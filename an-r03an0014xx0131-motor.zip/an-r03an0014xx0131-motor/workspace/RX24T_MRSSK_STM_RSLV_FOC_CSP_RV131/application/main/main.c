/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : main.c
* Description : The main function and the processes of application layer
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include <machine.h>
#include <stdbool.h>
#include "main.h"
#include "iodefine.h"

/****** for ICS ******/
#include "ICS_RX24T.h"
/*********************/
#include "r_mtr_common.h"
#include "r_mtr_ctrl_mcu.h"
#include "r_mtr_ctrl_inverter.h"
#include "r_mtr_foc_stm_rslv_control.h"
#include "r_ctrl_rdc_driver_adapter.h"
#include "r_mtr_ics.h"
#include "r_mtr_parameter.h"
#include "r_flash_access.h"

#include "r_rslv_api.h"

#include "r_mtr_stm_rslv_foc_rx_if.h"
#include "r_auto_calibration.h"
#include "r_mtr_board_ui.h"

uint8_t startup_calibration_sequence(void);

/***********************************************************************************************************************
* Private functions
***********************************************************************************************************************/
static void     ui_main(void);            /* ICS (Analyzer) user interface */
static void     variables_init(void);     /* Software initialize */
static void     memory_write(void);       /* Execution for memory write */
static void     rslv_calibration(void);   /* Resolver calibration process */
/***********************************************************************************************************************
* Global variables
***********************************************************************************************************************/
uint8_t     g_u1_motor_status;                /* Motor status */
uint8_t     com_u1_mode_system;               /* System mode */
uint8_t     g_u1_mode_system;                 /* System mode */
uint8_t     com_u1_memory_write;              /* Flag of memory write enable */
uint8_t     g_u1_result_flash_write;          /* Result of flash write */
uint8_t     g_u1_offset_cal_status;           /* Offset status */
uint8_t     com_u1_rslv_calibmode = 0;
uint8_t     g_u1_sw_userif = 1;
uint8_t     com_u1_sw_userif = 1;

/*** DTC table for ICS ***/
#pragma section DTCTBL
uint32_t dtc_table[256];
#pragma section
/*************************/

extern mtr_flash_val g_st_val;

/***********************************************************************************************************************
* Function Name : main
* Description   : Initialization and main routine
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void main(void)
{
    float f4_temp;
clrpsw_i();                                       /* Interrupt disable */
    /* Initialize peripheral functions */
    R_MTR_InitHardware();
    R_RSLVADP_Init();

    /* Initialize ICS */
    ics2_init((void*)dtc_table, ICS_SCI1_PD3_PD5, ICS_INT_LEVEL, ICS_BRR, ICS_INT_MODE);

    /* Start of A/D converter */
    R_MTR_Start_s12ad();

    /* Start of CMT0 */
    R_MTR_Start_cmt0();

    /* Initialize private global variables */
    variables_init();

    /* Execute reset event */
    R_MTR_SR_Foc_ExecEvent( MTR_ID_A,
                            MTR_EVENT_RESET);

#ifdef USE_FLASH
    /* Read for falsh memory */
    mtr_read_flashdt();

    /* Set values from Flash to control variables */
    R_MTR_SR_Foc_SetFlash2Ctrl( MTR_ID_A,
                                &g_st_val);
#endif

setpsw_i();                                       /* Interrupt enable */

    /* Start peripherals related to the resolver, must be called after enabling interrupt */
    R_RSLVADP_Start();
    mtr_init_adjst_interface();

    /*** Main routine ***/
    while (1)
    {
        /* User interface */
        ui_main();

#ifdef USE_FLASH
        /* Execution for memory write */
        memory_write();
#endif
        R_MTR_SR_Foc_GetSpeed(MTR_ID_A, &f4_temp, &g_f4_adjst_rslv_speed_rad);

        R_RSLVADP_MainLoopProcess();

        rslv_calibration();
        /* Clear watch dog timer */
        R_MTR_ClearWdt();
    }
} /* End of function main */

/***********************************************************************************************************************
* Function Name : ui_main
* Description   : User interface using ICS
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void ui_main(void)
{
    uint8_t u1_temp;

    /*============================*/
    /*        Get ICS value       */
    /*============================*/
    mtr_set_com_variables();

    /*============================*/
    /*   User interface switch    */
    /*============================*/
    u1_temp = com_u1_sw_userif;

    if (g_u1_sw_userif != u1_temp)
    {
        if (u1_temp >= MTR_SIZE_UI)
        {
            com_u1_sw_userif = g_u1_sw_userif;
        }
        else
        {
            g_u1_sw_userif = u1_temp;
        }
    }

    /*============================*/
    /*        Execute event       */
    /*============================*/
    if(g_u1_sw_userif == MTR_UI_BOARD)
    {
        /* Board SW & VR used */
        r_mtr_board_ui();
    }
    else
    {
        /* RMW used */
        /* Check INACTIVE flag for control system */
        if(MTR_SUCCESS == R_MTR_SR_Foc_IsOffsetCalFinished(MTR_ID_A, &g_u1_offset_cal_status))
        {
            if (TRUE == g_u1_offset_cal_status)
            {
                com_u1_mode_system = MTR_MODE_INACTIVE;
            }
        }
    }
    r_mtr_startup_calibration_sequence();

    u1_temp = com_u1_mode_system;

    if (g_u1_mode_system != u1_temp)
    {
        if (u1_temp >= MTR_SIZE_EVENT)
        {
            com_u1_mode_system = g_u1_mode_system;
        }
        else
        {
            if(TRUE == R_RSLVADP_IsRDCReady())
            {
                g_u1_mode_system = u1_temp;
                R_MTR_SR_Foc_ExecEvent( MTR_ID_A,
                                        g_u1_mode_system);
            }
            else
            {
                /* Do nothing */
            }
        }
    }

    R_MTR_SR_Foc_GetStatus( MTR_ID_A,
                            &g_u1_motor_status);      /* Get status of motor control system */

    if (MTR_EVENT_RESET == g_u1_mode_system)
    {
        if (MTR_MODE_INACTIVE == g_u1_motor_status)
        {
            variables_init();                            /* Initialize private global variables for reset event */
#ifdef USE_FLASH
            /* Read for falsh memory */
            mtr_read_flashdt();

            /* Set values from Flash to control variables */
            R_MTR_SR_Foc_SetFlash2Ctrl( MTR_ID_A,
                                        &g_st_val);
#endif
        }
        else if (MTR_MODE_ERROR == g_u1_motor_status)
        {
            g_u1_mode_system   = MTR_EVENT_ERROR;
            com_u1_mode_system = MTR_EVENT_ERROR;
        }
        else
        {
            /* Do nothing */
        }
    }

} /* End of function ui_main */

/***********************************************************************************************************************
* Function Name : memory_write
* Description   : Execution for memory write
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void memory_write(void)
{
    if(MTR_MODE_INACTIVE == g_u1_motor_status)
    {
        if(MTR_ENABLE == com_u1_memory_write)
        {
clrpsw_i();                                       /* Interrupt disable */
            R_MTR_SR_Foc_GetCtrl2Flash( MTR_ID_A,
                                        &g_st_val); /* Get parameter for control */
            g_u1_result_flash_write = R_MTR_WriteUsrDt2Flash();

            com_u1_memory_write = MTR_DISABLE;
setpsw_i();                                       /* Interrupt enable */
        }
    }
} /* End of function memory_write */

/***********************************************************************************************************************
* Function Name : variables_init
* Description   : Initialize private global variables
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void variables_init(void)
{
    g_u1_motor_status            = MTR_MODE_INACTIVE;
    g_u1_mode_system             = MTR_EVENT_INACTIVE;

    R_MTR_SR_Foc_Open(MTR_ID_A);
    R_MTR_SR_Foc_InitVariables(MTR_ID_A);

    /* ICS variables initialization */
    com_u1_mode_system           = MTR_EVENT_INACTIVE;
    mtr_ics_variables_init();
} /* End of function variables_init */

/***********************************************************************************************************************
* Function Name : rslv_calibration
* Description   : Resolver calibration process
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void rslv_calibration(void)
{
    uint8_t ret;

    if(com_u1_rslv_calibmode == 1)
    {
        ret = mtr_rdc_AdjstGainPhaseProcess(0);
        if(ret == 0)
        {
            com_u1_rslv_calibmode = 0;
        }
    }
    else if(com_u1_rslv_calibmode == 2)
    {
        ret = mtr_rdc_AdjstCarrierProcess(0);
        if(ret == 0)
        {
            com_u1_rslv_calibmode = 0;
        }
    }
}
