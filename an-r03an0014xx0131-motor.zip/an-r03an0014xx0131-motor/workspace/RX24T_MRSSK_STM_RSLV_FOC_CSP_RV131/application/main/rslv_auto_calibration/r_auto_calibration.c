/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_auto_calibration.c
* Version      :
* Device(s)    : R5F524TEAxFP
* Tool-Chain   : CCRX
* Description  : This file includes Auto Calibration process
* Creation Date: 2021/04/23
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <math.h>
#include "r_auto_calibration.h"
#include "r_mtr_config.h"
#include "r_mtr_common.h"
#include "main.h"

#include "iodefine.h"
#include "r_mtr_parameter.h"
#include "r_mtr_ctrl_mcu.h"
#include "r_mtr_foc_stm_rslv_control.h"
#include "r_mtr_foc_position.h"
#include "r_mtr_foc_speed.h"
#include "r_mtr_statemachine.h"

#include "r_rslv_api.h"
#include "r_ctrl_rdc_driver_adapter.h"

#include "r_mtr_stm_rslv_foc_rx_if.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
st_adjst_gainphase_return_t gp_api_ret;
st_adjst_carrier_arg_t cc_api_req;
st_adjst_carrier_return_t cc_api_ret;
float  g_f4_adjst_rslv_speed_rad = 0.0f;
extern mtr_foc_control_t g_st_foc;
extern uint8_t      com_u1_ctrl_loop_mode;
extern float        com_f4_ref_position_deg;
extern int16_t      com_s2_ref_speed_rpm;
extern uint8_t      com_u1_enable_write;            /* ICS write enable flag */
extern uint8_t      g_u1_enable_write;              /* ICS write enable flag */
extern uint8_t      com_u1_mode_system;             /* System mode */

/***********************************************************************************************************************
Static variables and functions
***********************************************************************************************************************/
#define     DEF_ADJST_CRIR_SPEED                (1000)      // reference speed at adjustment of
                                                            // carrier correction signal [rpm]
#define     DEF_POS_JUDGE_DIFF                  (0.2f)
#define     DEF_CTRL_WAIT_JUDGE                 (2500U)
#define     DEF_CTRL_SPEED_JUDGE                (100U)
#define     DEF_SPD_MARGIN                      (0.9f)
#define     PRV_LOOP_MODE_SWITCH_WAIT           (200)
#define     DEF_ADJST_SPEED_RIPPLE_RATE           (0.05f)

/* prototype definition of static functions */
static void mtr_ctrl_posspd_for_ccadjust_seq( void );

/* static variables */
static uint8_t s_u1_ctrl_posspd_seq = POSSPD_SEQ_NONE;
volatile uint16_t s_u2_ctrl_wait_cnt = 0U;
static uint8_t s_u1_flg_start_pos_ctrl = FALSE;

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: mtr_rdc_AdjstGainPhaseProcess
* Description  : Adjustment process of RDC IC Gain & Phase parameter
* Arguments    : req -
*                   Request of sequence continuation (0:continue, 1:halt)
* Return Value : Active status of Process (1:Active, 0:Finished)
***********************************************************************************************************************/
uint8_t mtr_rdc_AdjstGainPhaseProcess( uint8_t req )
{
    uint8_t result = TRUE;

    /* Call Gain & Phase Adjustment API */
    gp_api_ret = R_RSLV_ADJST_GainPhase(req);

    switch (gp_api_ret.u1_adjst_state)
    {
        default:
        case ADJST_APIINFO_RUN_MODE:
            {
                result = TRUE;
            }
        break;

        case ADJST_APIINFO_END_NORMAL:
        case ADJST_APIINFO_ERR_GAIN_HI_LMT:
        case ADJST_APIINFO_ERR_GAIN_LO_LMT:
        case ADJST_APIINFO_ERR_GAIN_SWAY:
        case ADJST_APIINFO_ERR_PHASE_AHI_BLO:
        case ADJST_APIINFO_ERR_PHASE_ALO_BHI:
        case ADJST_APIINFO_ERR_PHASE_SWAY:
        case ADJST_APIINFO_ERR_MOTOR:
        case ADJST_APIINFO_END_USER_STOP:
            {
                result = FALSE;
            }
        break;
    }

    return (result);
} /* end of function mtr_rdc_AdjstGainPhaseProcess() */

/***********************************************************************************************************************
* Function Name: mtr_rdc_AdjstCarrierProcess
* Description  : Adjustment process of Carrier Correction Signal
* Arguments    : req -
*                   Request of sequence continuation (0:continue, 1:halt)
* Return Value : Active status of Process (1:Active, 0:Finished)
***********************************************************************************************************************/
uint8_t mtr_rdc_AdjstCarrierProcess( uint8_t req )
{
    uint8_t result = TRUE;

    cc_api_req.call_state = req;

    /* Call Carrier Adjustment API */
    cc_api_ret = R_RSLV_ADJST_Carrier(cc_api_req);

    switch (cc_api_ret.adjst_state)
    {
        default:
        case ADJST_APIINFO_RUN_MODE:
            {
                result = TRUE;
            }
        break;

        /* Motor Control is required */
        case ADJST_APIINFO_WAITING:
            {
                mtr_ctrl_posspd_for_ccadjust_seq();
            }
        break;

        case ADJST_APIINFO_END_NORMAL:
        case ADJST_APIINFO_ERR_CARRIER:
        case ADJST_APIINFO_ERR_MOTOR:
        case ADJST_APIINFO_END_USER_STOP:
            {
                result = FALSE;
                com_u2_csig_shiftnum = cc_api_ret.res_csig_shift;
                com_u2_csig_amplvl = cc_api_ret.res_csig_amp;
                s_u1_flg_start_pos_ctrl = FALSE;
                s_u1_ctrl_posspd_seq = POSSPD_SEQ_NONE;
            }
        break;
    }

    return (result);

} /* end of function mtr_rdc_AdjstCarrierProcess() */


/***********************************************************************************************************************
Static functions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: mtr_s12ad_GetMntOut
* Description  : Get A/D converted data at RDC Monitor Out
* Arguments    : void
* Return Value : Converted A/D data at RDC Monitor Out
***********************************************************************************************************************/
uint16_t mtr_s12ad_GetMntOut( void )
{
    return ((uint16_t)S12AD1.ADDR3);
} /* end of function R_S12AD_GetMntOut() */

/***********************************************************************************************************************
* Function Name: mtr_s12ad_StartByAdjst
* Description  : A/D Conversion Control I/F
* Arguments    : ctrl -
*                   A/D conversion start/stop (1:start 0:stop)
* Return Value : void
***********************************************************************************************************************/
void mtr_s12ad_StartByAdjst( uint8_t ctrl )
{
    S12AD1.ADCSR.BIT.ADST = ctrl;
} /* end of function mtr_s12ad_StartByAdjst() */

/***********************************************************************************************************************
* Function Name: mtr_s12ad_ChkByAdjst
* Description  : Check to finish A/D conversion
* Arguments    : void
* Return Value : void
***********************************************************************************************************************/
uint8_t mtr_s12ad_ChkByAdjst( void )
{
    return ((uint8_t)S12AD1.ADCSR.BIT.ADST);
} /* end of function mtr_s12ad_ChkByAdjst() */

/***********************************************************************************************************************
 * Function Name: mtr_s12ad_ChgSettingForAdjst
 * Description  : Change A/D setting for Adjustment of Carrier Correction Signal
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
void mtr_s12ad_ChgSettingForAdjst( void )
{
    R_MTR_Stop_s12ad();                             // Stop Normal A/D conversion
    S12AD1.ADCSR.BIT.ADCS = 2;
    S12AD1.ADANSA0.BIT.ANSA003 = 1;                 /* Cancel A/D convert channel select AN206,AN207,AN208 */

} /* end of function mtr_s12ad_ChgSettingForAdjst() */

/***********************************************************************************************************************
 * Function Name: mtr_s12ad_ResetSettigForNormal
 * Description  : Reset A/D setting for generally
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
void mtr_s12ad_ResetSettigForNormal( void )
{
    S12AD1.ADANSA0.BIT.ANSA003 = 0;                      /* Cancel A/D convert channel select AN206,AN207,AN208 */
    S12AD1.ADCSR.BIT.ADCS = 0;
    R_MTR_Start_s12ad();                            /* Normal A/D conversion restart */

} /* end of function mtr_s12ad_ResetSettigForNormal() */

/***********************************************************************************************************************
* Function Name: mtr_init_adjst_interface
* Description  : Initialize interface functions and variables with Adjustment Library
* Arguments    : void
* Return Value : void
***********************************************************************************************************************/
void mtr_init_adjst_interface( void )
{
    st_ptr_func_arg_t  temp_arg;

    temp_arg.ad_data = mtr_s12ad_GetMntOut;
    temp_arg.ad_ctrl = mtr_s12ad_StartByAdjst;
    temp_arg.ad_peri_adjst = mtr_s12ad_ChgSettingForAdjst;
    temp_arg.ad_peri_user  = mtr_s12ad_ResetSettigForNormal;

    temp_arg.mtr_speed = &(g_f4_adjst_rslv_speed_rad);
    temp_arg.req_speed = DEF_ADJST_CRIR_SPEED;
    temp_arg.resolver_pole_num = RESOLVER_POLE;

    R_RSLV_ADJST_SetPtrFunc( &temp_arg );
    R_RSLV_Phase_AdjStart();
    /* Set carrier adjustment interface also */
    cc_api_req.req_state = ADJST_USRINFO_COMPLETE;
} /* end of function mtr_init_adjst_interface() */

/***********************************************************************************************************************
* Function Name: mtr_ctrl_posspd_for_ccadjust_seq
* Description  : Control Sequence of Openloop (Voltage Control) for Adjustment of Carrier Correction signal
* Arguments    : req -
*                   Requirement from Adjustment process of Carrier Correction signal
* Return Value : 1:processing 0:finished
***********************************************************************************************************************/
float dest_pos = 0;
float crnt_pos = 0.0f;
static void mtr_ctrl_posspd_for_ccadjust_seq( void )
{
    uint8_t u1_motor_status;
    float f4_ref_speed_rad;
    float f4_speed_rad;
    float f4_speed_rad_ctrl;
    float f4_speed_rad_err;
    float f4_speed_rad_limit;

    if (POSSPD_SEQ_NONE == s_u1_ctrl_posspd_seq)
    {
        switch (cc_api_ret.req_mtr_ctrl)
        {
            default:
                /* Do nothing */
            break;

            case ADJST_APIREQ_POS_CTRL:
                {
                    s_u1_ctrl_posspd_seq = POSSPD_SEQ_POS_START;
                }
            break;

            case ADJST_APIREQ_SPD_CTRL:
                {
                    s_u1_ctrl_posspd_seq = POSSPD_SEQ_SPD_REF;
                }
            break;

            case ADJST_APIREQ_POS_STOP:
            case ADJST_APIREQ_SPD_STOP:
                {
                    s_u1_ctrl_posspd_seq = POSSPD_SEQ_STOP;
                }
            break;
        }
    }

    switch (s_u1_ctrl_posspd_seq)
    {
        default:
        case POSSPD_SEQ_NONE:
            {
                cc_api_req.req_state = ADJST_USRINFO_COMPLETE;
            }
        break;

        case POSSPD_SEQ_POS_START:
            {
                if (FALSE == s_u1_flg_start_pos_ctrl)
                {
                    com_f4_ref_position_deg = 0;
                    com_u1_ctrl_loop_mode = MTR_LOOP_POSITION;
                    com_u1_enable_write = g_u1_enable_write;
                    s_u1_flg_start_pos_ctrl = TRUE;
                }
                else if (s_u2_ctrl_wait_cnt > PRV_LOOP_MODE_SWITCH_WAIT) /* Wait for new loop mode being applied */
                {
                    s_u1_ctrl_posspd_seq = POSSPD_SEQ_POS_REF;
                    com_u1_mode_system = MTR_EVENT_ACTIVE;
                    s_u2_ctrl_wait_cnt = 0;
                }
                else
                {
                    s_u2_ctrl_wait_cnt++;
                }

                cc_api_req.req_state = ADJST_USRINFO_PROCESSING;
            }
        break;

        case POSSPD_SEQ_POS_REF:
            {
                /* with MINEVEAR motor, control step is too small.
                 * Therefore addition of offset is performed. */
                dest_pos = (float)cc_api_ret.mtr_ctrl_data / RESOLVER_POLE;
                s_u2_ctrl_wait_cnt = 0U;
                cc_api_req.req_state = ADJST_USRINFO_PROCESSING;
                com_f4_ref_position_deg = dest_pos;
                com_u1_enable_write = g_u1_enable_write;
                s_u1_ctrl_posspd_seq = POSSPD_SEQ_POS_WAIT;
            }
        break;

        case POSSPD_SEQ_POS_WAIT:
            {
                R_MTR_SR_Foc_GetPosDeg(MTR_ID_A, &crnt_pos);
                cc_api_req.req_state = ADJST_USRINFO_PROCESSING;
                /* Rotor position reached to reference +/- 1.0deg */
                if (((dest_pos - crnt_pos) < DEF_POS_JUDGE_DIFF) && ((crnt_pos - dest_pos) < DEF_POS_JUDGE_DIFF))
                {
                    /* Wait stability of Position Control */
                    if (s_u2_ctrl_wait_cnt < DEF_CTRL_WAIT_JUDGE)
                    {
                        s_u2_ctrl_wait_cnt++;
                    }
                    else
                    {
                        cc_api_req.req_state = ADJST_USRINFO_COMPLETE;
                        s_u2_ctrl_wait_cnt = 0U;
                        s_u1_ctrl_posspd_seq = POSSPD_SEQ_NONE;
                    }
                }
            }
        break;

        case POSSPD_SEQ_SPD_REF:
            {
                com_s2_ref_speed_rpm = cc_api_ret.mtr_ctrl_data;
                com_u1_ctrl_loop_mode = MTR_LOOP_SPEED;
                com_u1_enable_write = g_u1_enable_write;
                s_u1_ctrl_posspd_seq = POSSPD_SEQ_SPD_START;
                cc_api_req.req_state = ADJST_USRINFO_PROCESSING;
            }
        break;

        case POSSPD_SEQ_SPD_START:
            {
                /* Wait for new loop mode being applied */
                if (s_u2_ctrl_wait_cnt > PRV_LOOP_MODE_SWITCH_WAIT)
                {
                    com_u1_mode_system = MTR_EVENT_ACTIVE;
                    s_u1_ctrl_posspd_seq = POSSPD_SEQ_SPD_WAIT;
                    s_u2_ctrl_wait_cnt = 0U;
                }
                else
                {
                    s_u2_ctrl_wait_cnt++;
                }
                cc_api_req.req_state = ADJST_USRINFO_PROCESSING;
            }
        break;

        case POSSPD_SEQ_SPD_WAIT:
            {
                cc_api_req.req_state = ADJST_USRINFO_PROCESSING;
                /* Speed runs over reference */
                R_MTR_SR_Foc_GetSpeed(MTR_ID_A, &f4_speed_rad, &f4_speed_rad_ctrl);
        f4_ref_speed_rad = (float)com_s2_ref_speed_rpm * MTR_RPM_RAD;
                f4_speed_rad_err =  f4_ref_speed_rad - f4_speed_rad_ctrl;
                f4_speed_rad_err = fabsf(f4_speed_rad_err);
                f4_speed_rad_limit =  f4_ref_speed_rad * DEF_ADJST_SPEED_RIPPLE_RATE;

        if (f4_speed_rad_err < f4_speed_rad_limit)
                {
                   /* Wait stability of Speed Control */
                    if (s_u2_ctrl_wait_cnt < DEF_CTRL_SPEED_JUDGE)
                    {
                        s_u2_ctrl_wait_cnt++;
                    }
                    else
                    {
                        cc_api_req.req_state = ADJST_USRINFO_COMPLETE;
                        s_u2_ctrl_wait_cnt = 0U;
                        s_u1_ctrl_posspd_seq = POSSPD_SEQ_NONE;
                    }
                 }
            }
        break;

        case POSSPD_SEQ_STOP:
            {
                cc_api_req.req_state = ADJST_USRINFO_PROCESSING;
                com_u1_mode_system = MTR_EVENT_INACTIVE;

                /* Guard All Adjustment Cancel */
                s_u1_ctrl_posspd_seq = POSSPD_SEQ_STOP_WAIT;
            }
        break;

        case POSSPD_SEQ_STOP_WAIT:
            {
                cc_api_req.req_state = ADJST_USRINFO_PROCESSING;
                R_MTR_SR_Foc_GetStatus( MTR_ID_A, &u1_motor_status);
                if (MTR_MODE_INACTIVE == u1_motor_status)
                {
                    s_u1_flg_start_pos_ctrl = FALSE;
                    cc_api_req.req_state = ADJST_USRINFO_COMPLETE;
                    s_u1_ctrl_posspd_seq = POSSPD_SEQ_NONE;
                }
            }
        break;
    }
} /* end of function mtr_ctrl_posspd_for_ccadjust_seq() */
