/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_auto_calibration.h
* Version      :
* Device(s)    : R5F524TEAxFP
* Tool-Chain   : CCRX
* Description  : Header for Auto Calibration process
* Creation Date: 2021/04/23
***********************************************************************************************************************/
#ifndef R_AUTO_CALIBRATION_H
#define R_AUTO_CALIBRATION_H

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>

#include "r_rslv_api.h"

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
/* Status of Sequence Openloop Control for CC Adjustment */
enum
{
    OL_SEQ_NONE = 0U,
    OL_SEQ_MTR_SET_REF,
    OL_SEQ_MTR_START,
    OL_SEQ_MTR_START_WAIT,
    OL_SEQ_MTR_STOP,
    OL_SEQ_MTR_STOP_WAIT
};

enum
{
    POSSPD_SEQ_NONE = 0,
    POSSPD_SEQ_POS_REF,
    POSSPD_SEQ_POS_START,
    POSSPD_SEQ_POS_WAIT,
    POSSPD_SEQ_SPD_REF,
    POSSPD_SEQ_SPD_START,
    POSSPD_SEQ_SPD_WAIT,
    POSSPD_SEQ_STOP,
    POSSPD_SEQ_STOP_WAIT
};

/***********************************************************************************************************************
Exported global variables
***********************************************************************************************************************/
extern st_adjst_gainphase_return_t gp_api_ret;
extern st_adjst_carrier_return_t cc_api_ret;
extern float g_f4_adjst_rslv_speed_rad;
/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/
extern uint8_t mtr_rdc_AdjstGainPhaseProcess( uint8_t );
extern uint8_t mtr_rdc_AdjstCarrierProcess( uint8_t );
extern void    mtr_init_adjst_interface( void );

#endif /* R_AUTO_CALIBRATION_H */
