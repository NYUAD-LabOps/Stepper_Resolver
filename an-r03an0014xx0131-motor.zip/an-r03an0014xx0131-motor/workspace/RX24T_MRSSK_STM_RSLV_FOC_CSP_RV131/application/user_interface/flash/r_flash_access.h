/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIESREGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_flash_access.h
* Version      :
* Device(s)    : R5F523T5AxFM
* Tool-Chain   : CCRX
* Description  : This file implements flash accessing function.
* Creation Date: 2021/04/23
***********************************************************************************************************************/
#ifndef R_FLASH_ACCESS_H_
#define R_FLASH_ACCESS_H_

#include <stdint.h>
#include "r_mtr_common.h"
#include "r_mtr_foc_stm_rslv_control.h"
/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/
#define     ERR_FA_PEMODE       (0x01)
#define     ERR_FA_BLOCKERASE   (0x02)
#define     ERR_FA_PROGRAM      (0x04)
#define     ERR_FA_RDMODE       (0x08)
#define     ERR_FA_VERIFY       (0x10)

/* definition */
#define     DEF_W_START_ADDR    (0xFFFE0000)                /* 128kByte */
#define     DEF_W_START_OFFSET  (0xFFFE0000 - 0xFC1E0000)   /* 128kByte */
#define     DATA_SET_ADRESS     (DEF_W_START_ADDR-DEF_W_START_OFFSET)
#define     DEF_WBYTE_SIZE      (8)
#define     DEF_SHIFT_WORD_DATA (2)                         /* Shift size of word(short) data */

#define     RSLV_ANGLE_OFFSET   (4.540686f)
#define     IA_OFFSET           (-0.02830246f)
#define     IB_OFFSET           (-0.04176212f)

#define     CSIG_SHIFTNUM       (184U)      /* Shift number of carrier compensation signal */
#define     CSIG_AMPLVL         (4U)          /* Amplitude level of carrier compensation signal */

#define     CSIG_PWM_DIFF_RATE_COUNT_LIMIT  (     999U)
#define     CSIG_PWM_DUTY_DATA_MID          (      99U)

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/


/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
typedef struct{
    uint16_t    u2_trans_cycle;            /* transfer cycle number */
    uint16_t    u2_trans_num;              /* transfer size */
    uint16_t    u2_write_size;             /* writing size */
    uint32_t    u4_dest_add;               /* destination address */
    uint8_t     *u1_source_add;            /* source address */
} st_flash_mem_info;

typedef struct{
    uint8_t     *u1_source_add;
    uint8_t     *u1_dest_add;
    uint16_t    u2_verify_num;
} st_flash_verify_info;

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
uint8_t R_MTR_WriteUsrDt2Flash( void );
void    mtr_read_flashdt( void );

#endif /* R_FLASH_ACCESS_H_ */
