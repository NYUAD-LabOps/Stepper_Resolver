/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIESREGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_flash_access.c
* Version      :
* Device(s)    : R5F523T5AxFM
* Tool-Chain   : CCRX
* Description  : This file implements flash accessing function.
* Creation Date: 2021/04/23
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include <math.h>
#include <machine.h>
#include <string.h>
#include "iodefine.h"
#include "r_flash_access.h"
#include "r_mtr_parameter.h"
#include "r_mtr_foc_stm_rslv_control.h"
#include "r_rslv_api.h"
#include "r_mtr_stm_rslv_foc_rx_if.h"

/***********************************************************************************************************************
 * Private functions
 ***********************************************************************************************************************/
static uint8_t flash_pe_mode(void);
static uint8_t flash_block_erase(uint32_t address);
static uint8_t flash_program_exe(st_flash_mem_info *st_info);
static void    flash_romread_mode(void);
static uint8_t flash_verify(st_flash_verify_info *verify_data);

/***********************************************************************************************************************
 Global variables and functions
 ***********************************************************************************************************************/
volatile uint8_t g_u1_dlcgsl_30_init_val = 0U;
volatile uint8_t g_u1_ccgsl_36_init_val = 0U;
volatile uint16_t g_u2_pwma_init_val = 0U;
volatile uint16_t g_u2_pwmb_init_val = 0U;

/* extern */
extern uint16_t com_u2_csig_shiftnum;         /* shift number of carrier compensation signal */
extern uint16_t com_u2_csig_amplvl;           /* amplitude level of carrier compensation signal */
extern uint8_t  com_u1_flg_upd_csigparam;
extern uint16_t g_u2_pwma;
extern uint16_t g_u2_pwmb;
extern uint8_t  g_u1_dlcgsl;
extern uint8_t  g_u1_ccgsl;
mtr_flash_val g_st_val;

/* variables */
static st_flash_mem_info g_st_flash_access_info[] =
{
 /* trans_cycle trans_num                                  write_size     dest_add         source_add*/
 {1,            sizeof(com_u2_csig_shiftnum),             DEF_WBYTE_SIZE, DATA_SET_ADRESS, (uint8_t*)&com_u2_csig_shiftnum},
 {1,            sizeof(com_u2_csig_amplvl),               DEF_WBYTE_SIZE, DATA_SET_ADRESS, (uint8_t*)&com_u2_csig_amplvl},
 {1,            sizeof(g_st_val.f4_rslv_angle_offset_rad),DEF_WBYTE_SIZE, DATA_SET_ADRESS, (uint8_t*)&g_st_val.f4_rslv_angle_offset_rad},
 {1,            sizeof(g_st_val.f4_offset_ia),            DEF_WBYTE_SIZE, DATA_SET_ADRESS, (uint8_t*)&g_st_val.f4_offset_ia},
 {1,            sizeof(g_st_val.f4_offset_ib),            DEF_WBYTE_SIZE, DATA_SET_ADRESS, (uint8_t*)&g_st_val.f4_offset_ib},
 {1,            sizeof(g_u2_pwma_init_val),               DEF_WBYTE_SIZE, DATA_SET_ADRESS, (uint8_t*)&g_u2_pwma},
 {1,            sizeof(g_u2_pwmb_init_val),               DEF_WBYTE_SIZE, DATA_SET_ADRESS, (uint8_t*)&g_u2_pwmb},
 {1,            sizeof(g_u1_dlcgsl_30_init_val),          DEF_WBYTE_SIZE, DATA_SET_ADRESS, (uint8_t*)&g_u1_dlcgsl},
 {1,            sizeof(g_u1_ccgsl_36_init_val),           DEF_WBYTE_SIZE, DATA_SET_ADRESS, (uint8_t*)&g_u1_ccgsl},
};
static st_flash_verify_info g_st_flash_verify_info;
static st_flash_verify_info *g_st_buf;

static uint32_t g_u4_dataini_start_add;
static uint32_t g_u4_verify_start_add;
static uint8_t  g_u1_flash_access_err = OK;
static uint8_t  g_u1_verify_sts = OK;
static uint8_t  g_u1_write_buffer[DEF_WBYTE_SIZE] =
{
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
};

/***********************************************************************************************************************
* Function Name: mtr_read_flashdt
* Description  :
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void mtr_read_flashdt( void )
{
    uint8_t  *u1_src_add;
    int16_t  *s2_src_add;
    uint16_t *u2_src_add;
    float    *f4_src_add;

    /*----- default value from ROM area -----*/
    f4_src_add = (float*)__sectop( "USR_VAR_AREA" );

    s2_src_add = (int16_t*)f4_src_add;
    com_u2_csig_shiftnum = (uint16_t)*s2_src_add;
    if ((com_u2_csig_shiftnum > CSIG_PWM_DIFF_RATE_COUNT_LIMIT) || isnan(com_u2_csig_shiftnum))
    {
        com_u2_csig_shiftnum = CSIG_SHIFTNUM;
    }

    /* Address shift */
    f4_src_add = f4_src_add+DEF_SHIFT_WORD_DATA;

    s2_src_add = (int16_t*)f4_src_add;
    com_u2_csig_amplvl = (uint16_t)*s2_src_add;
    if ((com_u2_csig_amplvl > CSIG_PWM_DUTY_DATA_MID) || isnan(com_u2_csig_amplvl))
    {
        com_u2_csig_amplvl = CSIG_AMPLVL;
        com_u1_flg_upd_csigparam = 1;
    }

    /* Address shift */
    f4_src_add = f4_src_add+DEF_SHIFT_WORD_DATA;

    g_st_val.f4_rslv_angle_offset_rad = *f4_src_add;
    if ((g_st_val.f4_rslv_angle_offset_rad < 0.0f) || isnan(g_st_val.f4_rslv_angle_offset_rad))
    {
        g_st_val.f4_rslv_angle_offset_rad = RSLV_ANGLE_OFFSET;
    }
    /* Address shift */
    f4_src_add = f4_src_add+DEF_SHIFT_WORD_DATA;
    g_st_val.f4_offset_ia = *f4_src_add;
    if (isnan(g_st_val.f4_offset_ia))
    {
        g_st_val.f4_offset_ia = IA_OFFSET;
    }
    /* Address shift */
    f4_src_add = f4_src_add+DEF_SHIFT_WORD_DATA;
    g_st_val.f4_offset_ib = *f4_src_add;
    if (isnan(g_st_val.f4_offset_ib))
    {
        g_st_val.f4_offset_ib = IB_OFFSET;
    }

    f4_src_add = f4_src_add + DEF_SHIFT_WORD_DATA;
    u2_src_add = (void*)f4_src_add;
    if ((*u2_src_add) < 255)
    {
        g_u2_pwma_init_val = *u2_src_add;
        R_RSLV_Phase_AdjUpdateBuff(g_u2_pwma_init_val, PHASE_CH_A);
    }

    f4_src_add = f4_src_add + DEF_SHIFT_WORD_DATA;
    u2_src_add = (void*)f4_src_add;
    if ((*u2_src_add) < 255)
    {
        g_u2_pwmb_init_val = *u2_src_add;
        R_RSLV_Phase_AdjUpdateBuff(g_u2_pwmb_init_val, PHASE_CH_B);
    }

    f4_src_add = f4_src_add + DEF_SHIFT_WORD_DATA;
    u1_src_add = (void*)f4_src_add;
    if ((*u1_src_add) <= 31)    /* Check maximum DLCGSL value */
    {
        g_u1_dlcgsl_30_init_val = *u1_src_add;
        R_RSLV_Rdc_SetRegisterVal(g_u1_dlcgsl_30_init_val, RDC_ADDR_DLCGSL_30);
    }

    f4_src_add = f4_src_add + DEF_SHIFT_WORD_DATA;
    u1_src_add = (void*)f4_src_add;
    if ((*u1_src_add) <= 5)     /* Check maximum CCGSL value */
    {
        g_u1_ccgsl_36_init_val = *u1_src_add;
        R_RSLV_Rdc_SetRegisterVal(g_u1_ccgsl_36_init_val, RDC_ADDR_CCGSL_36);
    }
} /* End of function mtr_read_flashdt */

#pragma section FLASHACCESS
/***********************************************************************************************************************
* Function Name: R_MTR_WriteUsrDt2Flash
* Description  : Flash accessing control function
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
uint8_t R_MTR_WriteUsrDt2Flash( void )
{
    uint8_t  u1_sts_flash_access = TRUE;
    uint8_t  u1_verify_err;
    uint8_t  u1_writing_num = (sizeof(g_st_flash_access_info))/(sizeof(g_st_flash_access_info[0]));
    uint8_t  u1_cnt = 0;
    uint16_t u2_add_shift = 0;
    g_u1_flash_access_err = OK;

    /*----------------------------------------------------- */
    /*      Top of writing address                          */
    /*----------------------------------------------------- */
    g_u4_dataini_start_add = (uint32_t)__sectop("USR_VAR_AREA");
    g_u4_dataini_start_add -= DEF_W_START_OFFSET;

    /*----------------------------------------------------- */
    /*      ROM read mode --> ROM P/E mode                  */
    /*----------------------------------------------------- */
    u1_sts_flash_access = flash_pe_mode();

    if (OK != u1_sts_flash_access)
    {
        g_u1_flash_access_err = ERR_FA_PEMODE;
    }

    /*----------------------------------------------------- */
    /*      Block Erase                                     */
    /*----------------------------------------------------- */
    if (OK == g_u1_flash_access_err)
    {
        u1_sts_flash_access = flash_block_erase(g_u4_dataini_start_add);

        if (OK != u1_sts_flash_access)
        {
            g_u1_flash_access_err = ERR_FA_BLOCKERASE;
        }
    }

    /*----------------------------------------------------- */
    /*      preparing address info and writing datas        */
    /*----------------------------------------------------- */
    if (OK == g_u1_flash_access_err)
    {
        u2_add_shift = 0;
        do
        {
            g_st_flash_access_info[u1_cnt].u4_dest_add = g_u4_dataini_start_add + (uint32_t)u2_add_shift;
            u1_sts_flash_access = flash_program_exe(&g_st_flash_access_info[u1_cnt]);
            if (OK != u1_sts_flash_access)
            {
                g_u1_flash_access_err = ERR_FA_PROGRAM;
                break;
            }
            u2_add_shift += g_st_flash_access_info[u1_cnt].u2_write_size;
        }
        while ((++u1_cnt) < u1_writing_num);
    }

    /*----------------------------------------------------- */
    /*      ROM P/E mode --> ROM read mode                  */
    /*----------------------------------------------------- */
    flash_romread_mode();

    /*----------------------------------------------------- */
    /*      Verify                                          */
    /*----------------------------------------------------- */
    if (OK == g_u1_flash_access_err)
    {
        g_u1_verify_sts = OK;
        u1_cnt = 0;
        u2_add_shift = 0;
        g_u4_verify_start_add = (uint32_t)__sectop( "USR_VAR_AREA" );
        do
        {
            g_st_flash_verify_info.u1_source_add = (uint8_t*)g_st_flash_access_info[u1_cnt].u1_source_add;
            g_st_flash_verify_info.u1_dest_add = (uint8_t*)(g_u4_verify_start_add + (uint32_t)u2_add_shift);
            g_st_flash_verify_info.u2_verify_num = g_st_flash_access_info[u1_cnt].u2_trans_num;
            u1_verify_err = flash_verify( &g_st_flash_verify_info );
            if (OK != u1_verify_err)
            {
                g_u1_verify_sts |= (0x01<<u1_cnt);
            }
            u2_add_shift += g_st_flash_access_info[u1_cnt].u2_write_size;
        }
        while ((++u1_cnt) < u1_writing_num);

        if (OK != g_u1_verify_sts)
        {
            g_u1_flash_access_err = ERR_FA_VERIFY;
        }
    }

    return(g_u1_flash_access_err);
} /* End of function R_MTR_WriteUsrDt2Flash */

/***********************************************************************************************************************
* Function Name: flash_pe_mode
* Description  :
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static uint8_t flash_pe_mode( void )
{
    uint16_t u2_wait_cnt = 0;
    uint8_t  u1_sts_err = OK;
    uint8_t  u1_operation_md;

    /* ROM/E2 DataFlash Access Disabled Mode --> ROM/E2 DataFlash Read Mode */
    FLASH.DFLCTL.BIT.DFLEN = 1;
    /* wait 5us(tms) */
    do
    {
        nop();
    }
    while ((++u2_wait_cnt) <= 600);
    u2_wait_cnt = 0;

    /* Disables the ROM cache operation */
    FLASH.ROMCE.WORD = 0x0000;

    /*----------------------------------------------------- */
    /*      ROM read mode --> ROM P/E mode                  */
    /*----------------------------------------------------- */
    FLASH.FENTRYR.WORD = 0xAA01;            /* ROM P/E mode */

    /* Set 12h in the FPMCR register */
    FLASH.FPR = 0xA5;
    FLASH.FPMCR.BYTE = 0x12;
    FLASH.FPMCR.BYTE = 0xED;
    FLASH.FPMCR.BYTE = 0x12;

    /* wait 2us(tdis) */
    do
    {
        nop();
    }
    while ((++u2_wait_cnt) <= 240);
    u2_wait_cnt = 0;

    /* operation mode */
    if (0 == SYSTEM.OPCCR.BIT.OPCM)
    {
        /* High speed mode */
        /* Set 92h in the FPMCR register */
        FLASH.FPR = 0xA5;
        FLASH.FPMCR.BYTE = 0x92;
        FLASH.FPMCR.BYTE = 0x6D;
        FLASH.FPMCR.BYTE = 0x92;

        /* Set 82h in the FPMCR register */
        FLASH.FPR = 0xA5;
        FLASH.FPMCR.BYTE = 0x82;
        FLASH.FPMCR.BYTE = 0x7D;
        FLASH.FPMCR.BYTE = 0x82;
        u1_operation_md = 0x82;
    }
    else
    {
        /* Middle speed mode */
        /* Set D2h in the FPMCR register */
        FLASH.FPR = 0xA5;
        FLASH.FPMCR.BYTE = 0xD2;
        FLASH.FPMCR.BYTE = 0x2D;
        FLASH.FPMCR.BYTE = 0xD2;

        /* Set C2h in the FPMCR register */
        FLASH.FPR = 0xA5;
        FLASH.FPMCR.BYTE = 0xC2;
        FLASH.FPMCR.BYTE = 0x3D;
        FLASH.FPMCR.BYTE = 0xC2;
        u1_operation_md = 0xC2;
    }

    /* wait 5us(tms) */
    do
    {
        nop();
    }
    while ((++u2_wait_cnt) <= 600);
    u2_wait_cnt = 0;

    /* Set the FCLK frequency 20MHz */
    FLASH.FISR.BIT.PCKA = 0x13;
    if (u1_operation_md != FLASH.FPMCR.BYTE)
    {
        u1_sts_err = NG;
    }

    return (u1_sts_err);
} /* End of function flash_pe_mode */

/***********************************************************************************************************************
* Function Name: flash_block_erase
* Description  :
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static uint8_t flash_block_erase( uint32_t u4_start_address )
{
    uint8_t u1_sts_err = OK;

    /*----------------------------------------------------- */
    /*      Block Erase                                     */
    /*----------------------------------------------------- */
    FLASH.FASR.BIT.EXS = 0;

    /* beginning address of block area */
    FLASH.FSARH = (uint16_t)((u4_start_address&0xFE1F0000)>>16);
    FLASH.FSARL = (uint16_t)(u4_start_address&0x0000FFF8);

    FLASH.FEARH = (uint16_t)(((u4_start_address+0x07F8)&0xFE1F0000)>>16);
    FLASH.FEARL = (uint16_t)((u4_start_address+0x07F8)&0x0000FFF8);

    FLASH.FCR.BYTE = 0x84;
    do
    {
        nop();
    }
    while (1 != FLASH.FSTATR1.BIT.FRDY);

    FLASH.FCR.BYTE = 0x00;
    do
    {
        nop();
    }
    while (0 != FLASH.FSTATR1.BIT.FRDY);

    /* error check */
    if ((1 == FLASH.FSTATR0.BIT.ILGLERR) || (1 == FLASH.FSTATR0.BIT.PRGERR))
    {
        /* initialize sequencer */
        FLASH.FRESETR.BIT.FRESET = 1;
        FLASH.FRESETR.BIT.FRESET = 0;

        u1_sts_err = NG;
    }

    return (u1_sts_err);
} /* End of function flash_block_erase */

/***********************************************************************************************************************
* Function Name: flash_program_exe
* Description  :
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static uint8_t flash_program_exe( st_flash_mem_info *st_info )
{
    uint8_t u1_sts_err = OK;
    uint8_t u1_cnt;
    st_flash_mem_info *st_buf = st_info;
    uint16_t u2_rest_num = st_info->u2_trans_num;
    uint16_t cycle_buf = st_info->u2_trans_cycle;
    uint16_t u2_add_shift = 0;

    for (u1_cnt=0; u1_cnt<DEF_WBYTE_SIZE; u1_cnt++,u2_add_shift++)
    {
        if (u1_cnt >= st_buf->u2_trans_num)
        {
            g_u1_write_buffer[u1_cnt] = 0x00;
        }
        else
        {
            g_u1_write_buffer[u1_cnt] = *(st_buf->u1_source_add+u2_add_shift);
        }
    }

    if ( st_buf->u2_trans_num >= DEF_WBYTE_SIZE)
    {
        u2_rest_num = u2_rest_num - DEF_WBYTE_SIZE;
    }

    /*----------------------------------------------------- */
    /*      Write default value(Flash program)              */
    /*----------------------------------------------------- */
    FLASH.FASR.BIT.EXS = 0;
    FLASH.FSARH = (uint16_t)((st_buf->u4_dest_add&0xFE1F0000)>>16);
    FLASH.FSARL = (uint16_t)(st_buf->u4_dest_add&0x0000FFF8);

    /* writing */
    do
    {
        FLASH.FWB0 = (((uint16_t)g_u1_write_buffer[1])<<8) | (uint16_t)g_u1_write_buffer[0];
        FLASH.FWB1 = (((uint16_t)g_u1_write_buffer[3])<<8) | (uint16_t)g_u1_write_buffer[2];
        FLASH.FWB2 = (((uint16_t)g_u1_write_buffer[5])<<8) | (uint16_t)g_u1_write_buffer[4];
        FLASH.FWB3 = (((uint16_t)g_u1_write_buffer[7])<<8) | (uint16_t)g_u1_write_buffer[6];

        /* Write the value set in registers FWB0, FWB1, FWB2, and FWB3 to the address set in registers FSARH and FSARL */
        FLASH.FCR.BYTE = 0x81;
        do
        {
            nop();
        }
        while (1 != FLASH.FSTATR1.BIT.FRDY);
        /* Confirm that the FSTATR1.FRDY flag is 1 (processing completed) before setting the OPST bit to 0 */
        FLASH.FCR.BYTE = 0x00;
        do
        {
            nop();
        }
        while (0 != FLASH.FSTATR1.BIT.FRDY);

        /* error check */
        if ((1 == FLASH.FSTATR0.BIT.ILGLERR) || (1 == FLASH.FSTATR0.BIT.PRGERR))
        {
            /* initialize sequencer */
            FLASH.FRESETR.BIT.FRESET = 1;
            FLASH.FRESETR.BIT.FRESET = 0;
            u1_sts_err = NG;
            break;
        }
        else
        {
            if (--cycle_buf > 0 )
            {
                for ( u1_cnt=0 ; u1_cnt<DEF_WBYTE_SIZE ; u1_cnt++,u2_add_shift++ )
                {
                    if (u1_cnt >= u2_rest_num)
                    {
                        g_u1_write_buffer[u1_cnt] = 0x00;
                    }
                    else
                    {
                        g_u1_write_buffer[u1_cnt] = *(st_buf->u1_source_add+u2_add_shift);
                    }
                }
                if (u2_rest_num >= DEF_WBYTE_SIZE)
                {
                    u2_rest_num = u2_rest_num - DEF_WBYTE_SIZE;
                }
            }
        }
    }while (cycle_buf > 0);

    return (u1_sts_err);
} /* End of function flash_program_exe */

/***********************************************************************************************************************
* Function Name: flash_romread_mode
* Description  :
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void flash_romread_mode( void )
{
    uint16_t u2_wait_counter = 0;

    /* Set 92h in the FPMCR register */
    FLASH.FPR = 0xA5;
    FLASH.FPMCR.BYTE = 0x92;
    FLASH.FPMCR.BYTE = 0x6D;
    FLASH.FPMCR.BYTE = 0x92;

    /* wait 2us(tdis) */
    do
    {
        nop();
    }
    while ((++u2_wait_counter) <= 240);
    u2_wait_counter = 0;

    /* Set 12h in the FPMCR register */
    FLASH.FPR = 0xA5;
    FLASH.FPMCR.BYTE = 0x12;
    FLASH.FPMCR.BYTE = 0xED;
    FLASH.FPMCR.BYTE = 0x12;

    /* Set 08h in the FPMCR register */
    FLASH.FPR = 0xA5;
    FLASH.FPMCR.BYTE = 0x08;
    FLASH.FPMCR.BYTE = 0xF7;
    FLASH.FPMCR.BYTE = 0x08;

    /* wait 5us(tms) */
    do
    {
        nop();
    }
    while ((++u2_wait_counter) <= 600);
    u2_wait_counter = 0;

    /* ROM read mode */
    FLASH.FENTRYR.WORD = 0xAA00;
    do
    {
        nop();
    }
    while (0x0000 != FLASH.FENTRYR.WORD);

    /* ROM cache invalidation */
    FLASH.ROMCIV.WORD = 0x0001;
    do
    {
        nop();
    }
    while (0x0000 != FLASH.ROMCIV.WORD);

    /* Enables the ROM cache operation */
    FLASH.ROMCE.WORD = 0x0001;
    do
    {
        nop();
    }
    while (0x0001 != FLASH.ROMCE.WORD);

    /* ROM/E2 DataFlash Read Mode --> ROM/E2 DataFlash Access Disabled Mode */
    FLASH.DFLCTL.BIT.DFLEN = 0;
    do
    {
        nop();
    }
    while (0 != FLASH.DFLCTL.BIT.DFLEN);

    /* initialize sequencer */
    FLASH.FRESETR.BIT.FRESET = 1;
    FLASH.FRESETR.BIT.FRESET = 0;
} /* End of function flash_romread_mode */

/***********************************************************************************************************************
* Function Name: flash_verify
* Description  :
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static uint8_t flash_verify( st_flash_verify_info *verify_data )
{
    uint32_t u4_verify_cnt = 0;
    uint8_t  u1_sts_err = OK;

    g_st_buf = verify_data;
    do
    {
        if ((*g_st_buf->u1_source_add) == (*g_st_buf->u1_dest_add))
        {
            g_st_buf->u1_source_add++;
            g_st_buf->u1_dest_add++;
            u4_verify_cnt++;
        }
        else
        {
            u1_sts_err = NG;
            nop();
            break;
        }
    }
    while (u4_verify_cnt < (g_st_buf->u2_verify_num));

    return (u1_sts_err);
} /* End of function flash_verify */

#pragma section
