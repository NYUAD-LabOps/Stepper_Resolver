/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_ics.c
* Description : Processes of a user interface (tool)
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <machine.h>

/* Main associated header file */
#include "r_mtr_ics.h"

/* Project headers */
#include "r_mtr_config.h"
#include "r_mtr_stm_rslv_foc_rx_if.h"
#include "r_ctrl_rdc_driver_adapter.h"
#include "ICS_RX24T.h"


static uint8_t           gs_u1_cnt_ics;         /* Counter for period of calling "scope_watchpoint" */
static mtr_ctrl_input_t  gs_st_ctrl_input;      /* Structure for ICS input */

/***********************************************************************************************************************
* Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
uint8_t      com_u1_enable_write;            /* ICS write enable flag */
uint8_t      g_u1_enable_write;              /* ICS write enable flag */

/* User command variables */
uint8_t      com_u1_flag_angle_spl_comp_use;  /* Flags whether use resolver position error compensation */
uint8_t      com_u1_flag_cc_spl_comp_use;    /* Flags whether use current control sampling delay compensation */
uint8_t      com_u1_flag_bpf_delay_comp_use; /* Flags whether use BPF delay compensation */
uint8_t      com_u1_flag_sob_use;            /* Flags whether use speed observer */
uint8_t      com_u1_flag_volt_err_comp_use;  /* Flags_whether use voltage error compensation */
uint8_t      com_u1_flag_flux_weakening_use; /* Flags_whether use flux-weakening */

uint8_t      com_u1_ctrl_loop_mode;          /* Loop mode select */
uint8_t      com_u1_ctrl_method_mode;        /* position loop method select */
uint8_t      com_u1_position_input_mode;     /* Position command value management */
uint8_t      com_u1_offset_adjust_mode;      /* Offset adjust mode */

uint8_t      com_u1_direction;               /* Rotational direction (0:CW ,1:CCW) */
float        com_f4_ref_position_deg;        /* Motor position reference [degree] (mechanical) */
int16_t      com_s2_ref_speed_rpm;           /* Motor speed reference [rpm] (mechanical) */
uint16_t     com_u2_min_speed_rpm;           /* Minimum speed [rpm] (mechanical) */
uint16_t     com_u2_max_speed_rpm;           /* Maximum speed [rpm] (mechanical) */
uint16_t     com_u2_speed_limit_rpm;         /* Over speed limit [rpm] (mechanical) */
uint16_t     com_u2_pos_interval_time;       /* Interval time for reference position update */
uint16_t     com_u2_pos_dead_band;           /* Position dead-band */
uint16_t     com_u2_pos_band_limit;          /* Positioning band limit */
uint16_t     com_u2_offset_calc_time;        /* Current offset calculation time */
uint16_t     com_u2_offset_calc_wait;        /* Counter for current offset detection start timing */
uint16_t     com_u2_run_mode;                /* RUN MODE */

float        com_f4_ipd_speed_k_ratio;       /* Speed gain ratio for I-PD */
float        com_f4_ipd_pos_kp_ratio;        /* Position control gain ratio for I-PD */
float        com_f4_ipd_err_limit_1;         /* Position error limit 1 */
float        com_f4_ipd_err_limit_2;         /* Position error limit 2 */
float        com_f4_accel_time;              /* Reference acceleration time */
float        com_f4_speed_rate_limit;        /* Limit of speed change */
float        com_f4_ref_id;                  /* Motor d-axis current reference when open loop [A] */
float        com_f4_ref_iq;                  /* Motor q-axis current reference [A] */
float        com_f4_current_rate_limit;      /* Limit of q-axis current change */
float        com_f4_bpf_comp_gain_cw;        /* BPF delay compensation gain for cw */
float        com_f4_bpf_comp_gain_ccw;       /* BPF delay compensation gain for ccw */
float        com_f4_bpf_comp_base_cw;        /* BPF delay compensation base coefficient for CW rotation*/
float        com_f4_bpf_comp_base_ccw;       /* BPF delay compensation base coefficient for CCW rotation*/

/* Motor parameters */
uint16_t     com_u2_mtr_pp;                  /* Pole pairs */
float        com_f4_mtr_r;                   /* Resistance [ohm] */
float        com_f4_mtr_ld;                  /* d-axis inductance [H] */
float        com_f4_mtr_lq;                  /* q-axis inductance [H] */
float        com_f4_mtr_m;                   /* Permanent magnetic flux [Wb] */
float        com_f4_mtr_j;                   /* Rotor inertia [kgm^2] */
float        com_f4_nominal_current_rms;     /* The nominal current[Arms] */

/* Design parameter */
float        com_f4_current_omega;           /* Natural frequency for current loop [Hz] */
float        com_f4_current_zeta;            /* Damping ratio for current loop */
float        com_f4_speed_omega;             /* Natural frequency for speed loop [Hz] */
float        com_f4_speed_zeta;              /* Damping ratio for speed loop */
float        com_f4_speed_lpf_omega;         /* Natural frequency for speed LPF [Hz] */
float        com_f4_pos_omega;               /* Natural frequency for position [Hz] */
float        com_f4_sob_omega;               /* Natural frequency for speed observer [Hz] */
float        com_f4_sob_zeta;                /* Damping ratio for speed observer */

/* Control gain */
float        com_f4_id_kp;                   /* d-axis current PI proportional gain */
float        com_f4_id_ki;                   /* d-axis current PI integral gain */
float        com_f4_iq_kp;                   /* q-axis current PI proportional gain */
float        com_f4_iq_ki;                   /* q-axis current PI integral gain */
float        com_f4_speed_kp;                /* Speed PI proportional gain */
float        com_f4_speed_ki;                /* Speed PI integral gain */
float        com_f4_pos_kp;                  /* Position P proportional gain */

/***********************************************************************************************************************
* Function Name : mtr_set_com_variables
* Description   : Set com variables to "tool" input buffer
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_com_variables(void)
{
    float f4_temp0;

    /**************************/
    /*    limit variables     */
    /**************************/
    com_s2_ref_speed_rpm = mtr_com_limit(com_s2_ref_speed_rpm, com_u2_max_speed_rpm, com_u2_min_speed_rpm);
    /* current natural frequency limit 1Hz ~ 1000Hz */
    com_f4_current_omega = mtr_com_limitf(com_f4_current_omega, MTR_MAX_CURRENT_OMEGA, MTR_MIN_POS_OMEGA);
    /* natural frequency & damping ratio for speed control loop */
    f4_temp0 = com_f4_current_omega / MTR_FREQ_BAND_LIMIT;
    if (f4_temp0 < com_f4_speed_omega)
    {
        com_f4_speed_omega = f4_temp0;
        /* speed natural frequency minimum limit 1Hz */
        com_f4_speed_omega = mtr_com_LowerLimitf(com_f4_speed_omega, MTR_MIN_POS_OMEGA);
    }
    /* natural frequency for position control loop */
    if (MTR_CTRL_PID == com_u1_ctrl_method_mode)
    {
        f4_temp0 = com_f4_speed_omega / MTR_FREQ_BAND_LIMIT;
        if (f4_temp0 < com_f4_pos_omega)
        {
            com_f4_pos_omega = f4_temp0;
            /* position natural frequency minimum limit 1Hz */
            com_f4_pos_omega = mtr_com_LowerLimitf(com_f4_pos_omega, MTR_MIN_POS_OMEGA);
        }
    }
    else if (MTR_CTRL_IPD == com_u1_ctrl_method_mode)
    {
        f4_temp0 = com_f4_current_omega / MTR_FREQ_BAND_LIMIT;
        if (f4_temp0 < (com_f4_ipd_speed_k_ratio * com_f4_pos_omega))
        {
            com_f4_ipd_speed_k_ratio = MTR_FREQ_BAND_LIMIT;
            com_f4_pos_omega = f4_temp0 / com_f4_ipd_speed_k_ratio;
            /* position natural frequency minimum limit 1Hz */
            com_f4_pos_omega = mtr_com_LowerLimitf(com_f4_pos_omega, MTR_MIN_POS_OMEGA);
        }
    }
    else
    {
        /* Do Nothing */
    }

    /***** When com_s2_enable_sw and g_u1_enable_write are same value, rewrite enable. *****/
    if (com_u1_enable_write == g_u1_enable_write)
    {
        /* Flags whether use resolver position error compensation */
        gs_st_ctrl_input.u1_flag_angle_spl_comp_use  = com_u1_flag_angle_spl_comp_use;
        /* Flags whether use current control sampling delay compensation */
        gs_st_ctrl_input.u1_flag_cc_spl_comp_use    = com_u1_flag_cc_spl_comp_use;
        /* Flags whether use BPF delay compensation */
        gs_st_ctrl_input.u1_flag_bpf_delay_comp_use = com_u1_flag_bpf_delay_comp_use;
        /* Flags whether use speed observer */
        gs_st_ctrl_input.u1_flag_sob_use            = com_u1_flag_sob_use;
        /* Flags_whether use voltage error compensation */
        gs_st_ctrl_input.u1_flag_volt_err_comp_use  = com_u1_flag_volt_err_comp_use;
        /* Flags_whether use flux-weakening */
        gs_st_ctrl_input.u1_flag_flux_weakening_use = com_u1_flag_flux_weakening_use;

        /* control loop select */
        gs_st_ctrl_input.u1_ctrl_loop_mode_buff   = com_u1_ctrl_loop_mode;
        /* control method select */
        gs_st_ctrl_input.u1_ctrl_method_mode      = com_u1_ctrl_method_mode;
        /* position command value management buffer */
        gs_st_ctrl_input.u1_state_pos_ref_buff    = com_u1_position_input_mode;
        /* Offset adjust mode */
        gs_st_ctrl_input.u1_offset_adjust_mode_buff = com_u1_offset_adjust_mode;
        /* RUN MODE */
        gs_st_ctrl_input.u2_run_mode = com_u2_run_mode;
        /* rotation direction */
        if (MTR_CCW < com_u1_direction)
        {
            com_u1_direction = MTR_CCW;
        }
        gs_st_ctrl_input.u1_direction = com_u1_direction;
        /* reference position [degree] (mechanical) */
        gs_st_ctrl_input.f4_ref_position_deg = com_f4_ref_position_deg;
        /* reference speed [rpm] (mechanical) */
        gs_st_ctrl_input.s2_ref_speed_rpm = com_s2_ref_speed_rpm;
        /* reference minimum speed [rpm] (mechanical) */
        gs_st_ctrl_input.u2_min_speed_rpm = com_u2_min_speed_rpm;
        /* reference maximum speed [rpm] (mechanical) */
        gs_st_ctrl_input.u2_max_speed_rpm = com_u2_max_speed_rpm;
        /* over speed limit [rpm] (mechanical) */
        gs_st_ctrl_input.u2_speed_limit_rpm = com_u2_speed_limit_rpm;
        /* interval time for reference position update */
        gs_st_ctrl_input.u2_pos_interval_time = com_u2_pos_interval_time;
        /* position dead-band */
        gs_st_ctrl_input.u2_pos_dead_band = com_u2_pos_dead_band;
        /* positioning band limit */
        gs_st_ctrl_input.u2_pos_band_limit = com_u2_pos_band_limit;
        /* current offset calculation time */
        gs_st_ctrl_input.u2_offset_calc_time = com_u2_offset_calc_time;
        /* Counter for current offset detection start timing */
        gs_st_ctrl_input.u2_offset_calc_wait = com_u2_offset_calc_wait;
        /* motor parameters */
        gs_st_ctrl_input.st_motor.u2_mtr_pp = com_u2_mtr_pp;
        gs_st_ctrl_input.st_motor.f4_mtr_r  = com_f4_mtr_r;
        gs_st_ctrl_input.st_motor.f4_mtr_ld = com_f4_mtr_ld;
        gs_st_ctrl_input.st_motor.f4_mtr_lq = com_f4_mtr_lq;
        gs_st_ctrl_input.st_motor.f4_mtr_m  = com_f4_mtr_m;
        gs_st_ctrl_input.st_motor.f4_mtr_j  = com_f4_mtr_j;
        gs_st_ctrl_input.st_motor.f4_nominal_current_rms = com_f4_nominal_current_rms;
        /* acceleration time */
        gs_st_ctrl_input.f4_accel_time = com_f4_accel_time;
        /* limit of speed change */
        gs_st_ctrl_input.f4_speed_rate_limit = com_f4_speed_rate_limit;
        /* id reference when low speed */
        gs_st_ctrl_input.f4_ref_id = com_f4_ref_id;
        /* iq reference when current control */
        gs_st_ctrl_input.f4_ref_iq = com_f4_ref_iq;
        /* limit of current change */
        gs_st_ctrl_input.f4_current_rate_limit = com_f4_current_rate_limit;
        /* BPF delay compensation gain for cw */
        gs_st_ctrl_input.f4_bpf_comp_gain_cw = com_f4_bpf_comp_gain_cw;
        /* BPF delay compensation gain for ccw */
        gs_st_ctrl_input.f4_bpf_comp_gain_ccw = com_f4_bpf_comp_gain_ccw;
        /* BPF delay compensation gain for cw */
        gs_st_ctrl_input.f4_bpf_comp_base_cw = com_f4_bpf_comp_base_cw;
        /* BPF delay compensation gain for ccw */
        gs_st_ctrl_input.f4_bpf_comp_base_ccw = com_f4_bpf_comp_base_ccw;

        /* natural frequency & damping ratio for control loop */
        gs_st_ctrl_input.st_design_params.f4_current_omega   = com_f4_current_omega;
        gs_st_ctrl_input.st_design_params.f4_current_zeta    = com_f4_current_zeta;
        gs_st_ctrl_input.st_design_params.f4_speed_omega     = com_f4_speed_omega;
        gs_st_ctrl_input.st_design_params.f4_speed_zeta      = com_f4_speed_zeta;
        gs_st_ctrl_input.st_design_params.f4_speed_lpf_omega = com_f4_speed_lpf_omega;
        gs_st_ctrl_input.st_design_params.f4_pos_omega       = com_f4_pos_omega;
        /* natural frequency & damping ratio for observer */
        gs_st_ctrl_input.st_design_params.f4_sob_omega     = com_f4_sob_omega;
        gs_st_ctrl_input.st_design_params.f4_sob_zeta      = com_f4_sob_zeta;
        /* control gain */
        gs_st_ctrl_input.st_ctrl_gain.f4_id_kp    = com_f4_id_kp;
        gs_st_ctrl_input.st_ctrl_gain.f4_id_ki    = com_f4_id_ki;
        gs_st_ctrl_input.st_ctrl_gain.f4_iq_kp    = com_f4_iq_kp;
        gs_st_ctrl_input.st_ctrl_gain.f4_iq_ki    = com_f4_iq_ki;
        gs_st_ctrl_input.st_ctrl_gain.f4_speed_kp = com_f4_speed_kp;
        gs_st_ctrl_input.st_ctrl_gain.f4_speed_ki = com_f4_speed_ki;
        gs_st_ctrl_input.st_ctrl_gain.f4_pos_kp   = com_f4_pos_kp;
        /* position control gain ratio for I-PD */
        gs_st_ctrl_input.f4_ipd_pos_kp_ratio = com_f4_ipd_pos_kp_ratio;
        /* speed gain ratio for I-PD */
        gs_st_ctrl_input.f4_ipd_speed_k_ratio = com_f4_ipd_speed_k_ratio;
        /* position error limit */
        gs_st_ctrl_input.f4_ipd_err_limit_1 = com_f4_ipd_err_limit_1;
        gs_st_ctrl_input.f4_ipd_err_limit_2 = com_f4_ipd_err_limit_2;
        /* copy variables com to ICS input */
        R_MTR_SR_Foc_CtrlInput(&gs_st_ctrl_input);

        g_u1_enable_write ^= 1;                         /* change every time 0 and 1 */
    }
} /* End of function mtr_set_com_variables */

/***********************************************************************************************************************
* Function Name : mtr_ics_variables_init
* Description   : Initialize valiables for Analyzer interface
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_ics_variables_init(void)
{
    g_u1_enable_write = 0;

    com_u1_flag_angle_spl_comp_use  = USE_RSLV_SPLTM_COMP;
    com_u1_flag_cc_spl_comp_use    = USE_CC_SPLDLY_COMP;
    com_u1_flag_bpf_delay_comp_use = USE_BPF_DELAY_COMP;
    com_u1_flag_sob_use            = USE_SOB;
    com_u1_flag_volt_err_comp_use  = USE_VOLT_ERR_COMP;
    com_u1_flag_flux_weakening_use = USE_FLUX_WEAKENING;

    com_u1_ctrl_loop_mode        = LOOP_MODE;
    com_u1_ctrl_method_mode      = POS_CTRL_MODE;
    com_u1_position_input_mode   = MTR_POS_TRAPEZOID;
    com_u1_offset_adjust_mode    = OFFSET_ADJUST_MODE;

    com_u1_direction          = MTR_CW;
    com_f4_ref_position_deg   = 0;
    com_s2_ref_speed_rpm      = 0;
    com_u2_min_speed_rpm      = MTR_MIN_SPEED_RPM;
    com_u2_max_speed_rpm      = MTR_MAX_SPEED_RPM;
    com_u2_speed_limit_rpm    = MTR_SPEED_LIMIT_RPM;
    com_u2_offset_calc_time   = MTR_OFFSET_CALC_TIME;
    com_u2_offset_calc_wait   = MTR_OFFSET_CALC_WAIT;
    com_u2_pos_dead_band      = MTR_POS_DEAD_BAND;
    com_u2_pos_band_limit     = MTR_POS_BAND_LIMIT;
    com_u2_pos_interval_time  = MTR_POS_INTERVAL_TIME;
    com_u2_run_mode           = MTR_MODE_DRIVE;
    com_f4_accel_time         = MTR_ACCEL_TIME;
    com_f4_ref_id             = MTR_REF_ID;
    com_f4_ref_iq             = 0.0f;
    com_f4_speed_rate_limit   = MTR_RATE_LIMIT_SPEED;
    com_f4_ipd_speed_k_ratio  = POS_SPEED_RATIO;
    com_f4_ipd_pos_kp_ratio   = POS_KP_RATIO;
    com_f4_ipd_err_limit_1    = POS_IPD_ERR_LIMIT_1;
    com_f4_ipd_err_limit_2    = POS_IPD_ERR_LIMIT_2;
    com_u1_enable_write       = 0;
    com_f4_current_rate_limit = MTR_RATE_LIMIT_CURRENT;
    com_f4_bpf_comp_gain_cw   = 1.0f;
    com_f4_bpf_comp_gain_ccw  = 1.0f;
    com_f4_bpf_comp_base_cw   = BPF_COMP_GAIN_BASE_CW;
    com_f4_bpf_comp_base_ccw  = BPF_COMP_GAIN_BASE_CCW;

    /* motor parameter */
    com_u2_mtr_pp = MTR_POLE_PAIRS;
    com_f4_mtr_r  = MTR_R;
    com_f4_mtr_ld = MTR_LD;
    com_f4_mtr_lq = MTR_LQ;
    com_f4_mtr_m  = MTR_M;
    com_f4_mtr_j  = MTR_J;
    com_f4_nominal_current_rms = MTR_NOMINAL_CURRENT_RMS;

    /* design parameter */
    com_f4_current_omega    = MTR_CURRENT_OMEGA;
    com_f4_current_zeta     = MTR_CURRENT_ZETA;
    com_f4_speed_omega      = MTR_SPEED_OMEGA;
    com_f4_speed_zeta       = MTR_SPEED_ZETA;
    com_f4_speed_lpf_omega  = MTR_SPEED_LPF_OMEGA;
    com_f4_pos_omega        = MTR_POS_OMEGA;
    com_f4_sob_omega        = SOB_OMEGA;
    com_f4_sob_zeta         = SOB_ZETA;

    /* pi gain */
    com_f4_id_kp    = 0.0f;
    com_f4_id_ki    = 0.0f;
    com_f4_iq_kp    = 0.0f;
    com_f4_iq_ki    = 0.0f;
    com_f4_speed_kp = 0.0f;
    com_f4_speed_ki = 0.0f;
    com_f4_pos_kp   = 0.0f;

    /* initialize member of ICS input structure */
    gs_st_ctrl_input.u1_flag_angle_spl_comp_use  = com_u1_flag_angle_spl_comp_use;
    gs_st_ctrl_input.u1_flag_cc_spl_comp_use    = com_u1_flag_cc_spl_comp_use;
    gs_st_ctrl_input.u1_flag_bpf_delay_comp_use = com_u1_flag_bpf_delay_comp_use;
    gs_st_ctrl_input.u1_flag_sob_use            = com_u1_flag_sob_use;
    gs_st_ctrl_input.u1_flag_volt_err_comp_use  = com_u1_flag_volt_err_comp_use;
    gs_st_ctrl_input.u1_flag_flux_weakening_use = com_u1_flag_flux_weakening_use;

    gs_st_ctrl_input.u1_ctrl_loop_mode_buff     = com_u1_ctrl_loop_mode;
    gs_st_ctrl_input.u1_ctrl_method_mode        = com_u1_ctrl_method_mode;
    gs_st_ctrl_input.u1_state_pos_ref_buff      = com_u1_position_input_mode;
    gs_st_ctrl_input.u1_offset_adjust_mode_buff = com_u1_offset_adjust_mode;

    gs_st_ctrl_input.u1_direction          = com_u1_direction;
    gs_st_ctrl_input.f4_ref_position_deg   = com_f4_ref_position_deg;
    gs_st_ctrl_input.s2_ref_speed_rpm      = com_s2_ref_speed_rpm;
    gs_st_ctrl_input.u2_min_speed_rpm      = com_u2_min_speed_rpm;
    gs_st_ctrl_input.u2_max_speed_rpm      = com_u2_max_speed_rpm;
    gs_st_ctrl_input.u2_speed_limit_rpm    = com_u2_speed_limit_rpm;
    gs_st_ctrl_input.u2_offset_calc_time   = com_u2_offset_calc_time;
    gs_st_ctrl_input.u2_offset_calc_wait   = com_u2_offset_calc_wait;
    gs_st_ctrl_input.u2_pos_dead_band      = com_u2_pos_dead_band;
    gs_st_ctrl_input.u2_pos_band_limit     = com_u2_pos_band_limit;
    gs_st_ctrl_input.u2_pos_interval_time  = com_u2_pos_interval_time;
    gs_st_ctrl_input.f4_ipd_pos_kp_ratio   = com_f4_ipd_pos_kp_ratio;
    gs_st_ctrl_input.f4_ipd_speed_k_ratio  = com_f4_ipd_speed_k_ratio;
    gs_st_ctrl_input.f4_ipd_err_limit_1    = com_f4_ipd_err_limit_1;
    gs_st_ctrl_input.f4_ipd_err_limit_2    = com_f4_ipd_err_limit_2;
    gs_st_ctrl_input.f4_accel_time         = com_f4_accel_time;
    gs_st_ctrl_input.f4_speed_rate_limit   = com_f4_speed_rate_limit;
    gs_st_ctrl_input.f4_ref_id             = com_f4_ref_id;
    gs_st_ctrl_input.f4_ref_iq             = com_f4_ref_iq;
    gs_st_ctrl_input.f4_current_rate_limit = com_f4_current_rate_limit;

    /* motor parameter */
    gs_st_ctrl_input.st_motor.u2_mtr_pp = com_u2_mtr_pp;
    gs_st_ctrl_input.st_motor.f4_mtr_r  = com_f4_mtr_r;
    gs_st_ctrl_input.st_motor.f4_mtr_ld = com_f4_mtr_ld;
    gs_st_ctrl_input.st_motor.f4_mtr_lq = com_f4_mtr_lq;
    gs_st_ctrl_input.st_motor.f4_mtr_m  = com_f4_mtr_m;
    gs_st_ctrl_input.st_motor.f4_mtr_j  = com_f4_mtr_j;
    gs_st_ctrl_input.st_motor.f4_nominal_current_rms = com_f4_nominal_current_rms;

    /* design parameter */
    gs_st_ctrl_input.st_design_params.f4_current_omega = com_f4_current_omega;
    gs_st_ctrl_input.st_design_params.f4_current_zeta  = com_f4_current_zeta;
    gs_st_ctrl_input.st_design_params.f4_speed_omega   = com_f4_speed_omega;
    gs_st_ctrl_input.st_design_params.f4_speed_zeta    = com_f4_speed_zeta;
    gs_st_ctrl_input.st_design_params.f4_pos_omega     = com_f4_pos_omega;
    gs_st_ctrl_input.st_design_params.f4_sob_omega     = com_f4_sob_omega;
    gs_st_ctrl_input.st_design_params.f4_sob_zeta      = com_f4_sob_zeta;

    /* pi gain */
    gs_st_ctrl_input.st_ctrl_gain.f4_id_kp    = com_f4_id_kp;
    gs_st_ctrl_input.st_ctrl_gain.f4_id_ki    = com_f4_id_ki;
    gs_st_ctrl_input.st_ctrl_gain.f4_iq_kp    = com_f4_iq_kp;
    gs_st_ctrl_input.st_ctrl_gain.f4_iq_ki    = com_f4_iq_ki;
    gs_st_ctrl_input.st_ctrl_gain.f4_speed_kp = com_f4_speed_kp;
    gs_st_ctrl_input.st_ctrl_gain.f4_speed_ki = com_f4_speed_ki;
    gs_st_ctrl_input.st_ctrl_gain.f4_pos_kp   = com_f4_pos_kp;

    /* BPF compensation */
    gs_st_ctrl_input.f4_bpf_comp_base_cw  = BPF_COMP_GAIN_BASE_CW;
    gs_st_ctrl_input.f4_bpf_comp_base_ccw = BPF_COMP_GAIN_BASE_CCW;
    gs_st_ctrl_input.f4_bpf_comp_gain_cw  = BPF_COMP_GAIN_MULT_CW;
    gs_st_ctrl_input.f4_bpf_comp_gain_ccw = BPF_COMP_GAIN_MULT_CCW;

    /* resolver parameter */
    gs_st_ctrl_input.f4_esig_freq             = st_drv_info.f_esig_freq;
    gs_st_ctrl_input.f4_esig_cnt              = (MTR_RSLV_TIMER_CLOCK / gs_st_ctrl_input.f4_esig_freq);
    gs_st_ctrl_input.f4_esig_cnt_inv          = (1.0f / gs_st_ctrl_input.f4_esig_cnt);
    gs_st_ctrl_input.f4_esig_half_cnt         = (gs_st_ctrl_input.f4_esig_cnt / 2.0f);
    gs_st_ctrl_input.f4_rslv_angle_diff       = (MTR_RSLV_ONE_CYCLE_RAD_MEC / gs_st_ctrl_input.f4_esig_cnt);

} /* End of function mtr_ics_variables_init */

/***********************************************************************************************************************
* Function Name : mtr_ics_interrupt_process
* Description   : Call by interrupt process(Period interval: 250 [us])
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_ics_interrupt_process(void)
{
    gs_u1_cnt_ics++;

    /* Decimation of ICS call */
    if (MTR_ICS_DECIMATION < gs_u1_cnt_ics)
    {
        gs_u1_cnt_ics = 0;

        /* Call ICS */
        ics2_watchpoint();
    }

    /* Update commands and configurations when trigger flag is set */
    R_MTR_SR_Foc_UpdateVariables(MTR_ID_A);

} /* End of function mtr_ics_interrupt_process */
