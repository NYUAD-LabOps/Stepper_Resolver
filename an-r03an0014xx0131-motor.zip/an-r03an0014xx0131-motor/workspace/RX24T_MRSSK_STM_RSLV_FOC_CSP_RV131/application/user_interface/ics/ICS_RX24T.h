#ifndef ICS_RX24T_H
#define ICS_RX24T_H

#include <stdint.h>

#define   ICS_SCI1_PD3_PD5    (0x10U)
#define   ICS_SCI5_PB5_PB6    (0x50U)
#define   ICS_SCI6_PB2_PB1    (0x60U)
#define   ICS_SCI6_PB0_PA5    (0x61U)
#define   ICS_SCI6_P81_P80    (0x62U)

void ics2_init(void * addr, uint8_t port, uint8_t level, uint8_t brr, uint8_t mode);
void ics2_watchpoint(void);

void ics_int_sci_rxi(void);
void ics_int_sci_eri(void);

#endif /* ICS_RX24T_H */
