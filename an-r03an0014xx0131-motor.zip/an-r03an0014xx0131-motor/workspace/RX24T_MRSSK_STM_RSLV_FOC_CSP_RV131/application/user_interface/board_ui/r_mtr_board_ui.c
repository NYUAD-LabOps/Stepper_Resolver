/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_mtr_board_ui.c
* Version      :
* Device(s)    : R5F523T***** & R5F524T*****
* Tool-Chain   : CCRX
* Description  : This file implements board (hardware) user interface functions
* Creation Date: 2021/04/23
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_board_ui.h"
#include "r_mtr_stm_rslv_foc_rx_if.h"
#include "r_mtr_ctrl_inverter.h"
#include "main.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/

/* exported variables from main */
extern uint8_t      com_u1_mode_system;             /* System mode */
extern uint8_t      com_u1_ctrl_loop_mode;          /* Loop mode select */
extern int16_t      com_s2_ref_speed_rpm;           /* Motor speed reference [rpm] (mechanical) */
extern uint8_t      com_u1_direction;               /* Rotational direction (0:CW ,1:CCW) */

extern uint8_t      g_u1_motor_status;              /* Motor status */
extern uint8_t      com_u1_enable_write;            /* ICS write enable flag */
extern uint8_t      g_u1_enable_write;              /* ICS write enable flag */
extern uint16_t     com_u2_run_mode;
extern uint8_t      com_u1_sw_userif;
extern uint8_t      com_u1_rslv_calibmode;


struct startup_calib_seq_t {
    uint8_t  u1_step;
    uint16_t u2_wait_cnt;
} g_st_startup_calib_seq;
/***********************************************************************************************************************
Static variables and functions
***********************************************************************************************************************/
/* prototype definitions of static functions */
static void     mtr_board_led_control( uint8_t );
static uint8_t  mtr_remove_sw_chattering( uint8_t, uint8_t );
static uint8_t  get_sw1(void);
static uint8_t  get_sw2(void);

#define     CHATTERING_CNT          (10)                /* Counts to remove chattering */
#define     SW2_PUSHED_LEVEL        (0)
#define     STEP_CALIB_NONE         (0)
#define     STEP_SET_ADJST_MODE     (1)
#define     STEP_EXE_ADJST_MODE     (2)
#define     STEP_SET_DRIVE_MODE     (3)
#define     STEP_EXE_CALIB1_MODE    (4)
#define     STEP_EXE_CALIB2_MODE    (5)
#define     STEP_CALIB_FINISH       (6)
static uint8_t  s_u1_sw_cnt = 0U;
static uint8_t  s_u1_reset_req = FALSE;

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name : r_mtr_board_ui
* Description   : User interface using Switches & Volume(VR)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_mtr_board_ui(void)
{
    uint8_t u1_temp_sw_signal;
    float   f4_vol_ad_data;
    float   f4_ref_speed_rpm = 0.0f;
    int16_t s2_ref_speed_rpm;

    /*======================*/
    /*     Mode control     */
    /*======================*/
    R_MTR_SR_Foc_GetStatus(MTR_ID_A, &g_u1_motor_status);
    if(r_mtr_startup_calibration_is_running() == FALSE)
    {
        switch (g_u1_motor_status)
        {
            case MTR_MODE_INACTIVE:
                /* Check SW1 */
                u1_temp_sw_signal = get_sw1();
                if (TRUE == mtr_remove_sw_chattering(u1_temp_sw_signal, SW_ON))
                {
                    com_u1_ctrl_loop_mode = MTR_LOOP_SPEED;
                    com_u1_mode_system = MTR_EVENT_ACTIVE;
                    com_u1_enable_write ^= 0x01;
                }
                else
                {
                    if(get_sw2() == SW2_PUSHED_LEVEL)
                    {
                        r_mtr_startup_calibration_start();
                    }
                }
            break;

            case MTR_MODE_ACTIVE:
                 /* Check SW1 */
                u1_temp_sw_signal = get_sw1();
                if (TRUE == mtr_remove_sw_chattering(u1_temp_sw_signal, SW_OFF))
                {
                    com_u1_mode_system = MTR_EVENT_INACTIVE;
                    com_u1_enable_write ^= 0x01;
                }

                /*=============================*/
                /*     Set speed reference     */
                /*=============================*/
                /* Translate VR A/D Data to reference Speed[rpm] */
                f4_vol_ad_data = mtr_get_vol_adc(MTR_ID_A);
                f4_ref_speed_rpm = (f4_vol_ad_data - DEF_VR_MID_LEVEL) * DEF_TRANS_AD2SPD;
                /* limit dead-band */
                if((f4_ref_speed_rpm <= DEF_VR_SPD_DBAND) && (f4_ref_speed_rpm >= -DEF_VR_SPD_DBAND))
                {
                    s2_ref_speed_rpm = 0;
                }
                else if(f4_ref_speed_rpm > DEF_VR_SPD_DBAND)
                {
                    s2_ref_speed_rpm = f4_ref_speed_rpm - DEF_VR_SPD_DBAND;
                }
                else if(f4_ref_speed_rpm < -DEF_VR_SPD_DBAND)
                {
                    s2_ref_speed_rpm = f4_ref_speed_rpm + DEF_VR_SPD_DBAND;
                }
                /* set speed reference */
                if(com_s2_ref_speed_rpm != s2_ref_speed_rpm)
                {
                    if(s2_ref_speed_rpm >= 0)
                    {
                        com_u1_direction = MTR_CW;
                        com_s2_ref_speed_rpm = s2_ref_speed_rpm;
                    }
                    else
                    {
                        com_u1_direction = MTR_CCW;
                        com_s2_ref_speed_rpm = -s2_ref_speed_rpm;
                    }
                    com_u1_enable_write ^= 0x01;
                }
            break;

            case MTR_MODE_ERROR:
                /* check SW2 & reset request flag */
                u1_temp_sw_signal = get_sw2();
                if ((FALSE == s_u1_reset_req) && (TRUE == mtr_remove_sw_chattering(u1_temp_sw_signal, SW_ON)))
                {
                    s_u1_reset_req = TRUE;
                }
                else if ((TRUE == s_u1_reset_req) && (TRUE == mtr_remove_sw_chattering(u1_temp_sw_signal, SW_OFF)))
                {
                    s_u1_reset_req = FALSE;
                    /* Cancel Error */
                    com_u1_mode_system = MTR_EVENT_RESET;
                }
                else
                {
                    /* Do nothing */
                }

            break;

            default:
                /* Do Nothing */
            break;
        }
    }
    /***** LED control *****/
    mtr_board_led_control(g_u1_motor_status);
} /* End of function r_mtr_board_ui */

/***********************************************************************************************************************
* Function Name : r_mtr_startup_calibration_start
* Description   : Starts all calibration sequence
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_mtr_startup_calibration_start(void)
{
    g_st_startup_calib_seq.u2_wait_cnt = 0;
    g_st_startup_calib_seq.u1_step = STEP_SET_ADJST_MODE;
} /* End of function r_mtr_startup_calibration_start */

/***********************************************************************************************************************
* Function Name : r_mtr_startup_calibration_is_running
* Description   : Returns whether the calibration is running
* Arguments     : None
* Return Value  : 0 = not running 1 = running
***********************************************************************************************************************/
uint8_t r_mtr_startup_calibration_is_running(void)
{
    return (g_st_startup_calib_seq.u1_step != STEP_CALIB_NONE);
} /* End of function r_mtr_startup_calibration_is_running */

/***********************************************************************************************************************
* Function Name : r_mtr_startup_calibration_sequence
* Description   : Startup calibration sequence function, should be called in main loop
* Arguments     : None
* Return Value  : Current step of calibration sequence
***********************************************************************************************************************/
uint8_t r_mtr_startup_calibration_sequence(void)
{

    switch(g_st_startup_calib_seq.u1_step)
    {
        case STEP_SET_ADJST_MODE:
        {
            /* Change run mode and interface, prepare for rotor alignment */
            com_u1_sw_userif = MTR_UI_RMW;
            com_u2_run_mode  = MTR_MODE_OFFSET_ADJUST;
            com_u1_enable_write = g_u1_enable_write;
            g_st_startup_calib_seq.u2_wait_cnt = 200;
            g_st_startup_calib_seq.u1_step = STEP_EXE_ADJST_MODE;
        }
        break;

        case STEP_EXE_ADJST_MODE:
        {
            /* Wait 200 cycle then start alignment */
            g_st_startup_calib_seq.u2_wait_cnt--;
            if(g_st_startup_calib_seq.u2_wait_cnt == 0)
            {
                com_u1_mode_system = MTR_MODE_ACTIVE;
                g_st_startup_calib_seq.u1_step = STEP_SET_DRIVE_MODE;
            }
        }
        break;

        case STEP_SET_DRIVE_MODE:
        {
            /* The alignment is completed when com_u1_mode_system become 0 */
            if(com_u1_mode_system == MTR_MODE_INACTIVE)
            {
                com_u2_run_mode  = MTR_MODE_DRIVE;
                com_u1_enable_write = g_u1_enable_write;
                g_st_startup_calib_seq.u2_wait_cnt = 200;
                g_st_startup_calib_seq.u1_step = STEP_EXE_CALIB1_MODE;
            }
        }
        break;

        case STEP_EXE_CALIB1_MODE:
        {
            /* Wait 200 cycle to change run mode then start gain phase calibration */
            if(com_u1_mode_system == MTR_MODE_INACTIVE)
            {
                com_u1_rslv_calibmode = 1;
                g_st_startup_calib_seq.u1_step = STEP_EXE_CALIB2_MODE;
            }
        }
        break;

        case STEP_EXE_CALIB2_MODE:
        {
            /* Start resolver carrier calibration when gain phase calibration ends */
            if(com_u1_rslv_calibmode == 0)
            {
                com_u1_rslv_calibmode = 2;
                g_st_startup_calib_seq.u1_step = STEP_CALIB_FINISH;
            }
        }
        break;

        case STEP_CALIB_FINISH:
        {
            /* Deactivate motor and switch back to board_u1 when carrier calibration calibration ends */
            if(com_u1_rslv_calibmode == 0)
            {
                com_u1_mode_system = MTR_MODE_INACTIVE;
                com_u1_sw_userif = MTR_UI_BOARD;
                g_st_startup_calib_seq.u1_step = STEP_CALIB_NONE;
            }
        }
        break;

        default:
        {
            // do nothing
        }
    }
    return (g_st_startup_calib_seq.u1_step);

} /* End of function r_mtr_startup_calibration_sequence */

/***********************************************************************************************************************
 static functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_board_led_control
* Description   : Set LED pattern depends on motor status
* Arguments     : u1_motor_status - Motor status
* Return Value  : None
***********************************************************************************************************************/
void mtr_board_led_control(uint8_t u1_motor_status)
{
    switch (u1_motor_status)
    {
        case MTR_MODE_ACTIVE:
            {
                led1_on();                                      /* LED1 on */
                led2_off();                                     /* LED2 off */
            }
        break;

        case MTR_MODE_ERROR:
            {
                led1_off();                                     /* LED1 off */
                led2_on();                                      /* LED2 on */
            }
        break;

        default:
            {
                led1_off();                                     /* LED1 off */
                led2_off();                                     /* LED2 off */
            }
        break;
    }
} /* End of function mtr_board_led_control */

/***********************************************************************************************************************
* Function Name : mtr_remove_sw_chattering
* Description   : Get switch status with removing chattering
* Arguments     : u1_sw - Board interface switch signal
*                 u1_on_off - Detected status (ON/OFF)
* Return Value  : u1_remove_chattering_flg - Detection result
***********************************************************************************************************************/
static uint8_t mtr_remove_sw_chattering(uint8_t u1_sw, uint8_t u1_on_off)
{
    uint8_t u1_remove_chattering_flg = FALSE;

    /* Switch status == Required status */
    if (u1_on_off == u1_sw)
    {
        s_u1_sw_cnt++;

        /* When match counts is over the chattering count */
        if (CHATTERING_CNT < s_u1_sw_cnt)
        {
            u1_remove_chattering_flg = TRUE;
            s_u1_sw_cnt = 0U;
        }
    }
    /* No match the statuses */
    else
    {
        /* Clear match count */
        s_u1_sw_cnt = 0U;
    }

    return (u1_remove_chattering_flg);
} /* End of function mtr_remove_sw_chattering */

/***********************************************************************************************************************
* Function Name : get_sw1
* Description   : Get state of SW1
* Arguments     : None
* Return Value  : State of SW1
***********************************************************************************************************************/
static uint8_t get_sw1(void)
{
    uint8_t tmp_port;

    tmp_port = MTR_PORT_SW1;

    return (tmp_port);
} /* End of function get_sw1 */

/***********************************************************************************************************************
* Function Name : get_sw2
* Description   : Get state of SW2
* Arguments     : None
* Return Value  : State of SW2
***********************************************************************************************************************/
static uint8_t get_sw2(void)
{
    uint8_t tmp_port;

    tmp_port = MTR_PORT_SW2;

    return (tmp_port);
} /* End of function get_sw2 */

