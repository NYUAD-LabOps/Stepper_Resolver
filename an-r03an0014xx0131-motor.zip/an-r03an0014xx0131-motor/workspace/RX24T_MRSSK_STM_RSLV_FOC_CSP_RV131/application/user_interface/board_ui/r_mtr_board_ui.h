/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_mtr_board_ui.h
* Version      :
* Device(s)    : R5F523T***** & R5F524T*****
* Tool-Chain   : CCRX
* Description  : Header for Board (Hardware) User Interface functions
* Creation Date: 2021/04/23
***********************************************************************************************************************/
#ifndef R_MTR_BOARD_UI_H
#define R_MTR_BOARD_UI_H

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
//#include "r_cg_macrodriver.h"
#include "iodefine.h"
#include "r_mtr_parameter.h"

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/


/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define     SW_ON               (0)                     /* Active level of SW */
#define     SW_OFF              (1)                     /* Inactive level of SW */
#define     MTR_LED_ON          (0)                     /* Active level of LED */
#define     MTR_LED_OFF         (1)                     /* Inactive level of LED */

#define     DEF_VR_MID_LEVEL    (0x7FF)                 /* Middle A/D Data of Board VR */
#define     DEF_VR_MAX_SPD_RPM  (200)                   /* Maximum speed[rpm] input from volume */
#define     DEF_VR_SPD_DBAND    (40.0f)                 /* Speed Dead Band [rpm] */
#define     DEF_VR_MAX_SPEED    (DEF_VR_MAX_SPD_RPM + DEF_VR_SPD_DBAND)
                                                        /* compensated Maximum Speed[rpm] */
#define     DEF_TRANS_AD2SPD    ((float)(DEF_VR_MAX_SPEED/DEF_VR_MID_LEVEL))
                                                        /* Translate parameter A/D Data to Speed[rpm] */

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global variables
***********************************************************************************************************************/


/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/
void r_mtr_board_ui( void );
void     r_mtr_startup_calibration_start(void);
uint8_t  r_mtr_startup_calibration_is_running(void);
uint8_t  r_mtr_startup_calibration_sequence(void);
#endif /* R_MTR_STM_RSLV_FOC_RX_BOARDIF_H */
