/**********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : r_mtr_stm_rslv_foc_rx_if.h
 * Description : Definitions of accessing driver processes
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * History : DD.MM.YYYY Version
 *           23.04.2021 1.31     First Release
 *********************************************************************************************************************/
#ifndef R_MTR_STM_RSLV_FOC_RX_IF_H
#define R_MTR_STM_RSLV_FOC_RX_IF_H

/**********************************************************************************************************************
 * Includes <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include <stdint.h>
#include "r_mtr_config.h"
#include "r_mtr_parameter.h"
#include "r_mtr_foc_stm_rslv_control.h"
#include "r_flash_access.h"

/**********************************************************************************************************************
 * Macro definitions
 *********************************************************************************************************************/
/* Version Number of API. */
#define MTR_SPM_RSLV_FOC_VERSION_MAJOR  (1)
#define MTR_SPM_RSLV_FOC_VERSION_MINOR  (20)

/* gain mode */
#define    MTR_GAIN_DESIGN_MODE    (0)        /* Use values in design_parameters to gains in PI controllers */
#define    MTR_GAIN_DIRECT_MODE    (1)        /* Access PI controllers directly */

/* Select control gain design mode as default method when GAIN_MODE is undefined */
#ifndef    GAIN_MODE
#define    GAIN_MODE               (MTR_GAIN_DESIGN_MODE)
#endif

extern mtr_foc_control_t    g_st_foc;

/**********************************************************************************************************************
 * Global structure
 *********************************************************************************************************************/
typedef struct{
    float   f4_rslv_angle_offset_rad;
    float   f4_offset_ia;                 /* a-phase current offset value [A] */
    float   f4_offset_ib;                 /* b-phase current offset value [A] */
} mtr_flash_val;

/* control input structure */
typedef struct
{
    uint8_t     u1_flag_angle_spl_comp_use;   /* Flags whether use resolver position error compensation */
    uint8_t     u1_flag_cc_spl_comp_use;      /* Flags whether use current control sampling delay compensation */
    uint8_t     u1_flag_bpf_delay_comp_use;   /* Flags whether use BPF delay compensation */
    uint8_t     u1_flag_sob_use;              /* Flags whether use speed observer */
    uint8_t     u1_flag_volt_err_comp_use;    /* Flags_whether use voltage error compensation */
    uint8_t     u1_flag_flux_weakening_use;   /* Flags_whether use flux-weakening */

    uint8_t     u1_ctrl_loop_mode_buff;       /* Control loop select */
    uint8_t     u1_ctrl_method_mode;          /* Control method select */
    uint8_t     u1_state_pos_ref_buff;        /* Position command value management */
    uint8_t     u1_offset_adjust_mode_buff;   /* Offset adjust mode */

    uint8_t     u1_direction;                 /* Reference rotation direction */
    float       f4_ref_position_deg;          /* Reference position [degree] */
    int16_t     s2_ref_speed_rpm;             /* Reference speed [rpm] (mechanical) */
    uint16_t    u2_min_speed_rpm;             /* Minimum speed [rpm] (mechanical) */
    uint16_t    u2_max_speed_rpm;             /* Maximum speed [rpm] (mechanical) */
    uint16_t    u2_speed_limit_rpm;           /* Over speed limit [rpm] (mechanical) */
    uint16_t    u2_pos_dead_band;             /* Position dead-band */
    uint16_t    u2_pos_band_limit;            /* Positioning band limit */
    uint16_t    u2_pos_interval_time;         /* Interval time for reference position update */
    uint16_t    u2_offset_calc_time;          /* Calculation time for current offset / 100 [us] */
    uint16_t    u2_offset_calc_wait;          /* Counter for current offset detection start timing */
    uint16_t    u2_run_mode;                  /* RUN MODE */

    float       f4_ipd_pos_kp_ratio;          /* Position proportional control gain ratio for I-PD control*/
    float       f4_ipd_speed_k_ratio;         /* Speed gain ratio for I-PD control */
    float       f4_ipd_err_limit_1;           /* Position error limit 1 */
    float       f4_ipd_err_limit_2;           /* Position error limit 2 */
    float       f4_accel_time;                /* Acceleration time */
    float       f4_speed_rate_limit;          /* Speed rate limit [rpm/ms] */
    float       f4_ref_id;                    /* Reference d-axis current [A] */
    float       f4_ref_iq;                    /* Motor q-axis current reference [A] */
    float       f4_current_rate_limit;        /* q-axis current rate limit [A/ms] */
    float       f4_bpf_comp_gain_cw;          /* BPF delay compensation gain for cw */
    float       f4_bpf_comp_gain_ccw;         /* BPF delay compensation gain for cw */
    float       f4_bpf_comp_base_cw;          /* BPF delay compensation base coefficient for cw */
    float       f4_bpf_comp_base_ccw;         /* BPF delay compensation base coefficient for cw */

    mtr_parameter_t        st_motor;          /* Motor parameters */
    mtr_design_parameter_t st_design_params;  /* Design parameter */
    mtr_ctrl_gain_t        st_ctrl_gain;      /* Control gain */

    float       f4_esig_freq;                 /* Get excitation frequency */
    float       f4_esig_cnt;                  /* Sampling time of position control */
    float       f4_esig_cnt_inv;
    float       f4_esig_half_cnt;
    float       f4_rslv_angle_diff;

} mtr_ctrl_input_t;

typedef struct
{
    uint8_t     u1_opt_rslv_spltm_comp;
    uint8_t     u1_opt_cc_spldly_comp;
    uint8_t     u1_opt_bpf_delay_comp;
    uint8_t     u1_opt_sob;
    uint8_t     u1_opt_volt_err_comp;
    uint8_t     u1_opt_flux_weakning;
} r_stm_rslv_ctrl_option_t;

/* API return values */
typedef enum
{
    MTR_SUCCESS = 0,
    MTR_FAIL,                                       // System failed (eg. cannot reserve memory by malloc)
    MTR_ERR_NOT_SUPPORT,                            // The API is not supported this type control.
    MTR_ERR_BAD_ID,                                 // Inputted Motor ID is out of range (minus or over 255)
    MTR_ERR_ALREADY_EXIST,                          // A Motor Instance which has inputted ID already exists
    MTR_ERR_ALREADY_RUN,                            // A Motor Instance already runs with any control type
    MTR_ERR_OVER_MAX,                               // Number of Motor Instance is over limit (3)
    MTR_ERR_OUT_OF_RANGE,                           // Inputted reference is out of range
    MTR_ERR_NO_OPEN                                 // Motor instance not created
} r_mtr_rslv_ret_t;

/**********************************************************************************************************************
 * Global function definitions
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_Open(uint8_t u1_id);
r_mtr_rslv_ret_t R_MTR_SR_Foc_Close(uint8_t u1_id);
r_mtr_rslv_ret_t R_MTR_SR_Foc_InitVariables(uint8_t u1_id);
r_mtr_rslv_ret_t R_MTR_SR_Foc_GetStatus(uint8_t u1_id,
                                        uint8_t *p_u1_status);
r_mtr_rslv_ret_t R_MTR_SR_Foc_GetErrStatus( uint8_t u1_id,
                                            uint16_t *p_u2_status);
r_mtr_rslv_ret_t R_MTR_SR_Foc_ExecEvent(uint8_t u1_id,
                                        uint8_t u1_event);
uint32_t R_MTR_SR_Foc_GetVersion(void);
r_mtr_rslv_ret_t R_MTR_SR_Foc_INT_PosSpdCtrl(uint8_t u1_id);
r_mtr_rslv_ret_t R_MTR_SR_Foc_INT_CrntCtrl(uint8_t u1_id);
r_mtr_rslv_ret_t R_MTR_RSLV_Foc_ChargeCapacitor(uint8_t u1_id);
r_mtr_rslv_ret_t R_MTR_SR_Foc_IsInPosition( uint8_t u1_id,
                                            uint8_t *pu1_position);
r_mtr_rslv_ret_t R_MTR_SR_Foc_IsOffsetCalFinished(  uint8_t u1_id,
                                                    uint8_t *p_u1_offset_adjust_mode);
void R_MTR_SR_Foc_CtrlInput(mtr_ctrl_input_t * pst_ctrl_input);
r_mtr_rslv_ret_t R_MTR_SR_Foc_UpdateVariables(uint8_t u1_id);
r_mtr_rslv_ret_t R_MTR_SR_Foc_INT_OverCur(uint8_t u1_id);
r_mtr_rslv_ret_t R_MTR_SR_Foc_INT_RdcAlarm(uint8_t u1_id);
r_mtr_rslv_ret_t R_MTR_SR_Foc_SetAngleInfo( uint8_t u1_id,
                                            uint16_t u2_angle_cnt,
                                            int16_t s2_angle_diff);
r_mtr_rslv_ret_t R_MTR_SR_Foc_GetPosDeg(uint8_t u1_id,
                                        float *pos_deg);
r_mtr_rslv_ret_t R_MTR_SR_Foc_GetSpeed(uint8_t u1_id,
                                       float *speed_rad,
                                       float *speed_rad_ctrl);
/**********************************************************************************************************************
* Function Name : R_MTR_SR_Foc_GetCtrl2Flash
* Description   : Write data of flash variables
* Arguments     :
* Return Value  :
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_GetCtrl2Flash(uint8_t u1_id,
                                            mtr_flash_val *pst_val);

/**********************************************************************************************************************
* Function Name : R_MTR_SR_Foc_SetFlash2Ctrl
* Description   : Read data for flash variables
* Arguments     : None
* Return Value  : None
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_SetFlash2Ctrl(uint8_t u1_id,
                                            mtr_flash_val *pst_val);

#endif /* R_MTR_STM_RSLV_FOC_RX_IF_H */
