/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_motor_parameter.h
* Description : Definition of the target motor parameters
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MTR_MOTOR_PARAMETER_H
#define R_MTR_MOTOR_PARAMETER_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_config.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Target motor parameter definitions */
#ifdef MP_MINEBEA_R17PMK440CNVA4438
#define     MP_POLE_PAIRS            (50)               /* Number of pole pairs */
#define     MP_MAGNETIC_FLUX         (0.0043f)          /* Permanent magnetic flux [Wb] */
#define     MP_RESISTANCE            (1.2f)             /* Resistance [ohm] */
#define     MP_D_INDUCTANCE          (0.0027f)          /* d-axis inductance [H] */
#define     MP_Q_INDUCTANCE          (0.0027f)          /* q-axis inductance [H] */
#define     MP_ROTOR_INERTIA         (7.5E-6f)          /* Rotor inertia [kgm^2] */
#define     MP_NOMINAL_CURRENT_RMS   (1.414f)           /* Nominal current [Arms] (2A_peak)*/
#endif

/* Resolver parameter definitions */
/* ---- Resolver Pole ---- */
#define RESOLVER_POLE                   (50)          /* Number of pole */

#endif /* R_MTR_MOTOR_PARAMETER_H */

