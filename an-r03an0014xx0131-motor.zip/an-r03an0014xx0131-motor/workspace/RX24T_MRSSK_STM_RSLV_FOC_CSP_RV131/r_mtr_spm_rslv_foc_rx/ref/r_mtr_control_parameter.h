/*********************************************************************\**************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_control_parameter.h
* Description : Definitions of default control parameters
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MTR_CONTROL_PARAMETER_H
#define R_MTR_CONTROL_PARAMETER_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_config.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Target control parameter definitions */
#ifdef CP_MINEBEA_R17PMK440CNVA4438
#define     CP_CURRENT_OMEGA            (400.0f)      /* natural frequency for current loop */
#define     CP_CURRENT_ZETA             (1.0f)        /* damping ratio for current loop */
#define     CP_SPEED_OMEGA              (40.0f)       /* natural frequency for speed loop */
#define     CP_SPEED_ZETA               (1.0f)        /* damping ratio for speed loop */
#define     CP_SPEED_LPF_OMEGA          (250.0f)      /* natural frequency for speed LPF */
#define     CP_POS_OMEGA                (10.0f)       /* natural frequency for position loop */
#define     CP_SOB_OMEGA                (200.0f)      /* natural frequency for speed observer */
#define     CP_SOB_ZETA                 (1.0f)        /* damping ratio for speed observer */
#define     CP_MIN_SPEED_RPM            (0)           /* minimum speed [rpm] (mechanical angle) */
#define     CP_MAX_SPEED_RPM            (3000)        /* maximum speed [rpm] (mechanical angle) */
#define     CP_SPEED_LIMIT_RPM          (4000)        /* over speed limit [rpm] (mechanical angle) */
#define     CP_OL_ID_REF                (1.8f)        /* id reference when open loop control [A] */
#endif

#endif /* R_MTR_CONTROL_PARAMETER_H */
