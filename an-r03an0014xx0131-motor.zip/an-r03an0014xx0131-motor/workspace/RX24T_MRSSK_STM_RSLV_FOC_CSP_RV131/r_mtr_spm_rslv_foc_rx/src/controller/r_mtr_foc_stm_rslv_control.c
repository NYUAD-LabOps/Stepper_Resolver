/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_foc_stm_rslv_control.c
* Description : The processes of motor control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <math.h>
#include <machine.h>

/* Main associated header file */
#include "iodefine.h"
#include "r_mtr_foc_stm_rslv_control.h"

/* Project headers */
#include "r_mtr_common.h"
#include "r_mtr_ctrl_mcu.h"
#include "r_mtr_fluxwkn.h"
#include "r_mtr_stm_rslv_foc_rx_if.h"
#include "r_ctrl_rdc_driver_adapter.h"

mtr_design_parameter_t st_default_parameters;
extern mtr_ctrl_input_t gs_st_ctrl_input_buff;     /* Structure for ICS input */

/***********************************************************************************************************************
* Function Name : mtr_foc_init
* Description   : Initializes FOC drive system with default configuration and specified motor ID
* Arguments     : st_foc - The pointer to the FOC data structure
*                 u1_id - The motor ID which specify the motor connectors
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_init(mtr_foc_control_t *st_foc, uint8_t u1_id)
{
    /* Initialize system state machine */
    mtr_statemachine_init(&st_foc->st_stm);

    /* Store the id to access HW resources */
    st_foc->u1_id = u1_id;

    /* Reset configurations to default */
    mtr_foc_motor_default_init(st_foc);
} /* End of function mtr_foc_init */

/***********************************************************************************************************************
* Function Name : mtr_foc_motor_default_init
* Description   : Initializes motor drive modules with default configuration
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_motor_default_init(mtr_foc_control_t *st_foc)
{
    st_foc->u2_run_mode        = MTR_MODE_DRIVE;
    st_foc->u2_error_status    = MTR_ERROR_NONE;
    st_foc->u1_state_id_ref    = MTR_ID_ZERO_CONST;
    st_foc->u1_state_iq_ref    = MTR_IQ_ZERO_CONST;
    st_foc->u1_state_speed_ref = MTR_SPEED_ZERO_CONST;
    st_foc->u1_state_pos_ref   = MTR_POS_TRAPEZOID;
    st_foc->u1_state_pos_ref_buff = 0;

    st_default_parameters.f4_current_omega   = MTR_CURRENT_OMEGA;
    st_default_parameters.f4_current_zeta    = MTR_CURRENT_ZETA;
    st_default_parameters.f4_speed_omega     = MTR_SPEED_OMEGA;
    st_default_parameters.f4_speed_zeta      = MTR_SPEED_ZETA;
    st_default_parameters.f4_speed_lpf_omega = MTR_SPEED_LPF_OMEGA;
    st_default_parameters.f4_pos_omega       = MTR_POS_OMEGA;
    st_default_parameters.f4_sob_omega       = SOB_OMEGA;
    st_default_parameters.f4_sob_zeta        = SOB_ZETA;

    /* Initialize member of motor parameter structure */
    st_foc->st_motor.u2_mtr_pp = MTR_POLE_PAIRS;
    st_foc->st_motor.f4_mtr_r  = MTR_R;
    st_foc->st_motor.f4_mtr_ld = MTR_LD;
    st_foc->st_motor.f4_mtr_lq = MTR_LQ;
    st_foc->st_motor.f4_mtr_m  = MTR_M;
    st_foc->st_motor.f4_mtr_j  = MTR_J;
    st_foc->st_motor.f4_nominal_current_rms = 0.0f;

    /* Initialize offset calibration */
    st_foc->u1_flag_offset_calc = MTR_FLG_CLR;
    st_foc->u2_offset_calc_time = MTR_OFFSET_CALC_TIME;
    st_foc->u2_offset_calc_wait = MTR_OFFSET_CALC_WAIT;
    st_foc->u2_cnt_adjust       = 0;
    st_foc->f4_vdc_ad           = 0.0f;
    st_foc->f4_offset_ia        = 0.0f;
    st_foc->f4_offset_ib        = 0.0f;
    st_foc->f4_sum_ia_ad        = 0.0f;
    st_foc->f4_sum_ib_ad        = 0.0f;
    st_foc->f4_ia_ad            = 0.0f;
    st_foc->f4_ib_ad            = 0.0f;
    st_foc->f4_rslv_angle_offset_rad     = 0.0f;
    st_foc->f4_rslv_angle_offset_sum_rad = 0.0f;

    if (MTR_FLG_SET != st_foc->u1_flag_charge_cap)
    {
        st_foc->u1_flag_charge_cap = MTR_FLG_CLR;
    }
    else
    {
        /* Do Nothing */
    }
//    if (MTR_ENABLE != R_RSLVADP_IsRDCReady())
//    {
//        g_u1_flg_rdc_state_ready = MTR_DISABLE;
//    }
//    else
//    {
//        /* Do Nothing */
//    }
    st_foc->u1_direction = MTR_CW;

    st_foc->f4_overspeed_limit_rad  = MTR_OVERSPEED_LIMIT_RAD;
    st_foc->f4_overvoltage_limit    = MTR_OVERVOLTAGE_LIMIT;
    st_foc->f4_undervoltage_limit   = MTR_UNDERVOLTAGE_LIMIT;
    st_foc->u1_ctrl_loop_mode       = LOOP_MODE;
    st_foc->u1_ctrl_method_mode     = POS_CTRL_MODE;
    st_foc->f4_overcurrent_limit    = MTR_OVERCURRENT_LIMIT;

    st_foc->u1_flag_angle_spl_comp_use = USE_RSLV_SPLTM_COMP;
    st_foc->u1_flag_pos_delay_comp_use = 0;
    st_foc->u1_flag_cc_spl_comp_use    = USE_CC_SPLDLY_COMP;
    st_foc->u1_flag_bpf_delay_comp_use = USE_BPF_DELAY_COMP;
    st_foc->u1_flag_volt_err_comp_use  = USE_VOLT_ERR_COMP;
    st_foc->u1_flag_sob_use            = USE_SOB;
    st_foc->u1_flag_flux_weakening_use = USE_FLUX_WEAKENING;

    st_foc->u1_offset_adjust_mode_buff = OFFSET_ADJUST_MODE;
    st_foc->u1_offset_adjust_mode      = st_foc->u1_offset_adjust_mode_buff;
    st_foc->u2_angle_adj_time          = MTR_ANGLE_ADJ_TIME;
    st_foc->u2_rslv_angle_offset_cnt   = 0;

    /* Initialize current control parameter */
    mtr_foc_current_init(&st_foc->st_cc);
    /* Initialize dq-axis current PI gains */
    mtr_foc_current_pi_gain_calc(
        &st_foc->st_motor,
        &st_default_parameters,
        &st_foc->st_cc,
        st_foc->st_cc.f4_ctrl_period
    );

    /* Initialize speed control parameter */
    mtr_speed_control_init(&st_foc->st_sc);
    /* Initialize Speed PI gains */
    mtr_speed_pi_gain_calc(
        &st_foc->st_motor,
        &st_default_parameters,
        &st_foc->st_sc,
        st_foc->st_sc.f4_speed_ctrl_period
    );
    /* Initialize position control parameter reset */
    mtr_position_control_init(&st_foc->st_pc);
    /* Initialize position P gain */
    mtr_pos_p_gain_calc(
        &st_default_parameters, &st_foc->st_pc
    );
    /* Initialize ipd control */
    mtr_ipd_ctrl_init(&st_foc->st_ipd);
    /* Initialize I-PD control gain */
    mtr_ipd_ctrl_gain_calc(
        &st_foc->st_motor,
        &st_default_parameters,
        &st_foc->st_ipd,
        st_foc->st_sc.f4_speed_ctrl_period
    );
    /* Setup current limits by nominal current of motor */
    mtr_foc_set_nominal_current(st_foc, MTR_NOMINAL_CURRENT_RMS);
    /* Voltage error compensation*/
    mtr_volt_err_comp_init(&st_foc->st_volt_comp_p);
    /* Initialize rotor angle parameter */
    mtr_rotor_angle_init(&st_foc->st_rotor_angle);
    /* Initialize position profiling parameter */
    mtr_position_profiling_init(&st_foc->st_ppf);
    /* Initialize speed LPF */
    mtr_com_FirstOrderLpffInit(&st_foc->st_slpf);
    /* Initialize speed LPF gain */
    mtr_com_FirstOrderLpffGainCalc(&st_foc->st_slpf,
                                 st_default_parameters.f4_speed_lpf_omega,
                                 st_foc->st_cc.f4_ctrl_period);
    /* Initialize speed observer */
    mtr_speed_observer_init(&st_foc->st_sob);
    /* Initialize speed observer gain */
    mtr_speed_observer_gain_calc(&st_foc->st_sob,
                                 &st_default_parameters,
                                 st_foc->st_cc.f4_ctrl_period);
    /* Initialize modulation module */
    mtr_mod_init(&st_foc->st_mod);
    mtr_mod_SetVdc(&st_foc->st_mod, MTR_INPUT_V);
    mtr_mod_SetMaxDuty(&st_foc->st_mod, MTR_MAX_DUTY_CYCLE);
    mtr_mod_SetMinDuty(&st_foc->st_mod, MTR_MIN_DUTY_CYCLE);
    mtr_mod_SetVoltageErrorRatio(&st_foc->st_mod, MTR_DUTY_CYCLE_DEADTIME);

    /* Initialize Flux-weakening module */
    mtr_fluxwkn_init(&st_foc->st_fluxwkn, MTR_LIMIT_IQ, mtr_mod_GetVamax(&st_foc->st_mod), &st_foc->st_motor);

    /* resolver compensation */
    mtr_rslv_comp_init(&st_foc->st_rcomp);
    /* Reset motor */
    mtr_foc_motor_reset(st_foc);
} /* End of function mtr_foc_motor_default_init */

/***********************************************************************************************************************
* Function Name : mtr_foc_motor_reset
* Description   : Resets motor drive modules, configurations will not be reset
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_motor_reset(mtr_foc_control_t *st_foc)
{
    /* Reset status structure members */
    st_foc->f4_ref_va = 0.0f;
    st_foc->f4_ref_vb = 0.0f;
    st_foc->f4_moda   = 0.0f;
    st_foc->f4_modb   = 0.0f;

    st_foc->u1_flag_mode_inactive         = MTR_DISABLE;
    st_foc->u2_angle_adj_cnt              = 0;

    st_foc->u1_state_angle_adj          = MTR_ANGLE_ADJ_90DEG;
    st_foc->s4_rslv_cycle_cnt            = 0;
    st_foc->u2_rslv_angle_cnt            = 0;
    st_foc->u2_rslv_pre_angle_cnt        = 0;
    st_foc->u2_rslv_timer_cnt            = 0;
    st_foc->s2_angle_err_cnt             = 0;
    st_foc->f4_spl_comp_angle_rad        = 0.0f;
    st_foc->f4_spl_delay_time            = 0.0f;
    st_foc->f4_spl_delay_comp_pos_rad    = 0.0f;
    st_foc->f4_rslv_pos_rad              = 0.0f;
    st_foc->f4_rslv_angle_rad            = 0.0f;
    st_foc->f4_rslv_speed_rad            = 0.0f;
    st_foc->f4_open_loop_pos_rad         = 0.0f;

    /* rotor angle parameter set*/
    mtr_rotor_angle_reset(&st_foc->st_rotor_angle);

    /* Reset current control module */
    mtr_foc_current_reset(&st_foc->st_cc);

    /* Reset speed control module */
    mtr_speed_control_reset(&st_foc->st_sc);

    /* Reset position control module */
    mtr_position_control_reset(&st_foc->st_pc);

    /* Position profiling parameter set */
    mtr_position_profiling_reset(&st_foc->st_ppf);

    if (MTR_ENABLE == st_foc->u1_flag_volt_err_comp_use)
    {
        /* Voltage error compensation */
        mtr_volt_err_comp_reset(&st_foc->st_volt_comp_p);
        /* voltage error compensation enable */
        st_foc->st_volt_comp_p.u1_volt_err_comp_enable = MTR_VOLT_ERR_COMP_ENABLE;
    }

    if (MTR_ENABLE == st_foc->u1_flag_flux_weakening_use)
    {
        mtr_fluxwkn_reset(&st_foc->st_fluxwkn);
    }

    mtr_com_FirstOrderLpffReset(&st_foc->st_slpf);
    /* speed observer */
    mtr_speed_observer_reset(&st_foc->st_sob);

    /* ipd control */
    mtr_ipd_ctrl_reset(&st_foc->st_ipd);

    /* resolver compensation */
    mtr_rslv_comp_reset(&st_foc->st_rcomp);

    /* mod */
    mtr_mod_reset(&st_foc->st_mod);

} /* End of function mtr_foc_motor_reset */

/***********************************************************************************************************************
* Function Name : mtr_foc_error
* Description   : Sets error flags and trigger error event when u2_error_flag is not zero
* Arguments     : st_foc - The pointer to the FOC data structure
*                 u2_error_flag - The error flags of the errors to report
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_error(mtr_foc_control_t *st_foc, uint16_t u2_error_flag)
{
    if (MTR_ERROR_NONE != u2_error_flag)
    {
        st_foc->u2_error_status |= u2_error_flag;
        mtr_statemachine_event(&st_foc->st_stm, st_foc, MTR_EVENT_ERROR);
    }
} /* End of function mtr_foc_error */

/***********************************************************************************************************************
* Function Name : mtr_calib_current_offset_iaib
* Description   : Measures the ab axis current offset
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : none
***********************************************************************************************************************/
void mtr_calib_current_offset_iaib(mtr_foc_control_t *st_foc)
{
    /* set half carrier */
    mtr_inv_set_ab(0.5f, 0.5f, st_foc->u1_id);

    /*==================================*/
    /*    current offset calibration    */
    /*==================================*/
    if ((st_foc->u2_offset_calc_time + st_foc->u2_offset_calc_wait) <= st_foc->u2_cnt_adjust)
    {
        st_foc->u1_flag_offset_calc = MTR_FLG_SET;
        st_foc->u2_cnt_adjust = st_foc->u2_offset_calc_time;
        st_foc->f4_offset_ia = st_foc->f4_sum_ia_ad / st_foc->u2_offset_calc_time;
        st_foc->f4_offset_ib = st_foc->f4_sum_ib_ad / st_foc->u2_offset_calc_time;
    }
    else
    {
        if(st_foc->u2_cnt_adjust >= st_foc->u2_offset_calc_wait)
        {
            st_foc->f4_sum_ia_ad += st_foc->f4_ia_ad + st_foc->f4_offset_ia;
            st_foc->f4_sum_ib_ad += st_foc->f4_ib_ad + st_foc->f4_offset_ib;
        }
    }
    st_foc->u2_cnt_adjust++;
} /* End of function mtr_calib_current_offset_iaib */

/***********************************************************************************************************************
* Function Name : mtr_current_offset_adjustment_iaib
* Description   : Calibrates the current offset
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_current_offset_adjustment_iaib(mtr_foc_control_t *st_foc)
{
    /* Current offset adjustment */
    st_foc->f4_ia_ad = st_foc->f4_ia_ad - st_foc->f4_offset_ia;
    st_foc->f4_ib_ad = st_foc->f4_ib_ad - st_foc->f4_offset_ib;
} /* End of function mtr_current_offset_adjustment_iaib */

/***********************************************************************************************************************
* Function Name : mtr_rslv_pos_speed_calc
* Description   : calculate rotor position and speed
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_rslv_pos_speed_calc(mtr_foc_control_t *st_foc)
{
    float f4_temp0;
    int32_t s4_pos_cnt_error;

    /*================================*/
    /*   Resolver angle cycle count   */
    /*================================*/
    s4_pos_cnt_error = (int32_t)st_foc->u2_rslv_pre_angle_cnt - (int32_t)st_foc->u2_rslv_angle_cnt;
    if (s4_pos_cnt_error >= gs_st_ctrl_input_buff.f4_esig_half_cnt)
    {
        st_foc->s4_rslv_cycle_cnt++;
    }
    else if (s4_pos_cnt_error <= (-gs_st_ctrl_input_buff.f4_esig_half_cnt))
    {
        st_foc->s4_rslv_cycle_cnt--;
    }
    else
    {
        /* Do Nothing */
    }
    st_foc->u2_rslv_pre_angle_cnt = st_foc->u2_rslv_angle_cnt;

    /*======================================*/
    /*   Count to rad for Position(angle)   */
    /*======================================*/
    /* Angle calculation */
    st_foc->f4_rslv_angle_rad = (float)st_foc->u2_rslv_angle_cnt * gs_st_ctrl_input_buff.f4_esig_cnt_inv * MTR_TWOPI;
    /* BPF delay comp */
    if(MTR_ENABLE == st_foc->u1_flag_bpf_delay_comp_use)
    {
        st_foc->f4_rslv_angle_rad += mtr_bpf_delay_comp(&st_foc->st_rcomp,
                                                        st_foc->u1_direction,
                                                        st_foc->u2_rslv_angle_offset_cnt,
                                                        st_foc->st_sc.f4_speed_rad_ctrl);
    }

    /* Iron-loss compensation */
    st_foc->f4_rslv_angle_rad += mtr_iron_loss_comp(&st_foc->st_rcomp, st_foc->st_sc.f4_speed_rad_ctrl);

    /* Adjust angle offset */
    st_foc->f4_rslv_angle_rad -= st_foc->f4_rslv_angle_offset_rad;

    /* Position caliculation */
    f4_temp0 = (float)st_foc->u2_rslv_angle_cnt * gs_st_ctrl_input_buff.f4_esig_cnt_inv * MTR_RSLV_ONE_CYCLE_RAD_MEC;
    st_foc->f4_rslv_pos_rad = f4_temp0 + (float)(st_foc->s4_rslv_cycle_cnt * MTR_RSLV_ONE_CYCLE_RAD_MEC);
    /* limit angle value of one rotation */
    if(st_foc->f4_rslv_angle_rad >= MTR_TWOPI)
    {
        st_foc->f4_rslv_angle_rad -= MTR_TWOPI;
    }
    else if(st_foc->f4_rslv_angle_rad < 0.0f)
    {
        st_foc->f4_rslv_angle_rad += MTR_TWOPI;
    }
    else
    {
        /* Do Nothing */
    }

    /*==============================*/
    /*   Count to rad/s for Speed   */
    /*==============================*/
    f4_temp0 = (float)((MTR_PWM_TIMER_FREQ * 1000000.0f) / (st_foc->s2_angle_err_cnt + gs_st_ctrl_input_buff.f4_esig_cnt));
    st_foc->f4_rslv_speed_rad = ((float)gs_st_ctrl_input_buff.f4_esig_freq - f4_temp0) * MTR_TWOPI;
} /* End of function mtr_rslv_pos_speed_calc */

/***********************************************************************************************************************
* Function Name: mtr_current_ctrl_smpldly_comp
* Description  : current control sampling delay compensation
* Arguments    : f4_angle_rad - motor angle (electrical) [rad]
*              : f4_speed_rad - motor speed (electrical) [rad/s]
* Return Value : motor angle (electrical) [rad/s]
***********************************************************************************************************************/
float mtr_current_ctrl_smpldly_comp(float f4_angle_rad, float f4_speed_rad)
{
    float f4_comp_angle_rad;
    float f4_temp_angle_rad;

    f4_comp_angle_rad = f4_speed_rad * MTR_CTRL_PERIOD * MTR_PERIOD_MAG_VALUE;
    f4_temp_angle_rad = f4_angle_rad + f4_comp_angle_rad;
    /* limit angle value of one rotation */
    if(f4_temp_angle_rad >= MTR_TWOPI)
    {
        f4_temp_angle_rad -= MTR_TWOPI;
    }
    else if(f4_temp_angle_rad < 0.0f)
    {
        f4_temp_angle_rad += MTR_TWOPI;
    }
    else
    {
        /* Do Nothing */
    }

    return (f4_temp_angle_rad); /* theta + w * delta_t * 1.5 */
} /* End of function mtr_current_ctrl_smpldly_comp */

/***********************************************************************************************************************
* Function Name : mtr_angle_speed
* Description   : Angle and speed detection
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_angle_speed(mtr_foc_control_t *st_foc)
{
    float f4_angle_rad = 0.0f;

    if (MTR_MODE_OFFSET_ADJUST == st_foc->u2_run_mode)
    {
        /* speed must be zero while adjusting angle */
        st_foc->st_sc.f4_speed_rad = 0.0f;

        if (MTR_ANGLE_ADJ_90DEG == st_foc->u1_state_angle_adj)
        {
            /* set alignment angle to Pi/2[rad] */
            f4_angle_rad = MTR_TWOPI * 0.25f;
        }
        else if (MTR_ANGLE_ADJ_0DEG == st_foc->u1_state_angle_adj)
        {
            /* set alignment angle to 0[rad] */
            f4_angle_rad = 0.0f;
        }
        else
        {
            /* Do Nothing */
        }
    }
    else if ((MTR_MODE_DRIVE == st_foc->u2_run_mode) && (MTR_LOOP_CURRENT_ID != st_foc->u1_ctrl_loop_mode))
    {
        /*===============*/
        /*   Set speed   */
        /*===============*/
        if (MTR_ENABLE == st_foc->u1_flag_sob_use)
        {
            /* speed observer */
           st_foc->st_sc.f4_speed_rad = mtr_speed_observer(&st_foc->st_sob,
                                                           &st_foc->st_motor,
                                                           st_foc->st_cc.f4_ref_iq_ctrl,
                                                           st_foc->f4_rslv_speed_rad);
        }
        else
        {
            st_foc->st_sc.f4_speed_rad = st_foc->f4_rslv_speed_rad;
        }
        st_foc->st_sc.f4_speed_rad_ctrl = st_foc->st_sc.f4_speed_rad;

        /*===============*/
        /*   Set angle   */
        /*===============*/
        f4_angle_rad = st_foc->f4_rslv_angle_rad;

        if (MTR_ENABLE == st_foc->u1_flag_angle_spl_comp_use)
        {
            f4_angle_rad = mtr_angle_spl_comp(&st_foc->st_rcomp,
                                              st_foc->u1_direction,
                                              f4_angle_rad,
                                              st_foc->st_sc.f4_speed_rad_ctrl);
        }

        /* limit angle value of one rotation */
        if(f4_angle_rad >= MTR_TWOPI)
        {
            f4_angle_rad -= MTR_TWOPI;
        }
        else if(f4_angle_rad < 0.0f)
        {
            f4_angle_rad += MTR_TWOPI;
        }
        else
        {
            /* Do Nothing */
        }
        st_foc->st_rcomp.f4_pre_angle_rad = f4_angle_rad;

        /*===================*/
        /*   Set position   */
        /*==================*/
        st_foc->st_pc.f4_pos_rad = st_foc->f4_rslv_pos_rad
                                 + ((st_foc->st_rcomp.f4_angle_comp_rad + st_foc->st_rcomp.f4_over_corr_comp_angle_rad)
                                 * (float)MTR_RSLV_POLE_INV);
    }
    else if ((MTR_MODE_DRIVE == st_foc->u2_run_mode) && (MTR_LOOP_CURRENT_ID == st_foc->u1_ctrl_loop_mode))
    {
        st_foc->st_sc.f4_speed_rad = 0.0f;
        st_foc->f4_open_loop_pos_rad = st_foc->f4_open_loop_pos_rad + (float)(MTR_CTRL_PERIOD * st_foc->st_sc.f4_ref_speed_rad_ctrl);

        /* limit angle value of one rotation */
        if(st_foc->f4_open_loop_pos_rad >= MTR_TWOPI)
        {
            st_foc->f4_open_loop_pos_rad -= MTR_TWOPI;
        }
        else if(st_foc->f4_open_loop_pos_rad < 0.0f)
        {
            st_foc->f4_open_loop_pos_rad += MTR_TWOPI;
        }
        else
        {
            /* Do Nothing */
        }
        f4_angle_rad = st_foc->f4_open_loop_pos_rad;
    }
    else
    {
        /* Do Nothing */
    }

   /*========================*/
   /*   Update rotor angle   */
   /*========================*/
   mtr_rotor_angle_update(&st_foc->st_rotor_angle, f4_angle_rad);
} /* End of function mtr_angle_speed */

/***********************************************************************************************************************
* Function Name : mtr_decide_direction
* Description   : Decide direction
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_decide_direction(mtr_foc_control_t *st_foc)
{
    if (0.0f <= st_foc->st_sc.f4_speed_rad)
    {
        st_foc->u1_direction = MTR_CW;
    }
    else if (0.0f > st_foc->st_sc.f4_speed_rad)
    {
        st_foc->u1_direction = MTR_CCW;
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function mtr_decide_direction */

/***********************************************************************************************************************
* Function Name : mtr_set_pos_ref
* Description   : Set position reference
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : position reference
***********************************************************************************************************************/
float mtr_set_pos_ref(mtr_foc_control_t *st_foc)
{
    float f4_ref_pos_rad_calc;

    switch (st_foc->u1_state_pos_ref)
    {
        case MTR_POS_ZERO_CONST:
        {
            /* position zero constant */
            f4_ref_pos_rad_calc = 0.0f;
        }
        break;

        case MTR_POS_STEP:
        {
            /* update reference position */
            f4_ref_pos_rad_calc = st_foc->st_pc.f4_ref_pos_rad;
        }
        break;

        case MTR_POS_TRAPEZOID:
        {
            /* check reference position update */
            if (st_foc->st_pc.f4_ref_pos_pre_rad != st_foc->st_pc.f4_ref_pos_rad)
            {
                st_foc->st_ppf.f4_pos_st_rad = st_foc->st_pc.f4_ref_pos_pre_rad;
                st_foc->st_ppf.f4_pos_ed_rad = st_foc->st_pc.f4_ref_pos_rad;
                st_foc->st_pc.f4_ref_pos_pre_rad = st_foc->st_pc.f4_ref_pos_rad;
            }
        }
        break;

        default:
        {
            /* Do Nothing */
        }
        break;
    }

    if(MTR_POS_TRAPEZOID == st_foc->u1_state_pos_ref)
    {
        /* profiling reference position (trapezoid control) */
        f4_ref_pos_rad_calc = mtr_position_profile(&st_foc->st_ppf);
    }

    /* return speed reference */
    return (f4_ref_pos_rad_calc);
} /* End of function mtr_set_pos_ref */

/***********************************************************************************************************************
* Function Name : mtr_position_deadband_set
* Description   : Set position dead-band
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
static inline float mtr_position_deadband_set(mtr_foc_control_t *st_foc, float f4_pos_err_rad)
{
    float f4_temp0;

    f4_temp0 = fabsf(f4_pos_err_rad);
    /* this variable will never reference memory over. */
    if (((float)st_foc->st_pc.u2_pos_dead_band * gs_st_ctrl_input_buff.f4_rslv_angle_diff) >= f4_temp0)
    {
        f4_pos_err_rad = 0.0f;
    }

    return (f4_pos_err_rad);
} /* End of function mtr_position_deadband_set */

/***********************************************************************************************************************
* Function Name : mtr_set_speed_ref
* Description   : Updates the speed reference
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : Speed reference
***********************************************************************************************************************/
float mtr_set_speed_ref(mtr_foc_control_t *st_foc)
{
    float f4_speed_ref_calc_rad;
    float f4_speed_ff_rad;
    float f4_temp0;

    switch (st_foc->u1_state_speed_ref)
    {
        case MTR_SPEED_ZERO_CONST:
        {
            f4_speed_ref_calc_rad = 0.0f;
        }
        break;

        case MTR_POS_CONTROL_OUTPUT:
        {
            /* Check control method mode */
            if (MTR_CTRL_PID == st_foc->u1_ctrl_method_mode)
            {
                st_foc->st_pc.f4_pos_err_rad = st_foc->st_pc.f4_ref_pos_rad_ctrl - st_foc->st_pc.f4_pos_rad;
                st_foc->st_pc.f4_pos_err_rad = mtr_position_deadband_set(st_foc, st_foc->st_pc.f4_pos_err_rad);
                f4_speed_ref_calc_rad = mtr_p_ctrl_pos(&st_foc->st_pc,
                                                       &st_foc->st_motor,
                                                       st_foc->st_pc.f4_pos_err_rad);
            }
            else if (MTR_CTRL_IPD == st_foc->u1_ctrl_method_mode)
            {
                st_foc->st_pc.f4_pos_err_rad = mtr_ipd_error_calc(&st_foc->st_ipd,
                                                                st_foc->st_pc.f4_pos_rad,
                                                                st_foc->st_pc.f4_ref_pos_rad_ctrl);
                st_foc->st_pc.f4_pos_err_rad = mtr_position_deadband_set(st_foc, st_foc->st_pc.f4_pos_err_rad);
                f4_speed_ref_calc_rad = mtr_ipd_ctrl(&st_foc->st_ipd,
                                                     &st_foc->st_motor,
                                                     st_foc->st_pc.f4_pos_err_rad,
                                                     st_foc->st_pc.f4_pos_rad,
                                                     st_foc->st_sc.f4_max_speed_rad);
            }
            else
            {
                /* Do Nothing */
            }
            /* Speed Reference Profiling mode */
            if (MTR_POS_TRAPEZOID == st_foc->u1_state_pos_ref)
            {
                /* Speed feed-forward control */
                f4_speed_ff_rad = mtr_speed_profile_feed_forward(&st_foc->st_ppf);
                f4_speed_ref_calc_rad = mtr_speed_feed_foward_control(&st_foc->st_pc,
                                                                      f4_speed_ff_rad,
                                                                      f4_speed_ref_calc_rad,
                                                                      st_foc->st_motor.u2_mtr_pp);
            }
            else if (MTR_POS_STEP == st_foc->u1_state_pos_ref)
            {
                /* Speed feed-forward control */
                f4_temp0 = st_foc->st_pc.f4_ref_pos_rad_ctrl - st_foc->st_pc.f4_ref_pos_pre_rad;
                f4_speed_ff_rad = f4_temp0 / st_foc->st_sc.f4_speed_ctrl_period;
                f4_speed_ref_calc_rad = mtr_speed_feed_foward_control(&st_foc->st_pc,
                                                                      f4_speed_ff_rad,
                                                                      f4_speed_ref_calc_rad,
                                                                      st_foc->st_motor.u2_mtr_pp);
                st_foc->st_pc.f4_ref_pos_pre_rad = st_foc->st_pc.f4_ref_pos_rad_ctrl;
            }
            else
            {
                /* Do Nothing */
            }
        }
        break;

        case MTR_SPEED_MANUAL:
        {
            f4_speed_ref_calc_rad = mtr_speed_rate_limit(&st_foc->st_sc);
        }
        break;

        default:
        {
            /* Do Nothing */
        }
        break;
    }
    /* speed reference limit */
    if(MTR_POS_CONTROL_OUTPUT == st_foc->u1_state_speed_ref)
    {
        f4_speed_ref_calc_rad = mtr_com_limitfAbs(f4_speed_ref_calc_rad, st_foc->st_sc.f4_max_speed_rad * 1.2f);
    }
    else
    {
        f4_speed_ref_calc_rad = mtr_com_limitfAbs(f4_speed_ref_calc_rad, st_foc->st_sc.f4_max_speed_rad);
    }

    /* return speed reference */
    return (f4_speed_ref_calc_rad);
} /* End of function mtr_set_speed_ref */

/***********************************************************************************************************************
* Function Name : mtr_set_iq_ref
* Description   : Updates the q-axis current reference
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : Iq reference
***********************************************************************************************************************/
float mtr_set_iq_ref(mtr_foc_control_t *st_foc)
{
    float f4_ref_iq_calc;
    float f4_temp0;
    float f4_temp1;

    switch (st_foc->u1_state_iq_ref)
    {
        case MTR_IQ_ZERO_CONST:
        {
            /*** constant zero set ***/
            f4_ref_iq_calc = 0.0f;
        }
        break;

        case MTR_IQ_SPEED_PI_OUTPUT:
        {
            /*** speed PI control ***/
            if (MTR_CTRL_PID == st_foc->u1_ctrl_method_mode)
            {
                f4_ref_iq_calc = mtr_speed_pi_control(&st_foc->st_sc, st_foc->st_sc.f4_speed_rad_ctrl);
            }
            else if (MTR_CTRL_IPD == st_foc->u1_ctrl_method_mode)
            {
                f4_ref_iq_calc = mtr_ipd_speed_p_ctrl(&st_foc->st_ipd,
                                                      st_foc->st_sc.f4_ref_speed_rad_ctrl,
                                                      st_foc->st_sc.f4_speed_rad_ctrl);
            }
            else
            {
                /* Do Nothing */
            }
        }
        break;

        case MTR_IQ_MANUAL:
        {
            f4_temp0 = st_foc->st_cc.f4_ref_iq - st_foc->st_cc.f4_ref_iq_ctrl;
            f4_temp1 = fminf(st_foc->st_cc.f4_current_rate_limit, fabsf(f4_temp0));
            f4_ref_iq_calc = st_foc->st_cc.f4_ref_iq_ctrl + copysignf(f4_temp1, f4_temp0);
        }
        break;

        default:
        {
            /* Do Nothing */
        }
        break;
    }

    /*** iq reference limit ***/
    f4_ref_iq_calc = mtr_com_limitfAbs(f4_ref_iq_calc, st_foc->st_cc.f4_lim_iq);

    /* return iq reference */
    return (f4_ref_iq_calc);
} /* End of function mtr_set_iq_ref */

/***********************************************************************************************************************
* Function Name : mtr_set_id_ref
* Description   : Updates the d-axis current reference
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : Id reference
***********************************************************************************************************************/
float mtr_set_id_ref(mtr_foc_control_t *st_foc)
{
    float f4_ref_id_calc;
    float f4_temp0;
    float f4_temp1;

    switch (st_foc->u1_state_id_ref)
    {
        case MTR_ID_ZERO_CONST:
        case MTR_ID_FLUXWKN:
        {
            f4_ref_id_calc = 0;
            if (MTR_ENABLE == st_foc->u1_flag_flux_weakening_use)
            {
                /* Enables the Flux-weakening when the open-loop has completely ended */
                if (FLUXWKN_STATE_BYPASSED != mtr_fluxwkn_GetStatus(&st_foc->st_fluxwkn))
                {
                    st_foc->u1_state_id_ref = MTR_ID_FLUXWKN;
                }
                else
                {
                    st_foc->u1_state_id_ref = MTR_ID_ZERO_CONST;
                }
            }
        }
        break;

        case MTR_ID_MANUAL:
        {
            f4_temp0 = st_foc->st_cc.f4_ref_id - st_foc->st_cc.f4_ref_id_ctrl;
            f4_temp1 = fminf(st_foc->st_cc.f4_current_rate_limit, fabsf(f4_temp0));
            f4_ref_id_calc = st_foc->st_cc.f4_ref_id_ctrl + copysignf(f4_temp1, f4_temp0);
        }
        break;

        default:
        {
            /* Do Nothing */
        }
        break;
    }

    /* return id reference */
    return (f4_ref_id_calc);
} /* End of function mtr_set_id_ref */

/***********************************************************************************************************************
* Function Name : mtr_pos_offset_adjust
* Description   : Position offset adjustment
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : Id reference
***********************************************************************************************************************/
float mtr_pos_offset_adjust(mtr_foc_control_t *st_foc)
{
    float f4_id_ref;

    st_foc->st_cc.f4_ref_id = st_foc->st_motor.f4_nominal_current_rms * MTR_SQRT_2 * MTR_OFFSET_ALIGN_ID_RATIO;

    if (st_foc->st_cc.f4_ref_id == st_foc->st_cc.f4_ref_id_ctrl)
    {
        st_foc->u2_angle_adj_cnt++;
    }

    f4_id_ref = mtr_set_id_ref(st_foc);
    if (st_foc->u2_angle_adj_cnt >= st_foc->u2_angle_adj_time)
    {
        /* angle adjusted to 90 degree */
        if (MTR_ANGLE_ADJ_90DEG == st_foc->u1_state_angle_adj)
        {
            /* repeat soft start */
            f4_id_ref = 0.0f;
            st_foc->u1_state_angle_adj = MTR_ANGLE_ADJ_0DEG;
            st_foc->u2_angle_adj_cnt = 0;
            st_foc->u2_cnt_adjust = 0;
            st_foc->f4_rslv_angle_offset_sum_rad = 0.0f;
            st_foc->f4_rslv_angle_offset_rad = 0.0f;
        }
        /* angle adjusted to 0 degree */
        else if (MTR_ANGLE_ADJ_0DEG == st_foc->u1_state_angle_adj)
        {
            if((st_foc->u2_offset_calc_time + st_foc->u2_offset_calc_wait) <= st_foc->u2_cnt_adjust)
            {
                /* Angle offset variables store */
                st_foc->f4_rslv_angle_offset_rad = st_foc->f4_rslv_angle_offset_sum_rad / st_foc->u2_offset_calc_time;
                st_foc->u2_rslv_angle_offset_cnt = (uint16_t)(st_foc->f4_rslv_angle_offset_rad * gs_st_ctrl_input_buff.f4_esig_cnt * MTR_TWOPI_INV);
                st_foc->u2_angle_adj_cnt = 0;

                /* Angle offset adjust finish */
                st_foc->u1_state_angle_adj = MTR_ANGLE_ADJ_FIN;
            }
            else
            {
                if(st_foc->u2_cnt_adjust >= st_foc->u2_offset_calc_wait)
                {
                    st_foc->f4_rslv_angle_offset_sum_rad += st_foc->f4_rslv_angle_rad;
                }
            }
            st_foc->u2_cnt_adjust++;
        }
        else if(MTR_ANGLE_ADJ_FIN == st_foc->u1_state_angle_adj)
        {
            f4_id_ref = 0.0f;
            st_foc->u2_angle_adj_cnt = 0;
            st_foc->u1_offset_adjust_mode = MTR_OFAJ_FIN;
            /* Execute stop event */
            st_foc->u1_flag_mode_inactive = MTR_ENABLE;
        }
        else
        {
            /* Do Nothing */
        }
    }
    else
    {
        /* Do Nothing */
    }

    return (f4_id_ref);
} /* End of function mtr_pos_offset_adjust */

/***********************************************************************************************************************
* Function Name : mtr_set_ref_state
* Description   : Set references state
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : none
***********************************************************************************************************************/
void mtr_set_ref_state(mtr_foc_control_t *st_foc)
{
    /* Setting of references state */
    switch (st_foc->u2_run_mode)
    {
        case MTR_MODE_OFFSET_ADJUST:
        {
            st_foc->u1_offset_adjust_mode = st_foc->u1_offset_adjust_mode_buff;
            mtr_set_param_current_rate_limit(&st_foc->st_cc, MTR_RATE_LIMIT_CURRENT);
            st_foc->st_cc.f4_ref_id = MTR_REF_ID;
            st_foc->u1_state_id_ref = MTR_ID_MANUAL;
        }
        break;

        case MTR_MODE_DRIVE:
        {
            st_foc->u1_offset_adjust_mode = MTR_OFAJ_FIN;
            switch (st_foc->u1_ctrl_loop_mode)
            {
                /* Current Loop mode (ID) */
                case MTR_LOOP_CURRENT_ID:
                {
                    st_foc->u1_state_pos_ref   = MTR_POS_ZERO_CONST;
                    st_foc->u1_state_speed_ref = MTR_SPEED_MANUAL;
                    st_foc->u1_state_iq_ref    = MTR_IQ_ZERO_CONST;
                    st_foc->u1_state_id_ref    = MTR_ID_MANUAL;
                }
                break;
                /* Current Loop mode (IQ) */
                case MTR_LOOP_CURRENT_IQ:
                {
                    st_foc->u1_state_pos_ref   = MTR_POS_ZERO_CONST;
                    st_foc->u1_state_speed_ref = MTR_SPEED_ZERO_CONST;
                    st_foc->u1_state_iq_ref    = MTR_IQ_MANUAL;
                    st_foc->u1_state_id_ref    = MTR_ID_ZERO_CONST;
                }
                break;
                /* Speed Loop mode */
                case MTR_LOOP_SPEED:
                {
                    st_foc->u1_state_pos_ref   = MTR_POS_ZERO_CONST;
                    st_foc->u1_state_speed_ref = MTR_SPEED_MANUAL;
                    st_foc->u1_state_iq_ref    = MTR_IQ_SPEED_PI_OUTPUT;
                    st_foc->u1_state_id_ref    = MTR_ID_ZERO_CONST;
                }
                break;
                /* Position Loop mode */
                case MTR_LOOP_POSITION:
                {
                    st_foc->u1_state_pos_ref   = st_foc->u1_state_pos_ref_buff;
                    st_foc->u1_state_speed_ref = MTR_POS_CONTROL_OUTPUT;
                    st_foc->u1_state_iq_ref    = MTR_IQ_SPEED_PI_OUTPUT;
                    st_foc->u1_state_id_ref    = MTR_ID_ZERO_CONST;
                }
                break;

                default:
                {
                    /* Do Nothing */
                }
                break;
            }
        }
        break;

        default:
        {
            /* Do Nothing */
        }
        break;
    }
} /* End of function mtr_set_ref_state */

/***********************************************************************************************************************
* Function Name : mtr_check_over_speed_error
* Description   : Checks over-speed error
* Arguments     : f4_speed_rad - The electrical speed[rad/s]
*                 f4_speed_limit_rad - The speed[rad/s] threshold of the over-speed error, should be a positive value
* Return Value  : The over-speed error flag
***********************************************************************************************************************/
static inline uint16_t mtr_check_over_speed_error(float f4_speed_rad, float f4_overspeed_limit_rad)
{
    float f4_temp0;
    uint16_t u2_temp0;

    u2_temp0 = MTR_ERROR_NONE;

    f4_temp0 = fabsf(f4_speed_rad);
    if (f4_temp0 > f4_overspeed_limit_rad)
    {
        /* Over speed error */
        u2_temp0 = MTR_ERROR_OVER_SPEED;
    }

    return (u2_temp0);
} /* End of function mtr_check_over_speed_error */

/***********************************************************************************************************************
* Function Name : mtr_check_over_voltage_error
* Description   : Checks over-voltage error
* Arguments     : f4_vdc - The actual Vdc value [V]
                  f4_overvoltage_limit - The threshold voltage[V] of over-voltage error
* Return Value  : The flag of over-voltage error
***********************************************************************************************************************/
static inline uint16_t mtr_check_over_voltage_error(float f4_vdc, float f4_overvoltage_limit)
{
    uint16_t u2_temp0;

    u2_temp0 = MTR_ERROR_NONE;

    if (f4_vdc > f4_overvoltage_limit)
    {
        /* Over voltage error */
        u2_temp0 = MTR_ERROR_OVER_VOLTAGE;
    }

    return (u2_temp0);
} /* End of function mtr_check_over_voltage_error */

/***********************************************************************************************************************
* Function Name : mtr_check_under_voltage_error
* Description   : Checks under-voltage error
* Arguments     : f4_vdc - The actual Vdc value [V]
                  f4_undervoltage_limit - The threshold voltage[V] of under-voltage error
* Return Value  : The flag of under-voltage error
***********************************************************************************************************************/
static inline uint16_t mtr_check_under_voltage_error(float f4_vdc, float f4_undervoltage_limit)
{
    uint16_t u2_temp0;

    u2_temp0 = MTR_ERROR_NONE;

    if (f4_vdc < f4_undervoltage_limit)
    {
        /* Under voltage error */
        u2_temp0 = MTR_ERROR_UNDER_VOLTAGE;
    }

    return (u2_temp0);
} /* End of function mtr_check_under_voltage_error */

/***********************************************************************************************************************
* Function Name : mtr_check_over_current_error_iaib
* Description   : Checks over-current error
* Arguments     : f4_ia - The actual U-phase current value [A]
*                 f4_ib - The actual V-phase current value [A]
*                 f4_overcurrent_limit - The threshold current[A] of over-current error
* Return Value  : The flag of over-current error
***********************************************************************************************************************/
static inline uint16_t mtr_check_over_current_error_iaib(float f4_ia, float f4_ib, float f4_overcurrent_limit)
{
    float f4_temp0;
    uint16_t u2_temp0;

    /* Initialize */
    u2_temp0 = MTR_ERROR_NONE;

    f4_temp0 = fabsf(f4_ia);
    u2_temp0 |= (f4_temp0 > f4_overcurrent_limit);
    f4_temp0 = fabsf(f4_ib);
    u2_temp0 |= (f4_temp0 > f4_overcurrent_limit);

    u2_temp0 *= MTR_ERROR_OVER_CURRENT_SW;

    return (u2_temp0);
} /* End of function mtr_check_over_current_error_iaib */

/***********************************************************************************************************************
* Function Name : mtr_error_check
* Description   : Checks the errors
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_error_check(mtr_foc_control_t *st_foc)
{
    uint16_t u2_error_flags = 0;

    /*==============================*/
    /*   Over current error check   */
    /*==============================*/
    u2_error_flags |= mtr_check_over_current_error_iaib(st_foc->f4_ia_ad,
                                                        st_foc->f4_ib_ad,
                                                        st_foc->f4_overcurrent_limit);
    /*==============================*/
    /*   Over voltage error check   */
    /*==============================*/
    u2_error_flags |= mtr_check_over_voltage_error(st_foc->f4_vdc_ad,
                                                   st_foc->f4_overvoltage_limit);
    /*===============================*/
    /*   Under voltage error check   */
    /*===============================*/
    if (MTR_FLG_SET == st_foc->u1_flag_charge_cap)    /* Check "capacitor charge completed" */
    {
        u2_error_flags |= mtr_check_under_voltage_error(st_foc->f4_vdc_ad, st_foc->f4_undervoltage_limit);
    }
    /*============================*/
    /*   Over speed error check   */
    /*============================*/
    u2_error_flags |= mtr_check_over_speed_error(st_foc->st_sc.f4_speed_rad, st_foc->f4_overspeed_limit_rad);

    if (MTR_ERROR_NONE != u2_error_flags)
    {
        mtr_foc_error(st_foc, u2_error_flags);        /* Execute error event */
    }
} /* End of function mtr_error_check */

/***********************************************************************************************************************
* Function Name : mtr_over_current
* Description   : POE interrupt
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_over_current(mtr_foc_control_t *st_foc)
{
    mtr_foc_error(st_foc, MTR_ERROR_OVER_CURRENT_HW);

    mtr_clear_oc_flag();                              /* Clear forced cutoff flag (detect over current) */
} /* End of function mtr_over_current */

/***********************************************************************************************************************
* Function Name : mtr_rdc_alarm
* Description   : RDC ARARM
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_rdc_alarm(mtr_foc_control_t *st_foc)
{
    mtr_foc_error(st_foc, MTR_ERROR_RDC);

} /* End of function mtr_rdc_alarm */

/***********************************************************************************************************************
* Function Name : mtr_foc_voltage_limit
* Description   : Limit voltage vector, d-axis voltage has higher priority than q-axis voltage
* Arguments     : p_foc - The pointer to the FOC structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_voltage_limit(mtr_foc_control_t *p_foc)
{
    float f4_va_max;
    float f4_vd_max;
    float f4_vq_lim;
    float f4_ref_vd;

    f4_va_max = mtr_mod_GetVamax(&p_foc->st_mod);
    f4_vd_max = f4_va_max;
    f4_ref_vd = p_foc->st_cc.f4_ref_vd;

    /* The d-axis voltage has high priority than the q-axis */
    /* If absolute value of D-axis voltage exceeds maximum voltage, limit it to the maximum voltage */
    if (f4_ref_vd > f4_vd_max)
    {
        f4_ref_vd = f4_vd_max;
    }
    else if (f4_ref_vd < (-f4_vd_max))
    {
        f4_ref_vd = -f4_vd_max;
    }
    f4_vq_lim = sqrtf((f4_va_max * f4_va_max) - (f4_ref_vd *  f4_ref_vd));
    p_foc->st_cc.f4_ref_vd = f4_ref_vd;
    p_foc->st_cc.f4_ref_vq = mtr_com_limitfAbs(p_foc->st_cc.f4_ref_vq, f4_vq_lim);
} /* End of function mtr_foc_voltage_limit */

/***********************************************************************************************************************
* Function Name : mtr_foc_voltage_limit_ab
* Description   : Limit voltage vector for ab-axis
* Arguments     : p_foc - The pointer to the FOC structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_voltage_limit_ab(float *f4_v_ab, float f4_vdc)
{
    float f4_temp_vdc;

    f4_temp_vdc = f4_vdc;

    if(f4_v_ab[0] >= f4_temp_vdc)
    {
        f4_v_ab[0] = f4_temp_vdc;
    }
    else if(f4_v_ab[0] <= (-f4_temp_vdc))
    {
        f4_v_ab[0] = (-f4_temp_vdc);
    }

    if(f4_v_ab[1] >= f4_temp_vdc)
    {
        f4_v_ab[1] = f4_temp_vdc;
    }
    else if(f4_v_ab[1] <= (-f4_temp_vdc))
    {
        f4_v_ab[1] = (-f4_temp_vdc);
    }

} /* End of function mtr_foc_voltage_limit_ab */

/***********************************************************************************************************************
* Function Name : mtr_foc_set_nominal_current
* Description   : Setup current related limit values by the nominal current of motor
* Arguments     : st_cc - The pointer to the FOC current control structure
*                 f4_nominal_current_rms - The nominal current[Arms] of motor
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_set_nominal_current(mtr_foc_control_t *st_foc, float f4_nominal_current_rms)
{
    float f4_ia_max;

    f4_ia_max = f4_nominal_current_rms * MTR_SQRT_2;
    st_foc->f4_overcurrent_limit = (f4_nominal_current_rms * MTR_SQRT_2) * MTR_OVERCURRENT_MARGIN_MULT;
    if (st_foc->f4_overcurrent_limit > IP_CURRENT_LIMIT)
    {
        st_foc->f4_overcurrent_limit = IP_CURRENT_LIMIT;
    }
    st_foc->st_sc.st_pi_speed.f4_ilimit = f4_ia_max;
    st_foc->st_cc.f4_lim_iq = f4_ia_max;

    if (MTR_ENABLE == st_foc->u1_flag_flux_weakening_use)
    {
        mtr_fluxwkn_SetIamax(&st_foc->st_fluxwkn, f4_ia_max);
    }
} /* End of function mtr_foc_set_nominal_current */

/***********************************************************************************************************************
* Function Name : mtr_flux_weakng
* Description   : Executes the flux-weakening
* Arguments     : st_foc - The pointer to the FOC data structure
*                 f4_idq_ref - The pointer to the reference current vector (array) in format {Idref, Iqref}
* Return Value  : None
***********************************************************************************************************************/
void  mtr_flux_weakng( mtr_foc_control_t *st_foc, float *f4_idq_ref )
{
    /* This function will over-write the dq-axis current command */
    mtr_fluxwkn_SetVamax(&st_foc->st_fluxwkn, mtr_mod_GetVamax(&st_foc->st_mod));
    if(0.0f != st_foc->st_sc.f4_speed_rad_ctrl)
    {
        mtr_fluxwkn_run(&st_foc->st_fluxwkn, st_foc->st_sc.f4_speed_rad_ctrl, &st_foc->st_cc.f4_id_ad, f4_idq_ref);
    }
    if (f4_idq_ref[0] > 0.0f)
    {
        f4_idq_ref[0] = 0.0f;
    }
} /* End of function mtr_flux_weakng */
