/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : r_mtr_variables.c
 * Version      : 1.00
 * Description  :
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * History : DD.MM.YYYY Version
 *           23.04.2021 1.31     First Release
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Includes <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include <stdint.h>

#include "r_mtr_variables.h"
#include "r_mtr_stm_rslv_foc_rx_if.h"

extern mtr_ctrl_input_t gs_st_ctrl_input_buff;     /* Structure for ICS input */

/**********************************************************************************************************************
 * Function Name: mtr_SetVariables
 * Description  : Set control input buffer to motor control structure members
 * Arguments    : None
 * Return Value : None
 *********************************************************************************************************************/
void mtr_SetVariables(mtr_foc_control_t * p_st_mtr)
{
    /*====================*/
    /*   FOC structure   */
    /*====================*/
    /* Setup flags whether use resolver position error compensation */
    p_st_mtr->u1_flag_angle_spl_comp_use = gs_st_ctrl_input_buff.u1_flag_angle_spl_comp_use;

    /* Setup flags whether use current control sampling delay compensation */
    p_st_mtr->u1_flag_cc_spl_comp_use = gs_st_ctrl_input_buff.u1_flag_cc_spl_comp_use;

    /* Setup flags whether use speed observer */
    p_st_mtr->u1_flag_sob_use = gs_st_ctrl_input_buff.u1_flag_sob_use;

    /* Setup flags_whether use voltage error compensation */
    p_st_mtr->u1_flag_volt_err_comp_use = gs_st_ctrl_input_buff.u1_flag_volt_err_comp_use;

    /* Flags_whether use flux-weakening */
    p_st_mtr->u1_flag_flux_weakening_use = gs_st_ctrl_input_buff.u1_flag_flux_weakening_use;
    if (MTR_MODE_INACTIVE == mtr_statemachine_get_status(&p_st_mtr->st_stm))
    {
        /* Setup control loop select */
        p_st_mtr->u1_ctrl_loop_mode = gs_st_ctrl_input_buff.u1_ctrl_loop_mode_buff;
        /* Setup RUN MODE */
        p_st_mtr->u2_run_mode = gs_st_ctrl_input_buff.u2_run_mode;
    }

    /* Setup control method select */
    if (MTR_LOOP_SPEED == p_st_mtr->u1_ctrl_loop_mode)
    {
        p_st_mtr->u1_ctrl_method_mode = MTR_CTRL_PID;
    }
    else if (MTR_LOOP_POSITION == p_st_mtr->u1_ctrl_loop_mode)
    {
        p_st_mtr->u1_ctrl_method_mode = gs_st_ctrl_input_buff.u1_ctrl_method_mode;
    }
    else
    {
        /* Do Nothing */
    }
    /* Setup position command value management */
    p_st_mtr->u1_state_pos_ref = gs_st_ctrl_input_buff.u1_state_pos_ref_buff;

    /* Offset adjust mode */
    p_st_mtr->u1_offset_adjust_mode_buff = gs_st_ctrl_input_buff.u1_offset_adjust_mode_buff;

    /* Setup motor parameter */
    p_st_mtr->st_motor = gs_st_ctrl_input_buff.st_motor;

    /* Setup current offset calculation time */
    p_st_mtr->u2_offset_calc_time = gs_st_ctrl_input_buff.u2_offset_calc_time;

    /* Counter for current offset detection start timing */
    p_st_mtr->u2_offset_calc_wait = gs_st_ctrl_input_buff.u2_offset_calc_wait;

    /* Setup nominal current */
    mtr_foc_set_nominal_current(p_st_mtr, gs_st_ctrl_input_buff.st_motor.f4_nominal_current_rms);

    /* Setup flux weakening parameter */
    if(MTR_ENABLE == p_st_mtr->u1_flag_flux_weakening_use)
    {
        mtr_fluxwkn_SetMotor(&p_st_mtr->st_fluxwkn ,&p_st_mtr->st_motor);
    }

    /*================================*/
    /*   Current control structure   */
    /*================================*/
    /* Setup reference d-axis current [A] */
    mtr_set_param_ref_id(&p_st_mtr->st_cc, gs_st_ctrl_input_buff.f4_ref_id);

    /* Setup reference q-axis current [A] */
    mtr_set_param_ref_iq(&p_st_mtr->st_cc, gs_st_ctrl_input_buff.f4_ref_iq);

    /* Limit of q-axis current change */
    mtr_set_param_current_rate_limit(&p_st_mtr->st_cc, gs_st_ctrl_input_buff.f4_current_rate_limit);

    /*==============================*/
    /*   Speed control structure   */
    /*==============================*/
    /* Setup rotation direction */
    mtr_set_param_ref_dir(&p_st_mtr->st_sc,gs_st_ctrl_input_buff.u1_direction);

    /* [rpm]->[rad/s]*/
    mtr_set_param_rpm_to_rad(&p_st_mtr->st_sc, p_st_mtr->st_motor.u2_mtr_pp);

    /* Setup reference speed */
    mtr_set_param_ref_speed(&p_st_mtr->st_sc, gs_st_ctrl_input_buff.s2_ref_speed_rpm);

    /* Setup max speed */
    mtr_set_param_max_speed(&p_st_mtr->st_sc, gs_st_ctrl_input_buff.u2_max_speed_rpm);

    /* Setup limit of speed change */
    mtr_set_param_speed_rate_limit(&p_st_mtr->st_sc, gs_st_ctrl_input_buff.f4_speed_rate_limit);

    /* Setup over-speed limit */
    p_st_mtr->f4_overspeed_limit_rad = (float)(gs_st_ctrl_input_buff.u2_speed_limit_rpm * p_st_mtr->st_sc.f4_rpm_rad);

    /*=================================*/
    /*   Position control structure   */
    /*=================================*/
    /* Setup motor position dead-band */
    mtr_set_param_pos_dead_band(&p_st_mtr->st_pc, gs_st_ctrl_input_buff.u2_pos_dead_band);

    /* Setup positioning band limit */
    mtr_set_param_pos_band_limit(&p_st_mtr->st_pc, gs_st_ctrl_input_buff.u2_pos_band_limit);

    /* Setup reference position */
    mtr_set_param_reference_position(&p_st_mtr->st_pc, gs_st_ctrl_input_buff.f4_ref_position_deg);

    /*===================================*/
    /*   Position profiling structure   */
    /*===================================*/
    /* Setup interval time for reference position update */
    mtr_set_param_interval_time(&p_st_mtr->st_ppf, gs_st_ctrl_input_buff.u2_pos_interval_time);

    /* Setup acceleration time */
    mtr_set_param_accel_time(&p_st_mtr->st_ppf, gs_st_ctrl_input_buff.f4_accel_time);

    /* Setup reference max speed */
    mtr_set_param_accel_max_speed(&p_st_mtr->st_ppf, gs_st_ctrl_input_buff.u2_max_speed_rpm);

    /* Setup max acceleration time */
    mtr_set_param_max_accel_time(&p_st_mtr->st_ppf,
                                 &gs_st_ctrl_input_buff.st_motor);

    /*============================*/
    /*   IPD control structure   */
    /*============================*/
    /* Setup position control gain ratio for I-PD */
    mtr_set_param_pos_kp_ratio(&p_st_mtr->st_ipd, gs_st_ctrl_input_buff.f4_ipd_pos_kp_ratio);

    /* Setup speed gain ratio for I-PD */
    mtr_set_param_speed_k_ratio(&p_st_mtr->st_ipd, gs_st_ctrl_input_buff.f4_ipd_speed_k_ratio);

    /* Setup position error limit */
    mtr_set_param_err_limit_1(&p_st_mtr->st_ipd, gs_st_ctrl_input_buff.f4_ipd_err_limit_1);
    mtr_set_param_err_limit_2(&p_st_mtr->st_ipd, gs_st_ctrl_input_buff.f4_ipd_err_limit_2);

    /*=====================================*/
    /*   Resolver compensation structure   */
    /*=====================================*/
    /* Setup BPF delay compensation gain for cw */
    mtr_set_param_bpf_comp_gain_cw(&p_st_mtr->st_rcomp, gs_st_ctrl_input_buff.f4_bpf_comp_gain_cw);

    /* Setup BPF delay compensation gain for ccw */
    mtr_set_param_bpf_comp_gain_ccw(&p_st_mtr->st_rcomp, gs_st_ctrl_input_buff.f4_bpf_comp_gain_ccw);

    /* Setup BPF delay compensation gain for cw */
    mtr_set_param_bpf_comp_base_cw(&p_st_mtr->st_rcomp, gs_st_ctrl_input_buff.f4_bpf_comp_base_cw);

    /* Setup BPF delay compensation gain for ccw */
    mtr_set_param_bpf_comp_base_ccw(&p_st_mtr->st_rcomp, gs_st_ctrl_input_buff.f4_bpf_comp_base_ccw);
}
/**********************************************************************************************************************
 * End of function mtr_SetVariables
 *********************************************************************************************************************/

