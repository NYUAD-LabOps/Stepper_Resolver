/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_parameter.h
* Description : Definitions of parameters used in control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MTR_PARAMETER_H
#define R_MTR_PARAMETER_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "r_mtr_config.h"
#include "r_mtr_motor_parameter.h"
#include "r_mtr_control_parameter.h"
#include "r_mtr_inverter_parameter.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Motor parameter */
#define MTR_M                        (MP_MAGNETIC_FLUX)           /* Permanent magnetic flux [Wb] */
#define MTR_R                        (MP_RESISTANCE)              /* Resistance [ohm] */
#define MTR_LD                       (MP_D_INDUCTANCE)            /* D-axis inductance [H] */
#define MTR_LQ                       (MP_Q_INDUCTANCE)            /* Q-axis inductance [H] */
#define MTR_J                        (MP_ROTOR_INERTIA)           /* Rotor inertia [kgm^2] */
#define MTR_NOMINAL_CURRENT_RMS      (MP_NOMINAL_CURRENT_RMS)     /* The nominal current[Arms] of motor */
#define MTR_POLE_PAIRS               (MP_POLE_PAIRS)              /* Pole pairs */
#define MTR_RPM_RAD                  ((MTR_POLE_PAIRS * MTR_TWOPI) / 60.0f)
                                                                  /* [rpm]->[rad/s] */
#define MTR_TWOPI_INV                (1.0f/MTR_TWOPI)

/* Resolver and RDC parameter */
#define MTR_RSLV_TIMER_CLOCK         (MTR_PWM_TIMER_FREQ * 1000000)
                                                                  /* 80MHz */
#define MTR_RSLV_TIMER_PERIOD        ((float)(1/MTR_RSLV_TIMER_CLOCK))
                                                                  /* 1/(80MHz) */
#define MTR_RSLV_POLE                (RESOLVER_POLE)              /* Resolver pole*/
#define MTR_RSLV_POLE_INV            (1.0f/(float)MTR_RSLV_POLE)  /* reciprocal of resolver pole */
#define MTR_RSLV_ONE_CYCLE_RAD_MEC   (MTR_TWOPI/(float)MTR_RSLV_POLE)
                                                                  /* Radian of one cycle */
#define MTR_ANGLE_ADJ_TIME           (512)                        /* encoder angle adjustment time [ms] */

/* design parameter */
#define MTR_CURRENT_OMEGA            (CP_CURRENT_OMEGA)           /* Natural frequency of current loop */
#define MTR_CURRENT_ZETA             (CP_CURRENT_ZETA)            /* Damping ratio of current loop */
#define MTR_SPEED_OMEGA              (CP_SPEED_OMEGA)             /* Natural frequency of speed loop */
#define MTR_SPEED_ZETA               (CP_SPEED_ZETA)              /* Damping ratio of speed loop */
#define MTR_SPEED_LPF_OMEGA          (CP_SPEED_LPF_OMEGA)         /* Natural frequency of speed LPF */
#define MTR_POS_OMEGA                (CP_POS_OMEGA)               /* Natural frequency for position */
#define MTR_FREQ_BAND_LIMIT          (3.0f)                       /* Motor control natural frequency limit */
#define MTR_MAX_CURRENT_OMEGA        (1500.0f)                    /* Max natural frequency of current loop [Hz] */
#define MTR_MIN_POS_OMEGA            (1.0f)                       /* Min natural frequency of position loop [Hz] */

/****** Macro of current control*****/
#define MTR_DEADTIME                 (IP_DEADTIME)                /* Deadtime [us] */
#define MTR_CURRENT_RANGE            (IP_CURRENT_RANGE)           /* For current scaling */
#define MTR_VDC_RANGE                (IP_VDC_RANGE)               /* For Vdc scaling */
#define MTR_OFFSET_CALC_TIME         (256.0f)                     /* Current offset calculation time */
#define MTR_OFFSET_CALC_WAIT         ((uint16_t)(MTR_LD/MTR_R*1000.0f*10.0f*1.5f))
                                                                  /* Counter for current offset detection start timing */
#define MTR_OFFSET_ALIGN_ID_RATIO    (0.8f)                       /* Id ratio to the maximum current for alignment */
#define MTR_PERIOD_MAG_VALUE         (1.5f)                       /* Period magnification value for coordinate transformation */
#define MTR_I_LIMIT_VD               (IP_INPUT_V)                 /* Current PI integral term limit for vd */
#define MTR_I_LIMIT_VQ               (IP_INPUT_V)                 /* Current PI integral term limit for vq */
#define MTR_REF_ID                   (CP_OL_ID_REF)               /* Id reference when low speed [A] */
#define MTR_I_LIMIT_IQ               (MTR_NOMINAL_CURRENT_RMS * MTR_SQRT_2)
                                                                  /* speed PI integral term limit for iq */
#define MTR_LIMIT_IQ                 (MTR_NOMINAL_CURRENT_RMS * MTR_SQRT_2)
                                                                  /* speed PI limit for iq */
#define MTR_OVERCURRENT_MARGIN_MULT  (1.5f)
#define MTR_OVERCURRENT_LIMIT        (MTR_NOMINAL_CURRENT_RMS * MTR_SQRT_2 * MTR_OVERCURRENT_MARGIN_MULT)
                                                                  /* Over current limit [A] */
#define MTR_OVERVOLTAGE_LIMIT        (IP_OVERVOLTAGE_LIMIT)       /* Over voltage limit [V] */
#define MTR_UNDERVOLTAGE_LIMIT       (IP_UNDERVOLTAGE_LIMIT)      /* Under voltage limit [V] */
#define MTR_INPUT_V                  (IP_INPUT_V)                 /* Input DC voltage [V] */
#define MTR_MCU_ON_V                 (MTR_INPUT_V * 0.8f)         /* MCU power on voltage */
#define MTR_RATE_LIMIT_CURRENT       (0.0005f)                    /* Rate limit of current [A/s] */

/***** Macro of speed control *****/
#define MTR_SPEED_CTRL_PERIOD        (0.00025f)                   /* control period for speed loop */
#define MTR_SPEED_FF_RATIO           (1.0f)                       /* speed feed-forward ratio */
#define MTR_MIN_SPEED_RPM            (CP_MIN_SPEED_RPM)           /* minimum reference speed [rpm] */
#define MTR_MAX_SPEED_RPM            (CP_MAX_SPEED_RPM)           /* maximum reference speed [rpm] */
#define MTR_MAX_SPEED_RAD            (MTR_MAX_SPEED_RPM * MTR_TWOPI_60)
                                                                  /* maximum reference speed [rad/s] (mechanical) */
#define MTR_SPEED_LIMIT_RPM          (CP_SPEED_LIMIT_RPM)         /* over speed limit [rpm] */
#define MTR_OVERSPEED_LIMIT_RAD      (MTR_SPEED_LIMIT_RPM * MTR_RPM_RAD)
                                                                  /* over speed limit [rad/s] (electrical) */
#define MTR_RATE_LIMIT_SPEED         (0.3f)                       /* Rate limit of speed [rpm/s] */

/***** Macro of position control *****/
#define MTR_POS_DEAD_BAND            (1.0f)                       /* position dead-band */
#define MTR_POS_BAND_LIMIT           (3.0f)                       /* positioning band limit */
#define MTR_POS_INTERVAL_TIME        (400)                        /* Interval time for reference position change */
#define MTR_POS_LIMIT                ((32767.0f * MTR_TWOPI) / 360.0f)/* position limit */

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
/* motor parameter structure */
typedef struct
{
    uint16_t    u2_mtr_pp;              /* Pole pairs */
    float       f4_mtr_r;               /* Resistance [ohm] */
    float       f4_mtr_ld;              /* Inductance for d-axis [H] */
    float       f4_mtr_lq;              /* Inductance for q-axis [H] */
    float       f4_mtr_m;               /* Magnet flux [Wb] */
    float       f4_mtr_j;               /* Rotor inertia [kgm^2] */
    float       f4_nominal_current_rms; /* Rated torque [Nm] */
} mtr_parameter_t;

/* design parameter structure */
typedef struct
{
    float     f4_current_omega;         /* Natural frequency[Hz] for current loop gain design */
    float     f4_current_zeta;          /* Damping ratio for current loop gain design */
    float     f4_speed_omega;           /* Natural frequency[Hz] for speed loop gain design */
    float     f4_speed_zeta;            /* Damping ratio for speed loop gain design */
    float     f4_speed_lpf_omega;       /* Natural frequency[Hz] for speed lpf gain design */
    float     f4_pos_omega;             /* Natural frequency[Hz] for position loop gain design */
    float     f4_sob_omega;             /* Natural frequency[Hz] for speed observer gain design */
    float     f4_sob_zeta;              /* Damping ratio for speed observer gain design */
} mtr_design_parameter_t;

/* control gain structure */
typedef struct
{
    float     f4_id_kp;                 /* The P gain of d-axis current PI for direct gain setting */
    float     f4_id_ki;                 /* The I gain of d-axis current PI for direct gain setting */
    float     f4_iq_kp;                 /* The P gain of q-axis current PI for direct gain setting */
    float     f4_iq_ki;                 /* The I gain of q-axis current PI for direct gain setting */
    float     f4_speed_kp;              /* The P gain of speed PI for direct gain setting */
    float     f4_speed_ki;              /* The I gain of speed PI for direct gain setting */
    float     f4_pos_kp;                /* The P gain of position P for direct gain setting */
} mtr_ctrl_gain_t;

#endif /* R_MTR_PARAMETER_H */
