/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_foc_speed.h
* Description : Definitions of FOC speed control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_FOC_SPEED_H
#define R_MTR_FOC_SPEED_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_common.h"
#include "r_mtr_parameter.h"
#include "r_mtr_pi_control.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
typedef struct
{
    uint8_t       u1_ref_dir;                        /* stored reference rotation direction */
    float         f4_rpm_rad;                        /* [rpm] to [rad/s] */
    float         f4_speed_ctrl_period;              /* speed control period */
    float         f4_ref_speed_rad_ctrl;             /* command speed value for speed PI control[rad/s] */
    float         f4_ref_speed_rad;                  /* reference speed value [rad/s] */
    float         f4_speed_rad;                      /* speed value [rad/s] */
    float         f4_speed_rad_ctrl;                 /* speed_value for speed loop control [rad/s] */
    float         f4_max_speed_rad;                  /* maximum speed command value [rad/s] */
    float         f4_speed_rate_limit;               /* reference speed max change limit [rad/s] */
    mtr_pi_ctrl_t st_pi_speed;                       /* PI control structure */
} mtr_speed_control_t;

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_speed_control_init
* Description   : Initialize variables when motor speed control
* Arguments     : st_sc               - The pointer to speed control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_speed_control_init(mtr_speed_control_t *st_sc);

/***********************************************************************************************************************
* Function Name : mtr_speed_control_reset
* Description   : Reset variables when motor speed control
* Arguments     : st_sc               - The pointer to speed control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_speed_control_reset(mtr_speed_control_t *st_sc);

/***********************************************************************************************************************
* Function Name : mtr_set_param_ref_dir
* Description   : Sets parameter for direction
* Arguments     : st_sc               - The pointer to speed control structure
*                 u1_direction        - direction
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_ref_dir(mtr_speed_control_t *st_sc, uint8_t u1_direction);

/***********************************************************************************************************************
* Function Name : mtr_set_param_rpm_to_rad
* Description   : Sets parameter for [rpm] to [rad/s]
* Arguments     : st_sc               - The pointer to speed control structure
*                 u2_mtr_pp           - pole pairs
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_rpm_to_rad(mtr_speed_control_t *st_sc, uint16_t u2_mtr_pp);

/***********************************************************************************************************************
* Function Name : mtr_set_param_max_speed
* Description   : Sets parameter for maximum speed
* Arguments     : st_sc               - The pointer to speed control structure
*                 u2_max_speed_rpm    - maximum speed
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_max_speed(mtr_speed_control_t *st_sc, uint16_t u2_max_speed_rpm);

/***********************************************************************************************************************
* Function Name : mtr_set_param_ref_speed
* Description   : Sets parameter for reference speed
* Arguments     : st_sc               - The pointer to speed control structure
*                 s2_ref_speed_rpm    - reference speed [rpm]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_ref_speed(mtr_speed_control_t *st_sc, int16_t s2_ref_speed_rpm);

/***********************************************************************************************************************
* Function Name : mtr_set_param_speed_rate_limit
* Description   : Sets parameter for speed rate limit
* Arguments     : st_sc               - The pointer to speed control structure
*                 f4_speed_rate_limit - speed rate limit[rpm]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_speed_rate_limit(mtr_speed_control_t *st_sc, float f4_speed_rate_limit);

/***********************************************************************************************************************
* Function Name : mtr_speed_rate_limit
* Description   : Limits the rate of change of speed reference
* Arguments     : st_sc               - The pointer to speed control structure
* Return Value  : Limited speed reference
***********************************************************************************************************************/
float mtr_speed_rate_limit(mtr_speed_control_t *st_sc);

/***********************************************************************************************************************
* Function Name : mtr_speed_pi_control
* Description   : Speed PI control
* Arguments     : st_sc               - The pointer to speed control structure
*                 f4_speed_rad        - The electrical speed [rad/s]
* Return Value  : The Iq reference
***********************************************************************************************************************/
float mtr_speed_pi_control(mtr_speed_control_t *st_sc, float f4_speed_rad);

/***********************************************************************************************************************
* Function Name : mtr_speed_pi_gain_calc
* Description   : Designs speed pi control gain by given parameters
* Arguments     : st_motor             - The pointer to the motor parameter structure
*                 st_design_params     - The pointer to the motor control parameter structure
*                 st_sc                - The pointer to the speed control structure
*                 f4_speed_ctrl_period - The control period[s] for speed loop
* Return Value  : None
***********************************************************************************************************************/
void mtr_speed_pi_gain_calc(mtr_parameter_t *st_motor, mtr_design_parameter_t *st_design_params,
                            mtr_speed_control_t *st_sc, float f4_speed_ctrl_period);

#endif /* R_MTR_FOC_SPEED_H */
