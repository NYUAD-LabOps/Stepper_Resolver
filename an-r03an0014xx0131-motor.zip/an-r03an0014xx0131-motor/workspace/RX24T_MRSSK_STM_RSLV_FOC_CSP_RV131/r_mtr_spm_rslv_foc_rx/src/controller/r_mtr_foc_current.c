/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_foc_current.c
* Description : The FOC current control module
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <math.h>
/* Main associated header file */
#include "r_mtr_foc_current.h"

/* Project headers */
#include "r_mtr_filter.h"
#include "r_mtr_ctrl_mcu.h"
#include "r_mtr_parameter.h"

/***********************************************************************************************************************
* Function Name : mtr_foc_current_init
* Description   : Initializes FOC current control module
* Arguments     : st_cc - The pointer to the FOC current control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_current_init(mtr_current_control_t *st_cc)
{
    st_cc->f4_ctrl_period        = MTR_CTRL_PERIOD;
    st_cc->f4_ref_id             = MTR_REF_ID;
    st_cc->f4_ref_iq             = 0.0f;
    st_cc->f4_lim_iq             = MTR_LIMIT_IQ;
    st_cc->st_pi_id.f4_ilimit    = MTR_I_LIMIT_VD;
    st_cc->st_pi_iq.f4_ilimit    = MTR_I_LIMIT_VQ;
    st_cc->f4_current_rate_limit = MTR_RATE_LIMIT_CURRENT;
} /* End of function mtr_foc_current_init */

/***********************************************************************************************************************
* Function Name : mtr_foc_current_reset
* Description   : Resets FOC current control module
* Arguments     : st_cc - The pointer to the FOC current control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_current_reset(mtr_current_control_t *st_cc)
{
    st_cc->f4_ref_vd        = 0.0f;
    st_cc->f4_ref_vq        = 0.0f;
    st_cc->f4_ref_id_ctrl   = 0.0f;
    st_cc->f4_ref_iq_ctrl   = 0.0f;
    st_cc->f4_id_ad         = 0.0f;
    st_cc->f4_iq_ad         = 0.0f;
    st_cc->f4_pre_id_ad     = 0.0f;
    st_cc->f4_pre_iq_ad     = 0.0f;
    st_cc->st_pi_id.f4_err  = 0.0f;
    st_cc->st_pi_iq.f4_err  = 0.0f;
    st_cc->st_pi_id.f4_refi = 0.0f;
    st_cc->st_pi_iq.f4_refi = 0.0f;
} /* End of function mtr_foc_current_reset */

/***********************************************************************************************************************
* Function Name : mtr_set_param_ref_id
* Description   : Sets parameter for reference id
* Arguments     : st_cc     - The pointer to current control structure
*                 f4_ref_id - reference d-axis current [A]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_ref_id(mtr_current_control_t *st_cc, float f4_ref_id)
{
    st_cc->f4_ref_id = f4_ref_id;
} /* End of function mtr_set_param_ref_id */

/***********************************************************************************************************************
* Function Name : mtr_set_param_ref_iq
* Description   : Sets parameter for reference iq
* Arguments     : st_cc     - The pointer to current control structure
*                 f4_ref_iq - reference q-axis current [A]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_ref_iq(mtr_current_control_t *st_cc, float f4_ref_iq)
{
    st_cc->f4_ref_iq = f4_ref_iq;
} /* End of function mtr_set_param_ref_iq */

/***********************************************************************************************************************
* Function Name : mtr_set_param_iq_rate_limit
* Description   : Sets parameter for iq rate limit
* Arguments     : st_cc            - The pointer to current control structure
*                 f4_current_rate_limit - current rate limit[A/ms]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_current_rate_limit(mtr_current_control_t *st_cc, float f4_current_rate_limit)
{
    if(f4_current_rate_limit > 0.0f)
    {
        st_cc->f4_current_rate_limit = ((0.001f / MTR_SPEED_CTRL_PERIOD) * f4_current_rate_limit);
    }
} /* End of function mtr_set_param_iq_rate_limit */

/***********************************************************************************************************************
* Function Name : mtr_foc_current_decoupling
* Description   : Decoupling control, cancels the interference voltage due to the magnet and inductance
* Arguments     : st_cc        - The pointer to the FOC current control structure
*                 f4_speed_rad - The electrical speed [rad/s]
*                 p_mtr        - The pointer to the motor parameter data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_current_decoupling(mtr_current_control_t *st_cc, float f4_speed_rad, const mtr_parameter_t *p_mtr)
{
    float f4_temp0,f4_temp1;
    float f4_id;
    float f4_iq;

    f4_id = st_cc->f4_ref_id_ctrl;
    f4_iq = st_cc->f4_ref_iq_ctrl;

    f4_temp0 = p_mtr->f4_mtr_lq * f4_iq;                /* Lq * Iq */
    f4_temp0 = - f4_speed_rad * f4_temp0;               /* Speed * Lq * Iq */
    f4_temp0 = f4_temp0 + p_mtr->f4_mtr_r * f4_id;      /* + R * Id */

    f4_temp1 = p_mtr->f4_mtr_ld * f4_id;                /* Ld * id */
    f4_temp1 = f4_temp1 + p_mtr->f4_mtr_m;              /* Ld * Id + Flux */
    f4_temp1 = f4_speed_rad * f4_temp1;                 /* Speed * (Ld * id + Flux) */
    f4_temp1 = f4_temp1 + p_mtr->f4_mtr_r * f4_iq;      /* + R * Iq */

    st_cc->f4_ref_vd += f4_temp0;                       /* Vd - Speed * Lq * Iq */
    st_cc->f4_ref_vq += f4_temp1;                       /* Vq + Speed*(Ld * id + Flux) */

    st_cc->f4_pre_id_ad = f4_id;
    st_cc->f4_pre_iq_ad = f4_iq;

} /* End of function mtr_foc_current_decoupling */

/***********************************************************************************************************************
* Function Name : mtr_foc_current_pi_ctrl
* Description   : Current PI control
*                 Calculates the output voltage vector from current vector command and actual current vector
* Arguments     : st_cc - The pointer to the FOC current control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_current_pi_ctrl(mtr_current_control_t *st_cc)
{
    /* The d-axis */
    st_cc->st_pi_id.f4_err = st_cc->f4_ref_id_ctrl - st_cc->f4_id_ad;
    st_cc->f4_ref_vd = mtr_pi_ctrl(&(st_cc->st_pi_id));

    /* The q-axis */
    st_cc->st_pi_iq.f4_err = st_cc->f4_ref_iq_ctrl - st_cc->f4_iq_ad;
    st_cc->f4_ref_vq = mtr_pi_ctrl(&(st_cc->st_pi_iq));
} /* End of function mtr_foc_current_pi_ctrl */
