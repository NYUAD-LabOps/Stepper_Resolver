/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_foc_position.c
* Description : Processes of a position control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Main associated header file */
#include "r_mtr_foc_position.h"

/***********************************************************************************************************************
* Function Name : mtr_position_control_init
* Description   : Initialize variables when motor position control init
* Arguments     : st_pc               - position control structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void mtr_position_control_init(mtr_position_control_t *st_pc)
{
    st_pc->u2_pos_dead_band            = MTR_POS_DEAD_BAND;
    st_pc->u2_pos_band_limit           = MTR_POS_BAND_LIMIT;

    /* initialize of position control variables */
    st_pc->f4_pos_rad                  = 0.0f;
    st_pc->f4_ref_pos_rad              = 0.0f;
    st_pc->f4_speed_ff_ratio           = MTR_SPEED_FF_RATIO;
} /* End of function mtr_position_control_init */

/***********************************************************************************************************************
* Function Name : mtr_position_control_reset
* Description   : Reset variables when motor position control
* Arguments     : st_pc               - position control structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void mtr_position_control_reset(mtr_position_control_t *st_pc)
{
    /* position control */
    st_pc->f4_ref_pos_pre_rad          = 0.0f;
    st_pc->f4_ref_pos_rad_ctrl         = 0.0f;
    st_pc->f4_pos_err_rad              = 0.0f;
    st_pc->f4_speed_ff_rad             = 0.0f;
} /* End of function mtr_position_control_reset */

/***********************************************************************************************************************
* Function Name : mtr_set_param_pos_dead_band
* Description   : Set parameter for position dead-band
* Arguments     : st_pc               - position control structure (pointer)
*                 u2_pos_dead_band    - position dead-band
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_pos_dead_band(mtr_position_control_t *st_pc, uint16_t u2_pos_dead_band)
{
    st_pc->u2_pos_dead_band = u2_pos_dead_band;
} /* End of function mtr_set_param_pos_dead_band */

/***********************************************************************************************************************
* Function Name : mtr_set_param_pos_band_limit
* Description   : Set parameter for position band-limit
* Arguments     : st_pc               - position control structure (pointer)
*                 u2_pos_band_limit   - position band limit
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_pos_band_limit(mtr_position_control_t *st_pc, uint16_t u2_pos_band_limit)
{
    st_pc->u2_pos_band_limit = u2_pos_band_limit;
} /* End of function mtr_set_param_pos_band_limit */

/***********************************************************************************************************************
* Function Name : mtr_set_param_reference_position
* Description   : Set parameter for position reference
* Arguments     : st_pc               - position control structure (pointer)
*                 f4_ref_position_deg - position reference [degree]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_reference_position(mtr_position_control_t *st_pc, float f4_ref_position_deg)
{
    st_pc->f4_ref_pos_rad = f4_ref_position_deg * MTR_DIG_RAD;
    if (MTR_POS_LIMIT <= st_pc->f4_ref_pos_rad)
    {
        st_pc->f4_ref_pos_rad = MTR_POS_LIMIT;
    }
    else if  ((-(MTR_POS_LIMIT + 1)) >= st_pc->f4_ref_pos_rad)
    {
        st_pc->f4_ref_pos_rad = - MTR_POS_LIMIT;
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function mtr_set_param_reference_position */

/***********************************************************************************************************************
* Function Name : mtr_set_param_reference_position_rad
* Description   : Set parameter for position reference (radian)
* Arguments     : st_pc               - position control structure (pointer)
*                 f4_ref_position_rad - position reference [radian]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_reference_position_rad(mtr_position_control_t *st_pc, float f4_ref_position_rad)
{
    st_pc->f4_ref_pos_rad = f4_ref_position_rad;
    if (MTR_POS_LIMIT <= st_pc->f4_ref_pos_rad)
    {
        st_pc->f4_ref_pos_rad = MTR_POS_LIMIT;
    }
    else if  ((-(MTR_POS_LIMIT + 1)) >= st_pc->f4_ref_pos_rad)
    {
        st_pc->f4_ref_pos_rad = - MTR_POS_LIMIT;
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function mtr_set_param_reference_position */

/***********************************************************************************************************************
* Function Name : mtr_set_param_position_kp
* Description   : Set parameter for position kp
* Arguments     : st_pc               - position control structure (pointer)
*                 f4_pos_kp           - position kp
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_position_kp(mtr_position_control_t *st_pc, float f4_pos_kp)
{
    st_pc->f4_pos_kp = f4_pos_kp;
} /* End of function mtr_set_param_position_kp */

/***********************************************************************************************************************
* Function Name : mtr_p_ctrl_pos
* Description   : Position Proportional control
* Arguments     : st_pc          - position control structure (pointer)
*                 f4_pos_err_rad - position error [rad]
* Return Value  : Speed reference [rad/s]
***********************************************************************************************************************/
float mtr_p_ctrl_pos(mtr_position_control_t *st_pc, mtr_parameter_t *st_motor, float f4_pos_err_rad)
{
    float f4_speed_ref_calc_rad;

    f4_speed_ref_calc_rad = f4_pos_err_rad * st_pc->f4_pos_kp * st_motor->u2_mtr_pp;

    return (f4_speed_ref_calc_rad);
} /* End of function mtr_p_ctrl_pos */

/***********************************************************************************************************************
* Function Name : mtr_set_param_speed_ff_ratio
* Description   : Set parameter for speed feed-forward ratio
* Arguments     : st_pc               - position control structure (pointer)
*                 f4_speed_ff_ratio   - speed feed-forward ratio
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_speed_ff_ratio(mtr_position_control_t *st_pc, float f4_speed_ff_ratio)
{
    st_pc->f4_speed_ff_ratio = f4_speed_ff_ratio;
} /* End of function mtr_set_param_speed_ff_ratio */

/***********************************************************************************************************************
* Function Name : mtr_speed_feed_foward_control
* Description   : speed feed-forward control
* Arguments     : st_pc - position control structure (pointer)
* Return Value  : Speed reference [rad/s]
***********************************************************************************************************************/
float mtr_speed_feed_foward_control(mtr_position_control_t *st_pc, float f4_speed_ff_rad, float f4_speed_ref_calc_rad, uint16_t u2_mtr_pp)
{
    float f4_temp0;

    /* speed feed-forward control */
    st_pc->f4_speed_ff_rad = f4_speed_ff_rad;
    f4_temp0 = st_pc->f4_speed_ff_ratio * st_pc->f4_speed_ff_rad * u2_mtr_pp;
    f4_speed_ref_calc_rad += f4_temp0;

    return (f4_speed_ref_calc_rad);
} /* End of function mtr_speed_feed_foward_control */
