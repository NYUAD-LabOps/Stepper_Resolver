/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_foc_stm_rslv_control.h
* Description : Definitions of motor control processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_FOC_CONTROL_ENCD_POSITION_H
#define R_MTR_FOC_CONTROL_ENCD_POSITION_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "r_mtr_filter.h"
#include "r_mtr_config.h"

#include "r_mtr_foc_current.h"
#include "r_mtr_foc_speed.h"
#include "r_mtr_foc_position.h"
#include "r_mtr_position_profiling.h"
#include "r_mtr_speed_observer.h"
#include "r_mtr_ipd.h"
#include "r_mtr_fluxwkn.h"
#include "r_mtr_mod.h"
#include "r_mtr_parameter.h"
#include "r_mtr_pi_control.h"
#include "r_mtr_statemachine.h"
#include "r_mtr_transform.h"
#include "r_mtr_volt_err_comp.h"
#include "r_rslv_compensation.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Id reference status */
#define     MTR_ID_ZERO_CONST            (0)
#define     MTR_ID_FLUXWKN               (1)
#define     MTR_ID_MANUAL                (2)
/* Iq reference status */
#define     MTR_IQ_ZERO_CONST            (0)
#define     MTR_IQ_SPEED_PI_OUTPUT       (1)
#define     MTR_IQ_MANUAL                (2)
/* Speed reference status */
#define     MTR_SPEED_ZERO_CONST         (0)
#define     MTR_POS_CONTROL_OUTPUT       (1)
#define     MTR_SPEED_MANUAL             (2)
/* Position reference mode */
#define     MTR_POS_ZERO_CONST           (0)
#define     MTR_POS_STEP                 (1)
#define     MTR_POS_TRAPEZOID            (2)
/* Control loop mode */
#define     MTR_LOOP_CURRENT_ID          (0)
#define     MTR_LOOP_CURRENT_IQ          (1)
#define     MTR_LOOP_SPEED               (2)
#define     MTR_LOOP_POSITION            (3)
/* Ctrl mode */
#define     MTR_CTRL_PID                 (0)
#define     MTR_CTRL_IPD                 (1)
/* Offset adjust mode */
#define     MTR_OFAJ_CURRENT_OFFSET      (0)
#define     MTR_OFAJ_POS_OFFSET          (1)
#define     MTR_OFAJ_FIN                 (2)
/* angle adjustment reference status */
#define     MTR_ANGLE_ADJ_90DEG          (0)
#define     MTR_ANGLE_ADJ_0DEG           (1)
#define     MTR_ANGLE_ADJ_FIN            (2)

/***********************************************************************************************************************
* Macro definitions for sequence control
***********************************************************************************************************************/
/* Run mode */
#define     MTR_MODE_OFFSET_ADJUST        (0x00)
#define     MTR_MODE_DRIVE                (0x01)

/* Error status */
#define     MTR_ERROR_NONE                (0x0000)
#define     MTR_ERROR_OVER_CURRENT_HW     (0x0001)
#define     MTR_ERROR_OVER_VOLTAGE        (0x0002)
#define     MTR_ERROR_OVER_SPEED          (0x0004)
/*#define     MTR_ERROR_HALL_TIMEOUT        (0x0008)*/
/*#define     MTR_ERROR_BEMF_TIMEOUT        (0x0010)*/
/*#define     MTR_ERROR_HALL_PATTERN        (0x0020)*/
/*#define     MTR_ERROR_BEMF_PATTERN        (0x0040)*/
#define     MTR_ERROR_UNDER_VOLTAGE       (0x0080)
#define     MTR_ERROR_OVER_CURRENT_SW     (0x0100)
#define     MTR_ERROR_OVER_TEMPERATURE    (0x0200)
#define     MTR_ERROR_RESOLVER_DISCONNECT (0x0400)
#define     MTR_ERROR_RDC                 (0x0800)
#define     MTR_ERROR_UNKNOWN             (0xffff)

/* The PWM period[us] */
#define     MTR_PWM_PERIOD_US             (1000.0f/MTR_CARRIER_FREQ)
/* The duty cycle of dead-time */
#define     MTR_DUTY_CYCLE_DEADTIME       (MTR_DEADTIME/MTR_PWM_PERIOD_US)
/* The maximum duty cycle to ensure the time for current sampling */
#define     MTR_MAX_DUTY_CYCLE            (1.0f-(MTR_DUTY_CYCLE_DEADTIME*0.5f+(MTR_AD_SAMPLING_TIME/MTR_PWM_PERIOD_US)))
/* The minimum duty cycle to prevent linearity error of PWM output */
#define     MTR_MIN_DUTY_CYCLE            (MTR_DUTY_CYCLE_DEADTIME*0.5f)

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
typedef struct
{
    uint8_t  u1_id;                           /* Motor id */
    uint8_t  u1_state_id_ref;                 /* The d-axis current command status */
    uint8_t  u1_state_iq_ref;                 /* The q-axis current command status */
    uint8_t  u1_state_speed_ref;              /* The speed command status */
    uint8_t  u1_state_pos_ref;                /* Position command value management */
    uint8_t  u1_state_pos_ref_buff;           /* Position command value management buffer */
    uint8_t  u1_state_angle_adj;              /* Angle adjustment status */

    uint8_t  u1_direction;                    /* Reference rotation direction */
    uint8_t  u1_ctrl_loop_mode;               /* Control loop select */
    uint8_t  u1_ctrl_method_mode;             /* Control method select */
    uint8_t  u1_offset_adjust_mode;           /* Offset adjust mode */
    uint8_t  u1_offset_adjust_mode_buff;      /* Buffer of offset adjust mode */
    uint8_t  u1_flag_offset_calc;             /* Flags whether use q-axis current command value management */
    uint8_t  u1_flag_charge_cap;              /* Flags whether use capacitor charge completed */
    uint8_t  u1_flag_angle_spl_comp_use;       /* Flags whether use resolver position error compensation enable */
    uint8_t  u1_flag_pos_delay_comp_use;      /* Flags whether use position sampling delay compensation enable */
    uint8_t  u1_flag_cc_spl_comp_use;         /* Flags whether use current control sampling delay compensation enable */
    uint8_t  u1_flag_bpf_delay_comp_use;      /* Flags whether use BPF delay compensation enable */
    uint8_t  u1_flag_sob_use;                 /* Flags whether use speed observer enable */
    uint8_t  u1_flag_volt_err_comp_use;       /* Flags_whether use voltage error compensation enable */
    uint8_t  u1_flag_flux_weakening_use;      /* Flags_whether use flux-weakening enable */
    uint8_t  u1_flag_mode_inactive;           /* Flags whether use mode system INACTIVE */

    uint16_t u2_error_status;                 /* FOC error status */
    uint16_t u2_run_mode;                     /* Run mode */
    uint16_t u2_offset_calc_time;             /* Calculation time for current offset */
    uint16_t u2_offset_calc_wait;             /* Counter for current offset detection start timing */
    uint16_t u2_cnt_adjust;                   /* The number of samples to be acquired in offset measurement */
    uint16_t u2_angle_adj_time;               /* time of encoder angle adjustment */
    uint16_t u2_angle_adj_cnt;                /* counter of encoder angle adjustment */
    uint16_t u2_rslv_angle_cnt;               /* Angle count of resolver (electrical) */
    uint16_t u2_rslv_pre_angle_cnt;           /* Previous value of angle count of resolver */
    uint16_t u2_rslv_timer_cnt;               /* Timer count of resolver 80MHz 0-4000 */
    uint16_t u2_rslv_angle_offset_cnt;        /* Count of resolver angle offset */
    int32_t  s4_rslv_cycle_cnt;               /* Cycle counter of resolver */
    int16_t  s2_angle_err_cnt;                /* Anglre error */

    float    f4_vdc_ad;                       /* Bus voltage [V] */
    float    f4_offset_ia;                    /* a-phase current offset value [A] */
    float    f4_offset_ib;                    /* b-phase current offset value [A] */
    float    f4_sum_ia_ad;                    /* a-phase current summation value for offset calculation [A] */
    float    f4_sum_ib_ad;                    /* b-phase current summation value for offset calculation [A] */
    float    f4_ia_ad;                        /* a-phase current value [A] */
    float    f4_ib_ad;                        /* b-phase current value [A] */
    float    f4_ref_va;                       /* a-phase reference voltage value [V] */
    float    f4_ref_vb;                       /* b-phase reference voltage value [V] */
    float    f4_moda;                         /* a-phase duty cycle */
    float    f4_modb;                         /* b-phase duty cycle */
    float    f4_overcurrent_limit;            /* Over-current limit [A] */
    float    f4_overvoltage_limit;            /* Over-voltage limit [V] */
    float    f4_undervoltage_limit;           /* Under voltage limit [V]*/
    float    f4_overspeed_limit_rad;          /* Motor speed limit [rad/s] */
    float    f4_spl_comp_angle_rad;           /* Angle for sampling compensation [rad](electrical) */
    float    f4_spl_delay_time;               /* Delay time [s] */
    float    f4_spl_delay_comp_pos_rad;       /* Position for sampling delay compensation [rad] */
    float    f4_rslv_pos_rad;                 /* Position of resolver [rad](mechanical) */
    float    f4_rslv_angle_rad;               /* Angle of resolver [rad](electrical) */
    float    f4_rslv_angle_offset_rad;        /* Angle offset of resolver [rad](electrical) */
    float    f4_rslv_angle_offset_sum_rad;    /* Sum of angle offset of resolver [rad](electrical) */
    float    f4_rslv_speed_rad;               /* Speed of resolver [rad/s](electrical) */
    float    f4_open_loop_pos_rad;            /* Angle for open-loop control [rad] */

    /* Sub-modules */
    mod_t                    st_mod;          /* Modulation structure */
    mtr_rotor_angle_t        st_rotor_angle;  /* The rotor angle and its sine and cosine values */
    mtr_statemachine_t       st_stm;          /* Action structure */
    mtr_parameter_t          st_motor;        /* Motor parameters structure */
    mtr_current_control_t    st_cc;           /* Current control structure */
    mtr_speed_control_t      st_sc;           /* Speed control structure */
    mtr_position_control_t   st_pc;           /* Position & speed control structure */
    mtr_position_profiling_t st_ppf;          /* Position profiling structure */
    mtr_ipd_ctrl_t           st_ipd;          /* IPD control structure */
    mtr_speed_observer_t     st_sob;          /* Speed observer structure */
    mtr_volt_comp_t          st_volt_comp_p;  /* Compensates voltage error structure */
    fluxwkn_t                st_fluxwkn;      /* Flux-weakening structure */
    mtr_1st_order_lpf_t      st_slpf;         /* LPF for speed */
    rslv_compensation_t      st_rcomp;        /* resolver angle compensation structure */
} mtr_foc_control_t;

/***********************************************************************************************************************
* Interrupt handler function declarations (defined in the r_mtr_interrupt_xxx.c source file)
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_foc_interrupt_250us
* Description   : 1ms interrupt handler of FOC control
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_interrupt_250us(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_foc_interrupt_carrier
* Description   : The carrier interrupt handler of FOC control
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_interrupt_carrier(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_foc_init
* Description   : Initializes FOC drive system with default configuration and specified motor ID
* Arguments     : st_foc - The pointer to the FOC data structure
*                 u1_id - The motor ID which specify the motor connectors
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_init(mtr_foc_control_t *st_foc, uint8_t u1_id);

/***********************************************************************************************************************
* Function Name : mtr_foc_motor_default_init
* Description   : Initializes motor drive modules with default configuration
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_motor_default_init(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_foc_motor_reset
* Description   : Resets motor drive modules, configurations will not be reset
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_motor_reset(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_foc_error
* Description   : Sets error flags and trigger error event when u2_error_flag is not zero
* Arguments     : st_foc - The pointer to the FOC data structure
*                 u2_error_flag - The error flags of the errors to report
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_error(mtr_foc_control_t *st_foc, uint16_t u2_error_flag);

/***********************************************************************************************************************
* Function Name : mtr_calib_current_offset_iaib
* Description   : Measures the ab axis current offset
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : none
***********************************************************************************************************************/
void mtr_calib_current_offset_iaib(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_current_offset_adjustment_iaib
* Description   : Calibrates the current offset
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_current_offset_adjustment_iaib(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_decide_direction
* Description   : Updates direction by sign of electrical speed
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_decide_direction(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_rslv_pos_speed_calc
* Description   : calculate rotor position and speed
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_rslv_pos_speed_calc(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name: mtr_current_ctrl_smpldly_comp
* Description  : current control sampling delay compensation
* Arguments    : f4_angle_rad - motor angle (electrical) [rad]
*              : f4_speed_rad - motor speed (electrical) [rad/s]
* Return Value : motor angle (electrical) [rad/s]
***********************************************************************************************************************/
float mtr_current_ctrl_smpldly_comp(float f4_angle_rad, float f4_speed_rad);

/***********************************************************************************************************************
* Function Name : mtr_angle_speed
* Description   : Angle and speed detection
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_angle_speed(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_set_pos_ref
* Description   : Set position reference
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : position reference
***********************************************************************************************************************/
float mtr_set_pos_ref(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_set_speed_ref
* Description   : Updates the speed reference
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : Speed reference
***********************************************************************************************************************/
float mtr_set_speed_ref(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_set_iq_ref
* Description   : Updates the q-axis current reference
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : Iq reference
***********************************************************************************************************************/
float mtr_set_iq_ref(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_set_id_ref
* Description   : Updates the d-axis current reference
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : Id reference
***********************************************************************************************************************/
float mtr_set_id_ref(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_pos_offset_adjust
* Description   : Position offset adjustment
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : Id reference
***********************************************************************************************************************/
float mtr_pos_offset_adjust(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_set_ref_states
* Description   : Set references state
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : none
***********************************************************************************************************************/
void mtr_set_ref_state(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_error_check
* Description   : Checks the errors
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_error_check(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_over_current
* Description   : POE interrupt
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_over_current(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_rdc_alarm
* Description   : RDC ALARM
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_rdc_alarm(mtr_foc_control_t *st_foc);

/***********************************************************************************************************************
* Function Name : mtr_foc_voltage_limit
* Description   : Limit voltage vector, d-axis voltage has higher priority than q-axis voltage
* Arguments     : st_foc - The pointer to the FOC structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_voltage_limit(mtr_foc_control_t *p_foc);

/***********************************************************************************************************************
* Function Name : mtr_foc_voltage_limit_ab
* Description   : Limit voltage vector for ab-axis
* Arguments     : p_foc - The pointer to the FOC structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_voltage_limit_ab(float *f4_v_ab, float f4_vdc);

/***********************************************************************************************************************
* Function Name : mtr_foc_set_nominal_current
* Description   : Setup current related limit values by the nominal current of motor
* Arguments     : st_foc - The pointer to the FOC current control structure
*               : f4_nominal_current_rms - The nominal current[Arms] of motor
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_set_nominal_current(mtr_foc_control_t *st_foc, float f4_nominal_current_rms);

/***********************************************************************************************************************
* Function Name : mtr_flux_weakng
* Description   : Executes the flux-weakening
* Arguments     : st_foc - The pointer to the FOC data structure
*                 f4_idq_ref - The pointer to the reference current vector (array) in format {Idref, Iqref}
* Return Value  : None
***********************************************************************************************************************/
void  mtr_flux_weakng(mtr_foc_control_t *st_foc, float *f4_idq_ref);

#endif /* R_MTR_FOC_ENCD_POSITION_CONTROL_H */
