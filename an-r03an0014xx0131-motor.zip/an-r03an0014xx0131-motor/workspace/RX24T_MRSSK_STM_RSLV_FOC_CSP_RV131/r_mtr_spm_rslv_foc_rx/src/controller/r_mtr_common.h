/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_common.h
* Description : This header includes common definitions
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MTR_COMMON_H
#define R_MTR_COMMON_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* General definition */
#define     MTR_TWOPI       (2.0f * 3.1415926535f) /* 2 * pi */
#define     MTR_TWOPI_60    (MTR_TWOPI / 60.0f)    /* 2 * pi / 60 */
#define     MTR_DIG_RAD     (MTR_TWOPI / 360.0f)   /* 2 * pi / 360 */
#define     MTR_SQRT_2      (1.41421356f)          /* Sqrt(2) */
#define     MTR_SQRT_3      (1.7320508f)           /* Sqrt(3) */

/* Rotational direction */
#define     MTR_CW          (0)
#define     MTR_CCW         (1)

#define     MTR_LED_ON      (0)                    /* Active level of LED */
#define     MTR_LED_OFF     (1)                    /* Inactive level of LED */

#define     MTR_FLG_CLR     (0)                    /* For flag clear */
#define     MTR_FLG_SET     (1)                    /* For flag set */

#define     MTR_ENABLE      (1)                    /* For function enable */
#define     MTR_DISABLE     (0)                    /* For function disable */

/* Motor ID */
#define     MTR_ID_A        (0)                    /* Motor ID 0 */
#define     MTR_ID_B        (1)                    /* Motor ID 1 */

/* User macro definition */
#define     TRUE            (1)
#define     FALSE           (0)

#define     ON              (1)
#define     OFF             (0)

#define     HIGH            (1)
#define     LOW             (0)

#define     OK              (0x00)
#define     NG              (0xFF)

/***********************************************************************************************************************
* Structure definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
float     copysignf(float x, float y);               /* Copy the sign (positive or negative) */

#endif /* R_MTR_COMMON_H */

