/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_foc_current.h
* Description : Definitions of FOC current control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MTR_FOC_CURRENT_H
#define R_MTR_FOC_CURRENT_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_common.h"
#include "r_mtr_pi_control.h"
#include "r_mtr_parameter.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
/* Motor current control parameter structure */
typedef struct
{
    float           f4_ctrl_period;         /* The control period */
    float           f4_ref_vd;              /* The reference d-axis voltage value [V] */
    float           f4_ref_vq;              /* The reference q-axis voltage value [V] */
    float           f4_ref_id;              /* d-axis current command value in open loop mode [A] */
    float           f4_ref_iq;              /* Motor q-axis current reference [A] */
    float           f4_ref_id_ctrl;         /* The reference d-axis current value [A] */
    float           f4_ref_iq_ctrl;         /* The reference q-axis current value [A] */
    float           f4_current_rate_limit;  /* Limit of q-axis current change */
    float           f4_id_ad;               /* The d-axis current value [A] */
    float           f4_iq_ad;               /* The q-axis current value [A] */
    float           f4_pre_id_ad;           /* Previous value of d-axis current value [A] */
    float           f4_pre_iq_ad;           /* Previous value of q-axis current value [A] */
    float           f4_lim_iq;              /* The speed PI control output limit value [A}*/
    mtr_pi_ctrl_t   st_pi_id;               /* The d-axis current PI controller */
    mtr_pi_ctrl_t   st_pi_iq;               /* The q-axis current PI controller */
} mtr_current_control_t;

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/**********************************************************************************************************************
* Function Name : mtr_foc_current_pi_gain_calc
* Description   : Designs current pi control gain by given parameters
* Arguments     : st_motor             - The pointer to the motor parameter structure
*                 st_design_params     - The pointer to the motor control parameter structure
*                 st_cc                - The pointer to the current current control structure
*                 f4_ctrl_period       - The control period[s] for current loop
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_current_pi_gain_calc(mtr_parameter_t *st_motor, mtr_design_parameter_t *st_design_params,
                  mtr_current_control_t *st_cc, float f4_ctrl_period);

/***********************************************************************************************************************
* Function Name : mtr_foc_current_init
* Description   : Initializes FOC current control module
* Arguments     : st_cc - The pointer to the FOC current control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_current_init(mtr_current_control_t *st_cc);

/***********************************************************************************************************************
* Function Name : mtr_foc_current_reset
* Description   : Resets FOC current control module
* Arguments     : st_cc - The pointer to the FOC current control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_current_reset(mtr_current_control_t *st_cc);

/***********************************************************************************************************************
* Function Name : mtr_set_param_ref_id
* Description   : Sets parameter for reference id
* Arguments     : st_cc     - The pointer to current control structure
*                 f4_ref_id - reference d-axis current [A]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_ref_id(mtr_current_control_t *st_cc, float f4_ref_id);

/***********************************************************************************************************************
* Function Name : mtr_set_param_ref_iq
* Description   : Sets parameter for reference iq
* Arguments     : st_cc     - The pointer to current control structure
*                 f4_ref_iq - reference q-axis current [A]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_ref_iq(mtr_current_control_t *st_cc, float f4_ref_iq);

/***********************************************************************************************************************
* Function Name : mtr_set_param_iq_rate_limit
* Description   : Sets parameter for iq rate limit
* Arguments     : st_cc            - The pointer to current control structure
*                 f4_current_rate_limit - current rate limit[A/ms]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_current_rate_limit(mtr_current_control_t *st_cc, float f4_current_rate_limit);

/***********************************************************************************************************************
* Function Name : mtr_foc_current_decoupling
* Description   : Decoupling control, cancels the interference voltage due to the magnet and inductance
* Arguments     : st_cc        - The pointer to the FOC current control structure
*                 f4_speed_rad - The electrical speed [rad/s]
*                 p_mtr        - The pointer to the motor parameter data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_current_decoupling(mtr_current_control_t *st_cc, float f4_speed_rad, const mtr_parameter_t *p_mtr);

/***********************************************************************************************************************
* Function Name : mtr_foc_current_pi_ctrl
* Description   : Current PI control
*                 Calculates the output voltage vector from current vector command and actual current vector
* Arguments     : st_cc - The pointer to the FOC current control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_foc_current_pi_ctrl(mtr_current_control_t *st_cc);

#endif /* R_MTR_FOC_CONTROL_H */
