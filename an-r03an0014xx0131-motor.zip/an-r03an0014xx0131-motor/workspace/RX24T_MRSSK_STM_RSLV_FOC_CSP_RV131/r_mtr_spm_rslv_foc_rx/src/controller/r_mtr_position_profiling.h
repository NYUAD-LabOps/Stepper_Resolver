/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_position_profiling.h
* Description : Definitions of a motor control processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_POS_PROFILING_H
#define R_MTR_POS_PROFILING_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <stdint.h>

#include "r_mtr_common.h"
#include "r_mtr_parameter.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* position limitation and profile */
#define     MTR_MAX_ACCEL                ((MTR_POLE_PAIRS * MTR_NOMINAL_CURRENT_RMS * MTR_SQRT_2 * MTR_M) / MTR_J)
                                                            /* maximum acceleration */
#define     MTR_ACCEL_TIME               (0.06f)            /* acceleration time of reference speed [s] */
#define     MTR_MAX_ACCEL_TIME           (MTR_MAX_SPEED_RAD / MTR_MAX_ACCEL)
                                                            /* maximum acceleration time of reference speed [s] */
#define     MTR_TIME_SEC                 (MTR_SPEED_CTRL_PERIOD)         /* 250[us] */

/* reference position profiling mode */
#define     MTR_CTRL_TRIANGLE            (0)
#define     MTR_CTRL_TRAPEZOIDAL         (1)

/* position status */
#define     MTR_POS_STEADY_STATE         (0)
#define     MTR_POS_TRANSITION_STATE     (1)

/***********************************************************************************************************************
* Structure definitions
***********************************************************************************************************************/
typedef struct
{
    uint8_t   u1_state_pos_pf;                       /* position profile status */
    uint8_t   u1_pos_ref_mode;                       /* position reference mode */
    uint16_t  u2_interval_time;                      /* interval time for profile */
    uint16_t  u2_interval_time_buff;                 /* interval time buffer for profile */
    uint16_t  u2_interval_time_cnt;                  /* interval time counter for profile */
    float     f4_accel_time;                         /* acceleration time */
    float     f4_accel_time_buff;                    /* acceleration time buffer */
    float     f4_accel_time_inv;                     /*`inverse of acceleration time */
    float     f4_max_accel_time;                     /* maximum acceleration time */
    float     f4_accel_max_speed;                    /* maximum speed for acceleration */
    float     f4_accel_max_speed_buff;               /* maximum speed buffer for acceleration */
    float     f4_time_sec;                           /* timer counter for profiling */
    float     f4_pos_st_rad;                         /* start position */
    float     f4_pos_ed_rad;                         /* end position */
    float     f4_pos_dt_rad;                         /* position error for profile */
    float     f4_pos_dt_time_sec;                    /* position error / max speed */
} mtr_position_profiling_t;

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name : mtr_position_profiling_init
* Description   : Initialize variables when motor position profiling init
* Arguments     : st_pf         - position profiling structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void mtr_position_profiling_init(mtr_position_profiling_t *st_pf);

/***********************************************************************************************************************
* Function Name : mtr_foc_current_init
* Description   : Initialize variables when motor control start
* Arguments     : st_pf         - position profiling structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void mtr_position_profiling_reset(mtr_position_profiling_t *st_pf);

/***********************************************************************************************************************
* Function Name : mtr_set_param_interval_time
* Description   : Set parameter for position change interval time
* Arguments     : st_pf             - position profiling structure (pointer)
*                 u2_interval_time  - position change interval time
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_interval_time(mtr_position_profiling_t *st_pf, uint16_t u2_interval_time);

/***********************************************************************************************************************
* Function Name : mtr_set_param_accel_time
* Description   : Set parameter for acceleration time
* Arguments     : st_pf          - position profiling structure (pointer)
*                 f4_accel_time  - acceleration time
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_accel_time(mtr_position_profiling_t *st_pf, float f4_accel_time);

/***********************************************************************************************************************
* Function Name : mtr_set_param_max_accel_time
* Description   : Set parameter for maximum acceleration time
* Arguments     : st_pf                - position profiling structure (pointer)
*                 st_motor             - motor parameter structure (pointer)
*                 s2_max_speed_rpm     - maximum speed [rpm]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_max_accel_time(mtr_position_profiling_t *st_pf, mtr_parameter_t *st_motor);

/***********************************************************************************************************************
* Function Name : mtr_set_param_accel_max_speed
* Description   : Set parameter for maximum speed [rpm]
* Arguments     : st_pf             - position profiling structure (pointer)
*                 s2_max_speed_rpm  - maximum speed [rpm]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_accel_max_speed(mtr_position_profiling_t *st_pf, int16_t s2_max_speed_rpm);

/***********************************************************************************************************************
* Function Name : mtr_speed_profile_feed_forward
* Description   : trapezoid profile for speed feed-forward
* Arguments     : st_pf         - position profiling structure (pointer)
* Return Value  : reference speed (feed-forward)
***********************************************************************************************************************/
float mtr_speed_profile_feed_forward(mtr_position_profiling_t *st_pf);

/***********************************************************************************************************************
* Function Name : mtr_position_profile
* Description   : position profile (trapezoid)
* Arguments     : st_pf         - position profiling structure (pointer)
* Return Value  : reference position
***********************************************************************************************************************/
float mtr_position_profile(mtr_position_profiling_t *st_pf);

#endif /* R_MTR_POS_PROFILING_H */
