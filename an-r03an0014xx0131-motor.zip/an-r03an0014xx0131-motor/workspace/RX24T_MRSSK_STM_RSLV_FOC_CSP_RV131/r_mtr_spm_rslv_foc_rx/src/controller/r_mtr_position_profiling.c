/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_position_profiling.c
* Description : Processes of a motor control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <math.h>

/* Main associated header file */
#include "r_mtr_position_profiling.h"

/***********************************************************************************************************************
* Private functions definitions
***********************************************************************************************************************/
/* triangle profile for position reference */
static float mtr_pos_triangle(mtr_position_profiling_t *st_pf);

/* trapezoid profile for position reference */
static float mtr_pos_trapezoid(mtr_position_profiling_t *st_pf);

/***********************************************************************************************************************
* Function Name : mtr_position_profiling_init
* Description   : Initialize variables when motor position profiling init
* Arguments     : st_pf         - position profiling structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void mtr_position_profiling_init(mtr_position_profiling_t *st_pf)
{
    /* initialize member of position profiling structure */
    st_pf->u1_state_pos_pf         = MTR_POS_STEADY_STATE;
    st_pf->u1_pos_ref_mode         = MTR_CTRL_TRIANGLE;
    st_pf->u2_interval_time        = MTR_POS_INTERVAL_TIME;
    st_pf->u2_interval_time_buff   = MTR_POS_INTERVAL_TIME;
    st_pf->f4_accel_time           = MTR_ACCEL_TIME;
    st_pf->f4_accel_time_buff      = MTR_ACCEL_TIME;
    st_pf->f4_accel_time_inv       = 1.0f / MTR_ACCEL_TIME;
    st_pf->f4_max_accel_time       = MTR_MAX_ACCEL_TIME;
    st_pf->f4_accel_max_speed      = MTR_MAX_SPEED_RAD;
    st_pf->f4_accel_max_speed_buff = MTR_MAX_SPEED_RAD;
} /* End of function mtr_position_profiling_init */

/***********************************************************************************************************************
* Function Name : mtr_position_profiling_reset
* Description   : Reset variables when motor control
* Arguments     : st_pf         - position profiling structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void mtr_position_profiling_reset(mtr_position_profiling_t *st_pf)
{
    /* position profiling structure */
    st_pf->u2_interval_time_cnt = 0;
    st_pf->f4_time_sec          = 0.0f;
    st_pf->f4_pos_dt_rad        = 0.0f;
    st_pf->f4_pos_st_rad        = 0.0f;
    st_pf->f4_pos_ed_rad        = 0.0f;
    st_pf->f4_pos_dt_time_sec   = 0.0f;
} /* End of function mtr_position_profiling_reset */

/***********************************************************************************************************************
* Function Name : mtr_set_param_interval_time
* Description   : Set parameter for position change interval time
* Arguments     : st_pf             - position profiling structure (pointer)
*                 u2_interval_time  - position change interval time
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_interval_time(mtr_position_profiling_t *st_pf, uint16_t u2_interval_time)
{
    st_pf->u2_interval_time_buff = u2_interval_time;
} /* End of function mtr_set_param_interval_time */

/***********************************************************************************************************************
* Function Name : mtr_set_param_accel_time
* Description   : Set parameter for acceleration time
* Arguments     : st_pf          - position profiling structure (pointer)
*                 f4_accel_time  - acceleration time
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_accel_time(mtr_position_profiling_t *st_pf, float f4_accel_time)
{
    st_pf->f4_accel_time_buff = f4_accel_time;
    if (st_pf->f4_max_accel_time >= st_pf->f4_accel_time_buff)
    {
        st_pf->f4_accel_time_buff = st_pf->f4_max_accel_time;
    }
} /* End of function mtr_set_param_accel_time */

/***********************************************************************************************************************
* Function Name : mtr_set_param_max_accel_time
* Description   : Set parameter for maximum acceleration time
* Arguments     : st_pf                - position profiling structure (pointer)
*                 st_motor             - Motor parameter structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_max_accel_time(mtr_position_profiling_t *st_pf, mtr_parameter_t *st_motor)
{
    float f4_temp;

    f4_temp = st_motor->u2_mtr_pp * (st_motor->f4_nominal_current_rms * st_motor->f4_mtr_m * MTR_SQRT_2);
    f4_temp = f4_temp / st_motor->f4_mtr_j;
    st_pf->f4_max_accel_time = st_pf->f4_accel_max_speed_buff / f4_temp;
} /* End of function mtr_set_param_max_accel_time */

/***********************************************************************************************************************
* Function Name : mtr_set_param_accel_max_speed
* Description   : Set parameter for maximum speed [rpm]
* Arguments     : st_pf             - position profiling structure (pointer)
*                 s2_max_speed_rpm  - maximum speed [rpm]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_accel_max_speed(mtr_position_profiling_t *st_pf, int16_t s2_max_speed_rpm)
{
    /* This macros will never reference memory over 0xFFFFFFFF. */
    st_pf->f4_accel_max_speed_buff = (float)s2_max_speed_rpm * MTR_TWOPI_60;
} /* End of function mtr_set_param_accel_max_speed */

/***********************************************************************************************************************
* Function Name : mtr_pos_triangle
* Description   : triangle profile for position reference
*               : Acceleration does not reach the maximum speed
*               : (f4_accel_max_ref_speed_rad * f4_accel_time) >= f4_pos_dt_rad
* Arguments     : st_pf         - position profiling structure (pointer)
* Return Value  : reference position
***********************************************************************************************************************/
static float mtr_pos_triangle(mtr_position_profiling_t *st_pf)
{
    float f4_temp0;
    float f4_temp1;
    float f4_temp2;
    float f4_temp3;
    float f4_ref_pos_rad_calc;

    if (st_pf->f4_time_sec <= st_pf->f4_accel_time)
    {
        f4_temp0 = st_pf->f4_time_sec * st_pf->f4_time_sec;
        f4_temp0 = st_pf->f4_accel_max_speed * f4_temp0;
        f4_temp1 = 0.5f * st_pf->f4_accel_time_inv;
        f4_temp0 = f4_temp0 * f4_temp1;
        f4_ref_pos_rad_calc = f4_temp0 + st_pf->f4_pos_st_rad;
    }                                                             /* rise section for triangle */
    else if ((st_pf->f4_time_sec > st_pf->f4_accel_time) && (st_pf->f4_time_sec <= (2.0f * st_pf->f4_accel_time)))
    {
        f4_temp0 = 2.0f * st_pf->f4_accel_max_speed;
        f4_temp0 = f4_temp0 * st_pf->f4_time_sec;
        f4_temp1 = st_pf->f4_time_sec * st_pf->f4_time_sec;
        f4_temp1 = st_pf->f4_accel_max_speed * f4_temp1;
        f4_temp2 = 0.5f * st_pf->f4_accel_time_inv;
        f4_temp1 = - (f4_temp1 * f4_temp2);
        f4_temp2 = st_pf->f4_pos_dt_rad * 0.5f;
        f4_temp3 = st_pf->f4_accel_max_speed * st_pf->f4_accel_time;
        f4_temp3 = 3.0f * f4_temp3;
        f4_temp3 = - (f4_temp3 * 0.5f);
        f4_ref_pos_rad_calc = f4_temp0 + f4_temp1 + f4_temp3 + f4_temp2 + st_pf->f4_pos_st_rad;
    }                                                             /* reduce the speed */
    else if (st_pf->f4_time_sec > (2.0f * st_pf->f4_accel_time))  /* reach the target position */
    {
        st_pf->f4_pos_st_rad = st_pf->f4_pos_ed_rad;
        f4_ref_pos_rad_calc = st_pf->f4_pos_st_rad;
    }
    else
    {
        /* Do Nothing */
    }

    return (f4_ref_pos_rad_calc);
} /* End of function mtr_pos_triangle */

/***********************************************************************************************************************
* Function Name : mtr_pos_trapezoid
* Description   : trapezoid profile for position reference
*               : Acceleration reach the maximum speed
*               : (f4_accel_max_ref_speed_rad * f4_accel_time) <  f4_pos_dt_rad
* Arguments     : st_pf         - position profiling structure (pointer)
* Return Value  : reference position
***********************************************************************************************************************/
static float mtr_pos_trapezoid(mtr_position_profiling_t *st_pf)
{
    float f4_temp0;
    float f4_temp1;
    float f4_temp2;
    float f4_temp3;
    float f4_temp4;
    float f4_temp5;
    float f4_ref_pos_rad_calc;

    if (st_pf->f4_time_sec <= st_pf->f4_accel_time)
    {
        f4_temp0 = st_pf->f4_time_sec * st_pf->f4_time_sec;
        f4_temp0 = st_pf->f4_accel_max_speed * f4_temp0;
        f4_temp1 = 0.5f * st_pf->f4_accel_time_inv;
        f4_temp0 = f4_temp0 * f4_temp1;
        f4_ref_pos_rad_calc = f4_temp0 + st_pf->f4_pos_st_rad;
    }                                                                              /* speed up */
    else if ((st_pf->f4_time_sec > st_pf->f4_accel_time) && (st_pf->f4_time_sec <= st_pf->f4_pos_dt_time_sec))
    {
        f4_temp0 = st_pf->f4_accel_max_speed * st_pf->f4_time_sec;
        f4_temp1 = st_pf->f4_accel_max_speed * st_pf->f4_accel_time;
        f4_temp1 = - (f4_temp1 * 0.5f);
        f4_ref_pos_rad_calc = f4_temp0 + f4_temp1 + st_pf->f4_pos_st_rad;
    }                                                                              /* constant speed */
    else if ((st_pf->f4_time_sec > st_pf->f4_pos_dt_time_sec)
            && (st_pf->f4_time_sec <= (st_pf->f4_pos_dt_time_sec + st_pf->f4_accel_time)))
    {
        f4_temp0 = st_pf->f4_accel_max_speed * st_pf->f4_time_sec;
        f4_temp1 = st_pf->f4_time_sec * st_pf->f4_time_sec;
        f4_temp1 = st_pf->f4_accel_max_speed * f4_temp1;
        f4_temp2 = 0.5f * st_pf->f4_accel_time_inv;
        f4_temp1 = - (f4_temp1 * f4_temp2);
        f4_temp2 = st_pf->f4_pos_dt_rad * st_pf->f4_time_sec;
        f4_temp2 = f4_temp2 * st_pf->f4_accel_time_inv;;
        f4_temp3 = st_pf->f4_accel_max_speed * st_pf->f4_accel_time;
        f4_temp3 = - (f4_temp3 * 0.5f);
        f4_temp4 = st_pf->f4_pos_dt_rad * st_pf->f4_pos_dt_rad;
        f4_temp5 = 0.5f * st_pf->f4_accel_time_inv;
        f4_temp4 = - ((f4_temp4 * f4_temp5) / st_pf->f4_accel_max_speed);
        f4_ref_pos_rad_calc = f4_temp0 + f4_temp1 + f4_temp2 + f4_temp3 + f4_temp4 + st_pf->f4_pos_st_rad;
    }                                                                              /* reduce the speed */
    else if (st_pf->f4_time_sec > (st_pf->f4_pos_dt_time_sec + st_pf->f4_accel_time))
    {
        st_pf->f4_pos_st_rad = st_pf->f4_pos_ed_rad;
        f4_ref_pos_rad_calc = st_pf->f4_pos_st_rad;
    }                                                                              /* reach the target position */
    else
    {
        /* Do Nothing */
    }

    return (f4_ref_pos_rad_calc);
} /* End of function mtr_pos_trapezoid */

/***********************************************************************************************************************
* Function Name : mtr_speed_profile_feed_forward
* Description   : trapezoid profile for speed feed-forward
* Arguments     : st_pf         - position profiling structure (pointer)
* Return Value  : reference speed (feed-forward)
***********************************************************************************************************************/
float mtr_speed_profile_feed_forward(mtr_position_profiling_t *st_pf)
{
    float f4_speed_ff_rad;
    float f4_temp0;
    float f4_temp1;

    if (MTR_CTRL_TRIANGLE == st_pf->u1_pos_ref_mode)            /* speed feed-forward profile for triangle*/
    {
        if (st_pf->f4_time_sec <= st_pf->f4_accel_time)
        {
            f4_speed_ff_rad = (st_pf->f4_accel_max_speed * st_pf->f4_time_sec) * st_pf->f4_accel_time_inv;
        }
        else if ((st_pf->f4_time_sec > st_pf->f4_accel_time) && (st_pf->f4_time_sec <= (2.0f * st_pf->f4_accel_time)))
        {
            f4_temp0 = (st_pf->f4_accel_max_speed * st_pf->f4_time_sec) * st_pf->f4_accel_time_inv;
            f4_speed_ff_rad = (2.0f * st_pf->f4_accel_max_speed) - f4_temp0;
        }
        else if (st_pf->f4_time_sec > (2.0f * st_pf->f4_accel_time))
        {
            f4_speed_ff_rad = 0;
        }
        else
        {
            /* Do Nothing */
        }
    }
    else if (MTR_CTRL_TRAPEZOIDAL == st_pf->u1_pos_ref_mode)    /* speed feed-forward profile for trapezoidal*/
    {
        if (st_pf->f4_time_sec <= st_pf->f4_accel_time)
        {
            f4_speed_ff_rad = (st_pf->f4_accel_max_speed * st_pf->f4_time_sec) * st_pf->f4_accel_time_inv;
        }
        else if ((st_pf->f4_time_sec > st_pf->f4_accel_time) && (st_pf->f4_time_sec <= st_pf->f4_pos_dt_time_sec))
        {
            f4_speed_ff_rad = st_pf->f4_accel_max_speed;
        }
        else if ((st_pf->f4_time_sec > st_pf->f4_pos_dt_time_sec)
                 && (st_pf->f4_time_sec <= (st_pf->f4_pos_dt_time_sec + st_pf->f4_accel_time)))
        {
            f4_temp0 = st_pf->f4_pos_dt_rad * st_pf->f4_accel_time_inv;
            f4_temp1 = (st_pf->f4_accel_max_speed * st_pf->f4_time_sec) * st_pf->f4_accel_time_inv;
            f4_speed_ff_rad = (st_pf->f4_accel_max_speed + f4_temp0) - f4_temp1;
        }
        else if (st_pf->f4_time_sec > (st_pf->f4_pos_dt_time_sec + st_pf->f4_accel_time))
        {
            f4_speed_ff_rad = 0;
        }
        else
        {
            /* Do Nothing */
        }
    }
    else
    {
        /* Do Nothing */
    }

    return (f4_speed_ff_rad);
} /* End of function mtr_speed_profile_feed_forward */

/***********************************************************************************************************************
* Function Name : mtr_position_profile
* Description   : position profile (trapezoid)
* Arguments     : st_pf         - position profiling structure (pointer)
* Return Value  : reference position
***********************************************************************************************************************/
float mtr_position_profile(mtr_position_profiling_t *st_pf)
{
    float f4_temp0;
    float f4_ref_pos_rad_calc;

    f4_ref_pos_rad_calc = st_pf->f4_pos_st_rad;

    /* position control reference state - steady state */
    if (MTR_POS_STEADY_STATE == st_pf->u1_state_pos_pf)
    {
        /* difference in reference position check */
        if (st_pf->f4_pos_st_rad != st_pf->f4_pos_ed_rad)
        {
            /* update variables */
            st_pf->f4_accel_max_speed = st_pf->f4_accel_max_speed_buff;
            st_pf->f4_accel_time      = st_pf->f4_accel_time_buff;
            st_pf->f4_accel_time_inv  = 1.0f / st_pf->f4_accel_time;
            st_pf->u2_interval_time   = st_pf->u2_interval_time_buff;
            st_pf->f4_time_sec        = 0.0f;
            st_pf->f4_pos_dt_rad      = st_pf->f4_pos_ed_rad - st_pf->f4_pos_st_rad;
            f4_temp0 = fabsf(st_pf->f4_pos_dt_rad);
            st_pf->f4_pos_dt_time_sec = f4_temp0 / st_pf->f4_accel_max_speed;

            /* trapezoid mode check */
            if ((st_pf->f4_accel_time * st_pf->f4_accel_max_speed) >= f4_temp0)
            {
                st_pf->u1_pos_ref_mode = MTR_CTRL_TRIANGLE;
                st_pf->f4_accel_max_speed = st_pf->f4_pos_dt_rad * st_pf->f4_accel_time_inv;
            }
            else
            {
                st_pf->u1_pos_ref_mode = MTR_CTRL_TRAPEZOIDAL;
                st_pf->f4_accel_max_speed = copysignf(st_pf->f4_accel_max_speed, st_pf->f4_pos_dt_rad);
            }
            st_pf->u1_state_pos_pf = MTR_POS_TRANSITION_STATE;
        }
    }

    /* position control reference state - transition state */
    if (MTR_POS_TRANSITION_STATE == st_pf->u1_state_pos_pf)
    {
        if (MTR_CTRL_TRIANGLE == st_pf->u1_pos_ref_mode)
        {
            /* profiling triangle position reference */
            f4_ref_pos_rad_calc = mtr_pos_triangle(st_pf);
        }
        else if (MTR_CTRL_TRAPEZOIDAL == st_pf->u1_pos_ref_mode)
        {
            /* profiling trapezoid position reference */
            f4_ref_pos_rad_calc = mtr_pos_trapezoid(st_pf);
        }
        else
        {
            /* Do Nothing */
        }
        st_pf->f4_time_sec += MTR_TIME_SEC;

        /* reach the target position */
        if (st_pf->f4_pos_st_rad == st_pf->f4_pos_ed_rad)
        {
            /* Transition Interval Time */
            if (st_pf->u2_interval_time <= (st_pf->u2_interval_time_cnt++))
            {
                st_pf->u2_interval_time_cnt = 0;
                st_pf->u1_state_pos_pf = MTR_POS_STEADY_STATE;
            }
            f4_ref_pos_rad_calc = st_pf->f4_pos_st_rad;
        }
    }

    return (f4_ref_pos_rad_calc);
} /* End of function mtr_position_profile */
