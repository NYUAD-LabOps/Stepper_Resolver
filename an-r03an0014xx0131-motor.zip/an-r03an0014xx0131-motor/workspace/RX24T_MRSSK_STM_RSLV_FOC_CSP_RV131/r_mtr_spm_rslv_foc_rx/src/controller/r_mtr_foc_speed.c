/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_foc_speed.c
* Description : Processes of a motor control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <math.h>

/* Main associated header file */
#include "r_mtr_foc_speed.h"

/***********************************************************************************************************************
* Function Name : mtr_speed_control_init
* Description   : Initialize variables when motor speed control
* Arguments     : st_sc               - The pointer to speed control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_speed_control_init(mtr_speed_control_t *st_sc)
{
    st_sc->f4_speed_ctrl_period = MTR_SPEED_CTRL_PERIOD;
    st_sc->u1_ref_dir           = MTR_CW;
    st_sc->f4_rpm_rad           = MTR_RPM_RAD;
    st_sc->f4_ref_speed_rad     = 0.0f;
    st_sc->f4_max_speed_rad     = MTR_MAX_SPEED_RPM * MTR_RPM_RAD;
    st_sc->f4_speed_rate_limit  = MTR_RATE_LIMIT_SPEED * MTR_RPM_RAD;

    /* Initialize member of PI  control structure */
    st_sc->st_pi_speed.f4_ilimit = MTR_I_LIMIT_IQ;
} /* End of function mtr_speed_control_init */

/***********************************************************************************************************************
* Function Name : mtr_speed_control_reset
* Description   : Reset variables when motor speed control
* Arguments     : st_sc               - The pointer to speed control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_speed_control_reset(mtr_speed_control_t *st_sc)
{
    st_sc->f4_ref_speed_rad_ctrl = 0.0f;
    st_sc->f4_speed_rad          = 0.0f;
    st_sc->f4_speed_rad_ctrl     = 0.0f;

    /* PI control structure */
    st_sc->st_pi_speed.f4_err    = 0.0f;
    st_sc->st_pi_speed.f4_refi   = 0.0f;
} /* End of function mtr_speed_control_reset */

/***********************************************************************************************************************
* Function Name : mtr_set_param_ref_dir
* Description   : Sets parameter for direction
* Arguments     : st_sc               - The pointer to speed control structure
*                 u1_direction        - direction
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_ref_dir(mtr_speed_control_t *st_sc, uint8_t u1_direction)
{
    st_sc->u1_ref_dir = u1_direction;
} /* End of function mtr_set_param_ref_dir */

/***********************************************************************************************************************
* Function Name : mtr_set_param_rpm_to_rad
* Description   : Sets parameter for [rpm] to [rad/s]
* Arguments     : st_sc               - The pointer to speed control structure
*                 u2_mtr_pp           - pole pairs
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_rpm_to_rad(mtr_speed_control_t *st_sc, uint16_t u2_mtr_pp)
{
    /* This variables will never reference memory over 0xFFFFFFFF. */
    st_sc->f4_rpm_rad = (float)(u2_mtr_pp * MTR_TWOPI_60);
} /* End of function mtr_set_param_rpm_to_rad */

/***********************************************************************************************************************
* Function Name : mtr_set_param_ref_speed
* Description   : Sets parameter for reference speed
* Arguments     : st_sc               - The pointer to speed control structure
*                 s2_ref_speed_rpm    - reference speed [rpm]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_ref_speed(mtr_speed_control_t *st_sc, int16_t s2_ref_speed_rpm)
{
    if (MTR_CW == st_sc->u1_ref_dir)
    {
        /* [rpm]->[rad/s] */
        st_sc->f4_ref_speed_rad = (float)s2_ref_speed_rpm * st_sc->f4_rpm_rad;
    }
    else if (MTR_CCW == st_sc->u1_ref_dir)
    {
        /* [rpm]->[rad/s] */
        st_sc->f4_ref_speed_rad = (-(float)s2_ref_speed_rpm) * st_sc->f4_rpm_rad;
    }
    else
    {
        /* Do nothing */
    }
} /* End of function mtr_set_param_ref_speed */

/***********************************************************************************************************************
* Function Name : mtr_set_param_max_speed
* Description   : Sets parameter for maximum speed
* Arguments     : st_sc               - The pointer to speed control structure
*                 u2_max_speed_rpm    - maximum speed
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_max_speed(mtr_speed_control_t *st_sc, uint16_t u2_max_speed_rpm)
{
    /* This variables will never reference memory over 0xFFFFFFFF. */
    st_sc->f4_max_speed_rad = (float)(u2_max_speed_rpm * st_sc->f4_rpm_rad);
} /* End of function mtr_set_param_max_speed */

/***********************************************************************************************************************
* Function Name : mtr_set_param_speed_rate_limit
* Description   : Sets parameter for speed rate limit
* Arguments     : st_sc               - The pointer to speed control structure
*                 f4_speed_rate_limit - speed rate limit[rpm/ms]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_speed_rate_limit(mtr_speed_control_t *st_sc, float f4_speed_rate_limit)
{
    if(f4_speed_rate_limit > 0.0f)
    {
        st_sc->f4_speed_rate_limit = (0.001 / MTR_SPEED_CTRL_PERIOD) * f4_speed_rate_limit * st_sc->f4_rpm_rad;
    }
} /* End of function mtr_set_param_speed_rate_limit */

/***********************************************************************************************************************
* Function Name : mtr_speed_rate_limit
* Description   : Limits the rate of change of speed reference
* Arguments     : st_sc               - The pointer to speed control structure
* Return Value  : Limited speed reference
***********************************************************************************************************************/
float mtr_speed_rate_limit(mtr_speed_control_t *st_sc)
{
    float f4_temp0;
    float f4_temp1;
    float f4_speed_ref_calc_rad;

    f4_temp0 = st_sc->f4_ref_speed_rad - st_sc->f4_ref_speed_rad_ctrl;
    f4_temp1 = fminf(st_sc->f4_speed_rate_limit, fabsf(f4_temp0));
    f4_speed_ref_calc_rad = st_sc->f4_ref_speed_rad_ctrl + copysignf(f4_temp1, f4_temp0);

    return (f4_speed_ref_calc_rad);
} /* End of function mtr_speed_rate_limit */

/***********************************************************************************************************************
* Function Name : mtr_speed_pi_control
* Description   : Speed PI control
* Arguments     : st_sc               - The pointer to speed control structure
*                 f4_speed_rad        - The electrical speed [rad/s]
* Return Value  : The Iq reference
***********************************************************************************************************************/
float mtr_speed_pi_control(mtr_speed_control_t *st_sc, float f4_speed_rad)
{
    float f4_ref_iq_calc;

    st_sc->st_pi_speed.f4_err = st_sc->f4_ref_speed_rad_ctrl - f4_speed_rad;
    f4_ref_iq_calc = mtr_pi_ctrl(&st_sc->st_pi_speed);

    return (f4_ref_iq_calc);
} /* End of function mtr_speed_pi_control */
