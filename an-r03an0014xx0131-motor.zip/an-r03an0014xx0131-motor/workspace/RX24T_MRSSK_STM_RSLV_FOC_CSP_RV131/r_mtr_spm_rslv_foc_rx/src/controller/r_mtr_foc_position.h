/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name   : r_mtr_foc_position.h
* Description : Definitions of a position control processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_POSITION_H
#define R_MTR_POSITION_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_common.h"
#include "r_mtr_parameter.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
/* motor position control parameter structure */
typedef struct
{
    /* position control */
    uint16_t    u2_pos_dead_band;        /* position dead-band */
    uint16_t    u2_pos_band_limit;       /* positioning band limit */
    float       f4_pos_kp;               /* proportional gain for position */
    float       f4_pos_err_rad;          /* position error [rad] (mechanical) */
    float       f4_pos_rad;              /* position value [rad] (mechanical) */
    float       f4_ref_pos_rad;          /* reference position [rad] (mechanical) */
    float       f4_ref_pos_pre_rad;      /* previous value of reference position [rad] (mechanical) */
    float       f4_ref_pos_rad_ctrl;     /* reference position for control [rad] (mechanical) */
    float       f4_speed_ff_rad;         /* feed-forward speed [rad/s] (mechanical) */
    float       f4_speed_ff_ratio;       /* speed feed-forward gain ratio */
} mtr_position_control_t;

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name : mtr_position_control_init
* Description   : Initialize variables when motor position control init
* Arguments     : st_pc - position control structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void mtr_position_control_init(mtr_position_control_t *st_pc);

/***********************************************************************************************************************
* Function Name : mtr_foc_current_init
* Description   : Reset variables when motor position control
* Arguments     : st_pc - position control structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void mtr_position_control_reset(mtr_position_control_t *st_pc);

/***********************************************************************************************************************
* Function Name : mtr_set_param_pos_dead_band
* Description   : Set parameter for position dead-band
* Arguments     : st_pc               - position control structure (pointer)
*                 u2_pos_dead_band    - position dead-band
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_pos_dead_band(mtr_position_control_t *st_pc, uint16_t u2_pos_dead_band);

/***********************************************************************************************************************
* Function Name : mtr_set_param_pos_band_limit
* Description   : Set parameter for position band-limit
* Arguments     : st_pc               - position control structure (pointer)
*                 u2_pos_band_limit   - position band limit
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_pos_band_limit(mtr_position_control_t *st_pc, uint16_t u2_pos_band_limit);

/***********************************************************************************************************************
* Function Name : mtr_set_param_reference_position
* Description   : Set parameter for position reference
* Arguments     : st_pc               - position control structure (pointer)
*                 f4_ref_position_deg - position reference [degree]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_reference_position(mtr_position_control_t *st_pc, float f4_ref_position_deg);

/***********************************************************************************************************************
* Function Name : mtr_set_param_reference_position_rad
* Description   : Set parameter for position reference (radian)
* Arguments     : st_pc               - position control structure (pointer)
*                 f4_ref_position_rad - position reference [radian]
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_reference_position_rad(mtr_position_control_t *st_pc, float f4_ref_position_rad);

/***********************************************************************************************************************
* Function Name : mtr_set_param_position_kp
* Description   : Set parameter for position kp
* Arguments     : st_pc     - position control structure (pointer)
*                 f4_pos_kp - position kp
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_position_kp(mtr_position_control_t *st_pc, float f4_pos_kp);

/***********************************************************************************************************************
* Function Name : mtr_p_ctrl_pos
* Description   : Position Proportional control
* Arguments     : st_pc               - position control structure (pointer)
*                 f4_pos_err_rad      - position error [rad]
* Return Value  : None
***********************************************************************************************************************/
float mtr_p_ctrl_pos(mtr_position_control_t *st_pc, mtr_parameter_t *st_motor, float f4_pos_err_rad);

/***********************************************************************************************************************
* Function Name : mtr_set_param_speed_ff_ratio
* Description   : Set parameter for speed feed-forward ratio
* Arguments     : st_pc               - position control structure (pointer)
*                 f4_speed_ff_ratio   - speed feed-forward ratio
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_speed_ff_ratio(mtr_position_control_t *st_pc, float f4_speed_ff_ratio);

/***********************************************************************************************************************
* Function Name : mtr_speed_feed_foward_control
* Description   : speed feed-forward control
* Arguments     : st_pc               - position control structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
float mtr_speed_feed_foward_control(mtr_position_control_t *st_pc,
                                    float f4_speed_ff_rad,
                                    float f4_speed_ref_calc_rad,
                                    uint16_t u2_mtr_pp);

/* control gains calculation */

/***********************************************************************************************************************
* Function Name : mtr_pos_p_gain_calc
* Description   : Gain calculation for position proportional control
* Arguments     : st_design_params       - The pointer to the design parameter structure
*                 st_pc                  - position control structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void mtr_pos_p_gain_calc(mtr_design_parameter_t *st_design_params, mtr_position_control_t *st_pc);

#endif /* R_MTR_POSITION_H */
