/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_rslv_compensation.h
* Description : Definitions of motor control processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_RSLV_COMPENSATION_H
#define R_RSLV_COMPENSATION_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>

#include "r_mtr_config.h"
#include "r_mtr_common.h"
#include "r_mtr_ctrl_mcu.h"
#include "r_mtr_parameter.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
#define     BPF_COMP_GAIN_MULT_CW        (1.00f)        /* Multiplier for clockwise rotation BPF comp. */
#define     BPF_COMP_GAIN_MULT_CCW       (1.00f)        /* Multiplier for counter-clockwise rotation BPF comp.*/
#define     IRON_LOSS_COMP_MULT          (1.00f)        /* Multiplier for iron-loss compensation */
/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
typedef struct
{
    uint16_t u2_rslv_timer_cnt_capture;       /* Timer count of resolver input capture */
    uint16_t u2_rslv_pre_timer_cnt_capture;   /* Previous value of timer count of resolver input capture */
    uint16_t u2_rslv_timer_cnt_capture_offset;/* Previous value of timer count of resolver input capture */
    int16_t  s2_timer_cnt_err;                /* Error of the timer count */
    float    f4_time;                         /* Debug */
    float    f4_bpf_comp_rad;                 /* BPF compensation [rad] */
    float    f4_iron_loss_comp_angle_rad;     /* Iron loss compensation */
    float    f4_angle_comp_rad;               /* Angle compensation [rad] */
    float    f4_pre_angle_rad;                /* Previous value of angle [rad] */
    float    f4_over_corr_comp_angle_rad;     /* Angle for over correction compensation [rad] */
    float    f4_bpf_comp_gain_cw;
    float    f4_bpf_comp_gain_ccw;
    float    f4_bpf_comp_base_cw;
    float    f4_bpf_comp_base_ccw;
    float    f4_iron_loss_comp_gain;
    float    f4_iron_loss_comp_base;
} rslv_compensation_t;

/***********************************************************************************************************************
* Interrupt handler function declarations (defined in the r_mtr_interrupt_xxx.c source file)
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_rslv_comp_init
* Description   : Initializes FOC current control module
* Arguments     : st_rcomp - The pointer to the resolver compensation structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_rslv_comp_init(rslv_compensation_t *st_rcomp);

/***********************************************************************************************************************
* Function Name : mtr_rslv_comp_reset
* Description   : Reset FOC current control module
* Arguments     : st_rcomp - The pointer to the resolver compensation structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_rslv_comp_reset(rslv_compensation_t *st_rcomp);

/***********************************************************************************************************************
* Function Name : mtr_set_param_bpf_comp_gain_cw
* Description   : Set parameter for BPF delay compensation gain for cw
* Arguments     : st_rcomp             - The pointer to the resolver compensation structure
*                 f4_bpf_comp_gain_cw  - BPF delay compensation gain for cw
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_bpf_comp_gain_cw(rslv_compensation_t *st_rcomp, float f4_bpf_comp_gain_cw);

/***********************************************************************************************************************
* Function Name : mtr_set_param_bpf_comp_gain_ccw
* Description   : Set parameter for BPF delay compensation gain for ccw
* Arguments     : st_rcomp              - The pointer to the resolver compensation structure
*                 f4_bpf_comp_gain_ccw  - BPF delay compensation gain for ccw
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_bpf_comp_gain_ccw(rslv_compensation_t *st_rcomp, float f4_bpf_comp_gain_ccw);

/***********************************************************************************************************************
* Function Name : mtr_set_param_bpf_comp_base_cw
* Description   : Set parameter for BPF delay compensation gain for CW
* Arguments     : st_rcomp             - The pointer to the resolver compensation structure
*                 f4_bpf_comp_base_cw  - BPF delay compensation gain for CW
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_bpf_comp_base_cw(rslv_compensation_t *st_rcomp, float f4_bpf_comp_base_cw);

/***********************************************************************************************************************
* Function Name : mtr_set_param_bpf_comp_base_ccw
* Description   : Set parameter for BPF delay compensation gain for CCW
* Arguments     : st_rcomp              - The pointer to the resolver compensation structure
*                 f4_bpf_comp_base_ccw  - BPF delay compensation gain for CCW
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_bpf_comp_base_ccw(rslv_compensation_t *st_rcomp, float f4_bpf_comp_base_ccw);

/***********************************************************************************************************************
* Function Name : mtr_set_param_iron_loss_comp_mult
* Description   : Set multiplier for Iron loss delay compensation
* Arguments     : st_rcomp                - The pointer to the resolver compensation structure
*                 f4_iron_loss_comp_mult  - The multiplier for iron loss delay compensation
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_iron_loss_comp_mult(rslv_compensation_t *st_rcomp, float f4_iron_loss_comp_mult);

/***********************************************************************************************************************
* Function Name : mtr_set_param_iron_loss_comp_base
* Description   : Set base value for Iron loss delay compensation
* Arguments     : st_rcomp                - The pointer to the resolver compensation structure
*                 f4_iron_loss_comp_base  - The base value for iron loss delay compensation
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_iron_loss_comp_base(rslv_compensation_t *st_rcomp, float f4_iron_loss_comp_base);

/***********************************************************************************************************************
* Function Name : mtr_iron_loss_comp
* Description   : Iron loss delay compensation
* Arguments     : st_rcomp                 - The pointer to the resolver compensation structure
*                 f4_speed_rad             - Speed
* Return Value  : compensation angle
***********************************************************************************************************************/
float mtr_iron_loss_comp(rslv_compensation_t *st_rcomp, float f4_speed_rad);

/***********************************************************************************************************************
* Function Name : mtr_bpf_delay_comp
* Description   : band-pass filter delay compensation
* Arguments     : st_rcomp                 - The pointer to the resolver compensation structure
*                 u1_direction             - Rotor direction
*                 u2_rslv_angle_offset_cnt - Angle offset of resolver
*                 f4_speed_rad_ctrl        - Speed
* Return Value  : f4_bpf_comp_rad          - compensation angle
***********************************************************************************************************************/
float mtr_bpf_delay_comp(rslv_compensation_t *st_rcomp, uint8_t u1_direction, uint16_t u2_rslv_angle_offset_cnt, float f4_speed_rad_ctrl);

/***********************************************************************************************************************
* Function Name : mtr_angle_spl_comp
* Description   : sampling delay compensation for angle
* Arguments     : st_rcomp                 - The pointer to the resolver compensation structure
*                 u1_direction             - Rotor direction
*                 f4_angle_rad             - Current angle
*                 f4_speed_rad_ctrl        - Speed
* Return Value  : f4_angle_rad             - Angle
***********************************************************************************************************************/
float mtr_angle_spl_comp(rslv_compensation_t *st_rcomp, uint8_t u1_direction, float f4_angle_rad, float f4_speed_rad_ctrl);

#endif /* R_RSLV_COMPENSATION_H */
