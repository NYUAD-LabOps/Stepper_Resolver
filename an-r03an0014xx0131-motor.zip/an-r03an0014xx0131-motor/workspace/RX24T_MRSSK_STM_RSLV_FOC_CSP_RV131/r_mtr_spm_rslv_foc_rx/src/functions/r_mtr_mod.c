/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_mtr_mod.c
* Description  : This module convert 3-phase voltages to 3-phase duties
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "r_mtr_mod.h"

/***********************************************************************************************************************
* Function Name: mod_svpwm
* Description  : Space vector modulation
* Arguments    : p_f4_v_in -
*                    Input data, in an array [Vu,Vv,Vw]
*                p_f4_v_out -
*                    Where to store output data, in an array [Vu,Vv,Vw]
* Return Value : None
***********************************************************************************************************************/
static inline mod_svpwm(const float *p_f4_v_in, float *p_f4_v_out)
{
    float f4_v_max;
    float f4_v_min;
    float f4_v_com;

    /* Sort vu vv vw */
    if (p_f4_v_in[0] > p_f4_v_in[1])
    {
        f4_v_max = p_f4_v_in[0];
        f4_v_min = p_f4_v_in[1];
    }
    else
    {
        f4_v_max = p_f4_v_in[1];
        f4_v_min = p_f4_v_in[0];
    }

    /* Vcom = (Vmin + Vmax)/2 */
    if (p_f4_v_in[2] > f4_v_max)
    {
        f4_v_com = (p_f4_v_in[2] + f4_v_min) * 0.5f;
    }
    else if (p_f4_v_in[2] < f4_v_min)
    {
        f4_v_com = (f4_v_max + p_f4_v_in[2]) * 0.5f;
    }
    else
    {
        f4_v_com = (f4_v_max + f4_v_min) * 0.5f;
    }

    p_f4_v_out[0] = p_f4_v_in[0] - f4_v_com;
    p_f4_v_out[1] = p_f4_v_in[1] - f4_v_com;
    p_f4_v_out[2] = p_f4_v_in[2] - f4_v_com;
} /* End of function mod_svpwm() */

/***********************************************************************************************************************
* Function Name: mod_limit
* Description  : Limits the duty cycle, and detect saturation (if function enabled)
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
*                p_f4_duty -
*                    Pointer to the input and output duty cycle array, array length = 3
* Return Value : None
***********************************************************************************************************************/
static inline void mod_limit(mod_t *p_mod, float *p_f4_duty)
{
    float f4_min_duty = p_mod->f4_min_duty;
    float f4_max_duty = p_mod->f4_max_duty;

    if (p_f4_duty[0] > f4_max_duty)
    {
        p_f4_duty[0] = f4_max_duty;
#if (MOD_DETECT_SATURATION == 1)
        p_mod->u1_sat_flag |= MOD_SATFLAG_BITU;
#endif
    }
    else if (p_f4_duty[0] < f4_min_duty)
    {
        p_f4_duty[0] = f4_min_duty;
#if (MOD_DETECT_SATURATION == 1)
        p_mod->u1_sat_flag |= MOD_SATFLAG_BITU;
#endif
    }
    else
    {
        /* Clear correspond saturation flag bit */
#if (MOD_DETECT_SATURATION == 1)
        p_mod->u1_sat_flag &= (~MOD_SATFLAG_BITU);
#endif
    }
    if (p_f4_duty[1] > f4_max_duty)
    {
        p_f4_duty[1] = f4_max_duty;
#if (MOD_DETECT_SATURATION == 1)
        p_mod->u1_sat_flag |= MOD_SATFLAG_BITV;
#endif
    }
    else if (p_f4_duty[1] < f4_min_duty)
    {
        p_f4_duty[1] = f4_min_duty;
#if (MOD_DETECT_SATURATION == 1)
        p_mod->u1_sat_flag |= MOD_SATFLAG_BITV;
#endif
    }
    else
    {
        /* Clear correspond saturation flag bit */
#if (MOD_DETECT_SATURATION == 1)
        p_mod->u1_sat_flag &= (~MOD_SATFLAG_BITV);
#endif
    }
    if (p_f4_duty[2] > f4_max_duty)
    {
        p_f4_duty[2] = f4_max_duty;
#if (MOD_DETECT_SATURATION == 1)
        p_mod->u1_sat_flag |= MOD_SATFLAG_BITW;
#endif
    }
    else if (p_f4_duty[2] < f4_min_duty)
    {
        p_f4_duty[2] = f4_min_duty;
#if (MOD_DETECT_SATURATION == 1)
        p_mod->u1_sat_flag |= MOD_SATFLAG_BITW;
#endif
    }
    else
    {
        /* Clear correspond saturation flag bit */
#if (MOD_DETECT_SATURATION == 1)
        p_mod->u1_sat_flag &= (~MOD_SATFLAG_BITW);
#endif
    }
}/* End of function mod_limit() */

/***********************************************************************************************************************
* Function Name: mtr_mod_init
* Description  : Initializes modulation module
* Arguments    : p_mod -
*                    Pointer to the modulation data structure to be initialized
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_init(mod_t *p_mod)
{
   if (p_mod)
   {
       p_mod->f4_1_div_vdc = 1.0f;                      /* Default value */
       p_mod->f4_max_duty = MOD_DEFAULT_MAX_DUTY;
       p_mod->f4_min_duty = 0.0f;
       p_mod->f4_neutral_duty = MOD_DEFAULT_MAX_DUTY * 0.5f;
       p_mod->f4_voltage_error_ratio = 0.0f;
       mtr_mod_reset(p_mod);
   }
} /* End of function mtr_mod_init() */

/***********************************************************************************************************************
* Function Name: mtr_mod_reset
* Description  : Resets modulation module
* Arguments    : p_mod -
*                    Pointer to the modulation data structure to be initialized
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_reset(mod_t *p_mod)
{
    p_mod->u1_sat_flag = 0;
} /* End of function mtr_mod_reset() */

/***********************************************************************************************************************
* Function Name: mtr_mod_run
* Description  : Calculates duty cycle from input 3-phase voltage (bipolar)
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
*              : p_f4_v_in -
*                    Pointer to the 3-phase input voltage
*              : p_f4_duty_out -
*                    Where to store the 3-phase output duty cycle
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_run(mod_t *p_mod, const float *p_f4_v_in, float *p_f4_duty_out)
{
    float f4_v_out[3];

    if ((0 == p_mod) || (0 == p_f4_duty_out))
    {
        return;
    }

    mod_svpwm(p_f4_v_in, f4_v_out);

    p_f4_duty_out[0] = (f4_v_out[0] * p_mod->f4_1_div_vdc) + p_mod->f4_neutral_duty;
    p_f4_duty_out[1] = (f4_v_out[1] * p_mod->f4_1_div_vdc) + p_mod->f4_neutral_duty;
    p_f4_duty_out[2] = (f4_v_out[2] * p_mod->f4_1_div_vdc) + p_mod->f4_neutral_duty;

    mod_limit(p_mod, p_f4_duty_out);
} /* End of function mtr_mod_run() */

/***********************************************************************************************************************
* Function Name : mtr_mod2ab_run
* Description   : Calculate modulation factor
* Arguments     : f4_va, f4_vb       - ab-phase voltage [V],
*               : f4_vdc             - Bus voltage [V],
*               : f4_moda, f4_modb   - modulation factor variables (pointer)
* Return Value  : none
***********************************************************************************************************************/
void mtr_mod2ab_run(float f4_va, float f4_vb, float f4_vdc, float *f4_moda, float *f4_modb)
{
    float f4_temp0;

    f4_temp0 = 1.0f / f4_vdc;                               /* modulation range (- vdc -> vdc) to (0 -> 1 )  */
    *f4_moda = (f4_va * f4_temp0) * 0.5f + 0.5f;
    *f4_modb = (f4_vb * f4_temp0) * 0.5f + 0.5f;
}

/***********************************************************************************************************************
* Function Name: mtr_mod_RunUnipolar
* Description  : Calculates duty cycle from input 3-phase voltage (Unipolar)
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
*              : p_f4_v_in -
*                    Pointer to the 3-phase input voltage
*              : p_f4_duty_out -
*                    Where to store the 3-phase output duty cycle
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_RunUnipolar(mod_t *p_mod, const float *p_f4_v_in, float *p_f4_duty_out)
{
    float f4_v_out[3];

    if ((0 == p_mod) || (0 == p_f4_duty_out))
    {
        return;
    }

#if (MOD_METHOD == MOD_METHOD_SVPWM)
    mod_svpwm(p_f4_v_in, f4_v_out);
#endif

    p_f4_duty_out[0] = (f4_v_out[0] * p_mod->f4_1_div_vdc);
    p_f4_duty_out[1] = (f4_v_out[1] * p_mod->f4_1_div_vdc);
    p_f4_duty_out[2] = (f4_v_out[2] * p_mod->f4_1_div_vdc);

    mod_limit(p_mod, p_f4_duty_out);
} /* End of function mtr_mod_RunUnipolar() */

/***********************************************************************************************************************
* Function Name: mtr_mod_GetVdc
* Description  : Gets the DC bus voltage used in modulation
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
* Return Value : DC bus voltage
***********************************************************************************************************************/
float mtr_mod_GetVdc(mod_t *p_mod)
{
    return (p_mod->f4_vdc);
} /* End of function mtr_mod_GetVdc() */

/***********************************************************************************************************************
* Function Name: mtr_mod_SetVdc
* Description  : Sets the DC bus voltage used in modulation
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
*                f4_vdc -
*                    The DC bus voltage to be used in modulation
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_SetVdc(mod_t *p_mod, float f4_vdc)
{
    if (f4_vdc > 0.0f)
    {
        p_mod->f4_vdc = f4_vdc;
        p_mod->f4_1_div_vdc = 1.0f / f4_vdc;
    }
} /* End of function mtr_mod_SetVdc() */

/***********************************************************************************************************************
* Function Name: mtr_mod_GetMaxDuty
* Description  : Gets the maximum duty cycle
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
* Return Value : Maximum duty cycle
***********************************************************************************************************************/
float mtr_mod_GetMaxDuty(mod_t *p_mod)
{
    if (p_mod)
    {
       return (p_mod->f4_max_duty);
    }
    else
    {
        return 0.0f;
    }
} /* End of function mtr_mod_GetMaxDuty() */

/***********************************************************************************************************************
* Function Name: mtr_mod_SetMaxDuty
* Description  : Sets the maximum duty cycle
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
*                f4_max_duty -
*                    Maximum duty cycle to set
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_SetMaxDuty(mod_t *p_mod, float f4_max_duty)
{
    if ((0 != p_mod) && ((f4_max_duty > 0.0f) && (f4_max_duty <= 1.0f)))
    {
       p_mod->f4_max_duty = f4_max_duty;
       p_mod->f4_neutral_duty = (p_mod->f4_max_duty + p_mod->f4_min_duty) * 0.5f;
    }
} /* End of function mtr_mod_SetMaxDuty() */

/***********************************************************************************************************************
* Function Name: mtr_mod_GetMinDuty
* Description  : Gets the minimum duty cycle
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
* Return Value : minimum duty cycle
***********************************************************************************************************************/
float mtr_mod_GetMinDuty(mod_t *p_mod)
{
    if (p_mod)
    {
       return (p_mod->f4_min_duty);
    }
    else
    {
        return 0.0f;
    }
} /* End of function mtr_mod_GetMinDuty() */

/***********************************************************************************************************************
* Function Name: mtr_mod_SetMinDuty
* Description  : Sets the minimum duty cycle
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
*                f4_max_duty -
*                    Minimum duty cycle to set
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_SetMinDuty(mod_t *p_mod, float f4_min_duty)
{
    if ((0 != p_mod) && (f4_min_duty > 0.0f))
    {
       p_mod->f4_min_duty = f4_min_duty;
       p_mod->f4_neutral_duty = (p_mod->f4_max_duty + p_mod->f4_min_duty) * 0.5f;
    }
} /* End of function mtr_mod_SetMinDuty() */

/***********************************************************************************************************************
* Function Name: mtr_mod_SetVoltageErrorRatio
* Description  : Sets the voltage error ratio (VoltageError/Vdc)
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
*                f4_voltage_error_ratio -
*                    The voltage error ratio := (VoltageError/Vdc), can use the (Dead-time*CarrierFreq) approximately
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_SetVoltageErrorRatio(mod_t *p_mod, float f4_voltage_error_ratio)
{
       p_mod->f4_voltage_error_ratio = f4_voltage_error_ratio;
} /* End of function mtr_mod_SetVoltageErrorRatio() */

/***********************************************************************************************************************
* Function Name: mtr_mod_GetSaturationFlag
* Description  : Gets saturation flag
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
* Return Value : Saturation flag
*                   BIT0 - Phase U
*                   BIT1 - Phase V
*                   BIT2 - Phase W
*                   BIT3-7 - Reserved
***********************************************************************************************************************/
float mtr_mod_GetSaturationFlag(mod_t *p_mod)
{
#if (MOD_DETECT_SATURATION == 1)
    if (p_mod)
    {
        return (p_mod->u1_sat_flag);
    }
    else
    {
        return 0;
    }
#else
    /* When saturation detection disabled, always return 0 */
    return 0;
#endif
} /* End of function mtr_mod_GetSaturationFlag() */

/***********************************************************************************************************************
* Function Name: mtr_mod_GetVoltageMultiplier
* Description  : Gets the voltage multiplier
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
* Return Value : Voltage multiplier
***********************************************************************************************************************/
float mtr_mod_GetVoltageMultiplier(mod_t *p_mod)
{
    float f4_usable_duty_cycle;

    f4_usable_duty_cycle = (p_mod->f4_max_duty - p_mod->f4_min_duty) - (2.0f * p_mod->f4_voltage_error_ratio) ;

#if (MOD_METHOD == MOD_METHOD_SPWM)
    return (f4_usable_duty_cycle);
#elif (MOD_METHOD == MOD_METHOD_SVPWM)
    return (f4_usable_duty_cycle * MOD_SVPWM_MULT);
#endif
} /* End of function mtr_mod_GetVoltageMultiplier */

/***********************************************************************************************************************
* Function Name: mtr_mod_GetVamax
* Description  : Gets the maximum magnitude of voltage vector
* Arguments    : p_mod -
*                    The pointer to the modulation data structure
* Return Value : The maximum magnitude of voltage vector
***********************************************************************************************************************/
float mtr_mod_GetVamax(mod_t *p_mod)
{
    return ((MOD_VDC_TO_VAMAX_MULT * p_mod->f4_vdc) * mtr_mod_GetVoltageMultiplier(p_mod));
} /* End of function mtr_mod_GetVamax */
