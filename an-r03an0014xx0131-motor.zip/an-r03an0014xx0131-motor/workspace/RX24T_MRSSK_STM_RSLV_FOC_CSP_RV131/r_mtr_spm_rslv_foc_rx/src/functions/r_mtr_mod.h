/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_mtr_mod.h
* Description  : Definitions for modulation module
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

#ifndef R_MTR_MOD_H_
#define R_MTR_MOD_H_

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "r_mtr_config.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* Select SVPWM as default method when MOD_METHOD is undefined */
#ifndef MOD_METHOD
#define MOD_METHOD                  (MOD_METHOD_SVPWM)
#endif

#define MOD_DEFAULT_MAX_DUTY        (1.0f)          /* Default maximum duty cycle */
#define MOD_METHOD_SPWM             (0)             /* Sinusoidal pulse-width-modulation */
#define MOD_METHOD_SVPWM            (1)             /* Space vector pulse-width-modulation */
#define MOD_SATFLAG_BITU            (1 << 0)        /* Saturation flag bit for U phase */
#define MOD_SATFLAG_BITV            (1 << 1)        /* Saturation flag bit for V phase */
#define MOD_SATFLAG_BITW            (1 << 2)        /* Saturation flag bit for W phase */

/*
 * Vamax in this module is calculated by the following equation
 *   SVPWM :  Vdc * (MOD_VDC_TO_VAMAX_MULT) * (Max duty - Min duty) * (MOD_SVPWM_MULT)
 *   SPWM  :  Vdc * (MOD_VDC_TO_VAMAX_MULT) * (Max duty - Min duty)
 */
#define MOD_VDC_TO_VAMAX_MULT       (0.97f)         /* The basic coefficient used to convert Vdc to Vamax 1:1 */
#define MOD_SVPWM_MULT              (1.155f)        /* The usable voltage is multiplied by sqrt(4/3) when using SVPWM */

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
typedef struct
{
    float f4_vdc;                                   /* Vdc */
    float f4_1_div_vdc;                             /* 1/Vdc */
    float f4_voltage_error_ratio;                   /* The voltage error ratio (VoltageError/Vdc) */
    float f4_max_duty;                              /* Maximum duty cycle (default:1.0) */
    float f4_min_duty;                              /* Minimum duty cycle (default:0.0) */
    float f4_neutral_duty;                          /* Duty cycle that represents 0[V] */
    uint8_t u1_sat_flag;                            /* Saturation flag */
}mod_t;

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: mtr_mod_init
* Description  : Initializes modulation module
* Arguments    : p_mod -
*                    Pointer to the modulation data structure to be initialized
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_init(mod_t *p_mod);

/***********************************************************************************************************************
* Function Name: mtr_mod_reset
* Description  : Resets modulation module
* Arguments    : p_mod -
*                    Pointer to the modulation data structure to be initialized
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_reset(mod_t *p_mod);

/***********************************************************************************************************************
* Function Name: mtr_mod_run
* Description  : Calculates duty cycle from input 3-phase voltage (bipolar);
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
*              : p_f4_v_in -
*                    Pointer to the 3-phase input voltage
*              : p_f4_duty_out -
*                    Where to store the 3-phase output duty cycle
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_run(mod_t *p_mod, const float *p_f4_v_in, float *p_f4_duty_out);

/***********************************************************************************************************************
* Function Name : mtr_mod2ab_run
* Description   : Calculate modulation factor
* Arguments     : f4_va, f4_vb       - ab-phase voltage [V],
*               : f4_vdc             - Bus voltage [V],
*               : f4_moda, f4_modb   - modulation factor variables (pointer)
* Return Value  : none
***********************************************************************************************************************/
void mtr_mod2ab_run(float f4_va, float f4_vb, float f4_vdc, float *f4_moda, float *f4_modb);

/***********************************************************************************************************************
* Function Name: mtr_mod_RunUnipolar
* Description  : Calculates duty cycle from input 3-phase voltage (Unipolar);
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
*              : p_f4_v_in -
*                    Pointer to the 3-phase input voltage
*              : p_f4_duty_out -
*                    Where to store the 3-phase output duty cycle
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_RunUnipolar(mod_t *p_mod, const float *p_f4_v_in, float *p_f4_duty_out);

/***********************************************************************************************************************
* Function Name: mtr_mod_GetVdc
* Description  : Gets the DC bus voltage used in modulation
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
* Return Value : DC bus voltage
***********************************************************************************************************************/
float mtr_mod_GetVdc(mod_t *p_mod);

/***********************************************************************************************************************
* Function Name: mtr_mod_SetVdc
* Description  : Sets the DC bus voltage used in modulation
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
*                f4_vdc -
*                    The DC bus voltage to be used in modulation
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_SetVdc(mod_t *p_mod, float f4_vdc);

/***********************************************************************************************************************
* Function Name: mtr_mod_GetMaxDuty
* Description  : Gets the maximum duty cycle
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
* Return Value : Maximum duty cycle
***********************************************************************************************************************/
float mtr_mod_GetMaxDuty(mod_t *p_mod);

/***********************************************************************************************************************
* Function Name: mtr_mod_SetMaxDuty
* Description  : Sets the maximum duty cycle
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
*                f4_max_duty -
*                    Maximum duty cycle to set
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_SetMaxDuty(mod_t *p_mod, float f4_max_duty);

/***********************************************************************************************************************
* Function Name: mtr_mod_GetMinDuty
* Description  : Gets the minimum duty cycle
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
* Return Value : minimum duty cycle
***********************************************************************************************************************/
float mtr_mod_GetMinDuty(mod_t *p_mod);

/***********************************************************************************************************************
* Function Name: mtr_mod_SetMinDuty
* Description  : Sets the minimum duty cycle
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
*                f4_max_duty -
*                    Minimum duty cycle to set
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_SetMinDuty(mod_t *p_mod, float f4_min_duty);

/***********************************************************************************************************************
* Function Name: mtr_mod_SetVoltageErrorRatio
* Description  : Sets the voltage error ratio (VoltageError/Vdc);
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
*                f4_voltage_error_ratio -
*                    The voltage error ratio := (VoltageError/Vdc), can use the (Dead-time*CarrierFreq) approximately
* Return Value : None
***********************************************************************************************************************/
void mtr_mod_SetVoltageErrorRatio(mod_t *p_mod, float f4_voltage_error_ratio);

/***********************************************************************************************************************
* Function Name: mtr_mod_GetSaturationFlag
* Description  : Gets saturation flag
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
* Return Value : Saturation flag
*                   BIT0 - Phase U
*                   BIT1 - Phase V
*                   BIT2 - Phase W
*                   BIT3-7 - Reserved
***********************************************************************************************************************/
float mtr_mod_GetSaturationFlag(mod_t *p_mod);

/***********************************************************************************************************************
* Function Name: mtr_mod_GetVoltageMultiplier
* Description  : Gets the voltage multiplier
* Arguments    : p_mod -
*                    Pointer to the modulation data structure
* Return Value : Voltage multiplier
***********************************************************************************************************************/
float mtr_mod_GetVoltageMultiplier(mod_t *p_mod);

/***********************************************************************************************************************
* Function Name: mtr_mod_GetVamax
* Description  : Gets the maximum magnitude of voltage vector
* Arguments    : p_mod -
*                    The pointer to the modulation data structure
* Return Value : The maximum magnitude of voltage vector
***********************************************************************************************************************/
float mtr_mod_GetVamax(mod_t *p_mod);

#endif /* R_MOD_H_ */
