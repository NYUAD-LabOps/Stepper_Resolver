/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_speed_observer.h
* Description : Definitions of a speed observer processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_SPEED_OBSERVER_H
#define R_MTR_SPEED_OBSERVER_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_common.h"
#include "r_mtr_filter.h"
#include "r_mtr_parameter.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
#define     SOB_SPEED_CTRL_PERIOD   (MTR_CTRL_PERIOD)/* control period (Speed Loop) [s] */

/* design parameter */
#define     SOB_OMEGA               (CP_SOB_OMEGA)  /* natural frequency for speed observer */
#define     SOB_ZETA                (CP_SOB_ZETA)   /* damping ratio for speed observer */
#define     SOB_HPF_OMEGA           (1.0f)             /* natural frequency for speed observer HPF */

/* SPEED OBSERVER HPF GAIN */
#define     SOB_HPF_K2              (2.0f / SOB_SPEED_CTRL_PERIOD)
                                                    /* speed observer HPF gain */
#define     SOB_HPF_K3              (-(1.0f - SOB_HPF_K2))
                                                    /* speed observer HPF gain */

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
typedef struct
{
    float      f4_speed_rad;                        /* speed observer output speed [rad/s] (electrical) */
    float      f4_ref_torque;                       /* reference torque */
    float      f4_ref_pre_torque;                   /* previous value of reference torque */
    float      f4_ref_speed_rad;                    /* reference speed for sob [rad/s] (electrical) */
    float      f4_ref_pre_speed_rad;                /* previous value of reference speed for sob [rad/s] (electrical) */
    float      f4_hpf_k1;                           /* HPF gain for sob */
    float      f4_hpf_k2;                           /* HPF gain for sob */
    float      f4_hpf_k3;                           /* HPF gain for sob */
    float      f4_k1;                               /* K1 gain for sob */
    float      f4_k2;                               /* K2 gain for sob */
    float      f4_hpf_ref_speed_rad;                /* HPF output reference speed [rad/s] */
    float      f4_hpf_ref_pre_speed_rad;            /* previous value of HPF output reference speed [rad/s] */
    float      f4_hpf_omega;                        /* natural frequency for speed observer HPF */
    mtr_2nd_order_lpf_t st_lpf;                     /* second order LPF structure */
} mtr_speed_observer_t;

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name : mtr_speed_observer_init
* Description   : Initialize variables when speed observer init
* Arguments     : st_sob               - speed observer structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void mtr_speed_observer_init(mtr_speed_observer_t *st_sob);

/***********************************************************************************************************************
* Function Name : mtr_speed_observer_reset
* Description   : Reset variables when speed observer control
* Arguments     : st_sob               - speed observer structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void mtr_speed_observer_reset(mtr_speed_observer_t *st_sob);

/***********************************************************************************************************************
* Function Name : mtr_speed_observer
* Description   : speed observer
* Arguments     : st_sob           - speed observer structure
                  st_motor         - The pointer to the motor parameter structure
                  f4_ref_iq_ctrl        - reference iq [A]
                  f4_speed_rad     - motor speed [rad/s]
* Return Value  : f4_ref_speed_sob - observer output speed [rad/s]
***********************************************************************************************************************/
float mtr_speed_observer(mtr_speed_observer_t *st_sob, mtr_parameter_t *st_motor, float f4_ref_iq_ctrl, float f4_speed_rad);

/* control gains calculation */

/***********************************************************************************************************************
* Function Name : mtr_speed_observer_gain_calc
* Description   : Gain calculation for speed observer
* Arguments     : st_sob               - speed observer structure
                  st_design_params     - The pointer to the design parameter structure
                  f4_speed_ctrl_period - control period for speed loop
* Return Value  : None
***********************************************************************************************************************/
void mtr_speed_observer_gain_calc(mtr_speed_observer_t *st_sob,
                                  mtr_design_parameter_t *st_design_params,
                                  float f4_speed_ctrl_period);

#endif /* R_MTR_SPEED_OBSERVER_H */
