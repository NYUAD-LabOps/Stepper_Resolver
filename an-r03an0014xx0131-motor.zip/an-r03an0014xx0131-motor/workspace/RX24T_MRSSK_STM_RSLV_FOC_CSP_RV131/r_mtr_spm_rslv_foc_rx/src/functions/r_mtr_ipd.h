/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_ipd.h
* Description : Definitions of a IPD control processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_IPD_H
#define R_MTR_IPD_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_common.h"
#include "r_mtr_filter.h"
#include "r_mtr_parameter.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
#define    POS_LPF_OMEGA          (200.0f)   /* Natural frequency [Hz] for position HPF */
#define    POS_LPF_ZETA           (1.0f)     /* Damping ratio for position HPF, 1.0 for most app */
#define    POS_SPEED_RATIO        (3.0f)     /* Default speed gain ratio for I-PD, 2.0 for most app, up to 3.0 */
#define    POS_FF_RATIO           (0.9f)     /* Position feed-forward ratio, 1.0 for most app,
                                              *  down to 0.9 to avoid over-shot, less than 0.9 will cause distortion of
                                              *  speed reference waveform
                                              */
#define    POS_KP_RATIO           (0.0f)     /* Position KP ratio, 0.0 ~ 0.4, 0.0 for most app, increase it to faster
                                              * the position loop */
#define    POS_IPD_ERR_LIMIT_1    (10.0f)    /* position error limit 1 [rad], limit the position error input to
                                              * the integrator to avoid saturation  */
#define    POS_IPD_ERR_LIMIT_2    (1.0f)     /* position error limit 2, in ratio of the maximum speed [rad/s]
                                              * e.g. 0.2 means limiting the output of IPD to 20% of the maximum speed,
                                              * so the speed command will rely on the speed feed-forward */

#define    LPF_FLAG               (LPF_ON)   /* initial set position LPF ON/OFF */
#define    LPF_OFF                (0)        /* position LPF OFF */
#define    LPF_ON                 (1)        /* position LPF ON */

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
typedef struct
{
    /* I-PD control */
    uint8_t  u1_ipd_lpf_flag;              /* 0 : LPF OFF(default) 1 : LPF ON */
    float    f4_ref_pos_pre_rad_ctrl;      /* previous position value for control [rad] (mechanical) */
    float    f4_ipd_pos_k;                 /* position control gain for I-PD */
    float    f4_ipd_pos_1st_fb_rad;        /* feed-back position [rad] (mechanical) */
    float    f4_ipd_pos_1st_fb_pre_rad;    /* previous value of feed-back position [rad] (mechanical) */
    float    f4_ipd_pos_2nd_fb_rad;        /* feed-back position [rad] (mechanical) */
    float    f4_ipd_ref_pos_rad;           /* ipd control reference [rad] (mechanical) */
    float    f4_ipd_err_rad;               /* ipd control error [rad] (mechanical) */
    float    f4_ipd_pos_fb_k;              /* feedback gain for I-PD */
    float    f4_ipd_pos_ff_rad;            /* feed-forward position [rad] (mechanical) */
    float    f4_ipd_pos_ff_k;              /* feed-forward position control gain */
    float    f4_ipd_pos_p_rad;             /* proportional control [rad] (mechanical) */
    float    f4_ipd_pos_kp;                /* position control gain kp */
    float    f4_ipd_pos_kp_ratio;          /* position contorl gain kp ratio */
    float    f4_ipd_pos_ff_ratio;          /* position feed-forward gain ratio */
    float    f4_ipd_speed_k;               /* speed gain for I-PD */
    float    f4_ipd_speed_k_ratio;         /* speed gain for I-PD gain ratio */
    float    f4_ipd_ref_speed_rad;         /* reference speed [rad/s] (electrical) */
    float    f4_ipd_err_limit_1;           /* position error limit 1 */
    float    f4_ipd_err_limit_2;           /* position error limit 2 */
    float    f4_ipd_lpf_omega;             /* natural frequency for position LPF */
    float    f4_ipd_lpf_zeta;              /* damping ratio for position LPF */
    mtr_2nd_order_lpf_t  st_pos_lpf;       /* second order LPF structure */
} mtr_ipd_ctrl_t;

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name : mtr_ipd_ctrl_init
* Description   : Initialize variables when IPD control init
* Arguments     : st_ipd - The pointer to the IPD control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_ipd_ctrl_init(mtr_ipd_ctrl_t *st_ipd);

/***********************************************************************************************************************
* Function Name : mtr_ipd_ctrl_reset
* Description   : Reset variables when IPD control reset
* Arguments     : st_ipd - The pointer to the IPD control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_ipd_ctrl_reset(mtr_ipd_ctrl_t *st_ipd);

/***********************************************************************************************************************
* Function Name : mtr_set_param_pos_kp_ratio
* Description   : Set parameter for position control gain kp ratio
* Arguments     : st_ipd              - The pointer to the IPD control structure
*                 f4_ipd_pos_kp_ratio - position control gain kp ratio
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_pos_kp_ratio(mtr_ipd_ctrl_t *st_ipd, float f4_ipd_pos_kp_ratio);

/***********************************************************************************************************************
* Function Name : mtr_set_param_pos_ff_ratio
* Description   : Set parameter for position feed-forward gain ratio
* Arguments     : st_ipd               - The pointer to the IPD control structure
*                 f4_ipd_pos_ff_ratio  - position feed-forward gain ratio
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_pos_ff_ratio(mtr_ipd_ctrl_t *st_ipd, float f4_ipd_pos_ff_ratio);

/***********************************************************************************************************************
* Function Name : mtr_set_param_speed_k_ratio
* Description   : Set parameter for speed gain for I-PD gain ratio
* Arguments     : st_ipd               - The pointer to the IPD control structure
*                 f4_ipd_speed_k_ratio - speed gain for I-PD gain ratio
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_speed_k_ratio(mtr_ipd_ctrl_t *st_ipd, float f4_ipd_speed_k_ratio);

/***********************************************************************************************************************
* Function Name : mtr_set_param_err_limit_1
* Description   : Set parameter for position error limit 1
* Arguments     : st_ipd               - The pointer to the IPD control structure
*                 f4_ipd_err_limit_1   - position error limit 1
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_err_limit_1(mtr_ipd_ctrl_t *st_ipd, float f4_ipd_err_limit_1);

/***********************************************************************************************************************
* Function Name : mtr_set_param_err_limit_2
* Description   : Set parameter for position error limit 2
* Arguments     : st_ipd               - The pointer to the IPD control structure
*                 f4_ipd_err_limit_2   - position error limit 2
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_param_err_limit_2(mtr_ipd_ctrl_t *st_ipd, float f4_ipd_err_limit_2);

/***********************************************************************************************************************
* Function Name : mtr_ipd_ctrl_gain_calc
* Description   : Gain calculation for IPD control
* Arguments     : st_motor             - The pointer to the motor parameter structure
                  st_design_params     - The pointer to the design parameter structure
                  st_ipd               - The pointer to the IPD control structure
                  f4_speed_ctrl_period - control period for speed loop
* Return Value  : None
***********************************************************************************************************************/
void mtr_ipd_ctrl_gain_calc(mtr_parameter_t *st_motor,
                            mtr_design_parameter_t *st_design_params,
                            mtr_ipd_ctrl_t *st_ipd,
                            float f4_speed_ctrl_period);

/***********************************************************************************************************************
* Function Name : mtr_ipd_speed_p_ctrl
* Description   : Speed propotional control for IPD
* Arguments     : st_ipd               - The pointer to the IPD control structure
*                 f4_ref_speed_rad     - command value of speed value [rad/s]
*                 f4_speed_rad         - speed [rad/s] (electrical)
* Return Value  : f4_ref_iq_calc       - q axis current reference
***********************************************************************************************************************/
float mtr_ipd_speed_p_ctrl(mtr_ipd_ctrl_t *st_ipd, float f4_ref_speed_rad, float f4_speed_rad);

/***********************************************************************************************************************
* Function Name : mtr_ipd_error_calc
* Description   : position error calcuration for IPD
* Arguments     : st_ipd               - The pointer to the IPD control structure
*                 f4_pos_rad           - position [rad] (mechancal)
*                 f4_ref_pos_rad_ctrl  - command value of position control
* Return Value  : f4_pos_err           - position error [rad] (mechanical)
***********************************************************************************************************************/
float mtr_ipd_error_calc(mtr_ipd_ctrl_t *st_ipd, float f4_pos_rad, float f4_ref_pos_rad_ctrl);

/***********************************************************************************************************************
* Function Name : mtr_ipd_ctrl
* Description   : IPD control
* Arguments     : st_ipd                - The pointer to the IPD control structure
*                 st_motor              - The pointer to the motor parameter structure
*                 f4_pos_err_rad        - position error [rad] (mechanical)
*                 f4_pos_rad            - position [rad]
*                 f4_max_speed_rad      - maximum speed [rad/s]
* Return Value  : f4_speed_ref_calc_rad - Speed reference [rad/s]
***********************************************************************************************************************/
float mtr_ipd_ctrl(mtr_ipd_ctrl_t *st_ipd, mtr_parameter_t *st_motor, float f4_pos_err_rad, float f4_pos_rad, float f4_max_speed_rad);

#endif /* R_MTR_IPD_H */
