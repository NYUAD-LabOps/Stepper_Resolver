/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_mtr_fluxwkn.h
* Description  : Definitions for flux weakening module
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

#ifndef R_MTR_FLUXWKN_H
#define R_MTR_FLUXWKN_H

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_parameter.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define FLUXWKN_DEF_VFWRATIO            (0.95f)     /* Defines default flux-weakening voltage ratio */
#define FLUXWKN_DEF_VFWRATIO_MIN        (0.5f)      /* Defines default minimum flux-weakening voltage ratio */

/**
 * Flux-weakening-states
 */
#define FLUXWKN_STATE_BYPASSED          (0x0000)    /* Flux-weakening control is not necessary, module is bypassed */
#define FLUXWKN_STATE_FLUXWKN           (0x0001)    /* Normal flux-weakening state */
#define FLUXWKN_STATE_IDSAT             (0x0002)    /* D-axis current has already saturated */
#define FLUXWKN_STATE_ERROR             (0x8000)    /* Flux-weakening general/runtime error */
#define FLUXWKN_STATE_INVALID_MOTOR     (0x9001)    /* Motor pointer is null or either of Ld, Lq, flux is below 0 */
#define FLUXWKN_STATE_INVALID_IAMAX     (0x9002)    /* Invalid maximum Ia value (Iamax < 0.0) */
#define FLUXWKN_STATE_INVALID_VAMAX     (0x9003)    /* Invalid maximum Va value (Vamax < 0.0)  */
#define FLUXWKN_STATE_INVALID_VFWRATIO  (0x9004)    /* Invalid flux-weakening maximum voltage ratio, that f4_vfw_ratio
                                                     * is out of range [VFWRATIO_MIN, 1.0]  */

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
/**
 * Flux-weakening data structure
 */
typedef struct
{
    /* User configurations */
    const mtr_parameter_t *pmotor;      /* The pointer to the motor parameter data structure */
    float               f4_ia_max;      /* The maximum magnitude of current vector */
    float               f4_va_max;      /* The maximum magnitude of voltage vector */
    float               f4_vfw_ratio;   /* The maximum ratio of voltage used by flux-weakening module */

    /* Internal data */
    float               f4_id_demag;    /* The demagnetization current derived by (-flux/Ld) */
    float               f4_id_min;      /* The minimum Id output, min(-Ia,Id_demag) */
    float               f4_v_fw;        /* The target abs. limit value of voltage vector due to the total flux */
    uint16_t            u2_fw_status;   /* The status of flux-weakening */
}fluxwkn_t;

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: mtr_fluxwkn_init
* Description  : Initializes flux-weakening module
* Arguments    : p_fluxwkn - The pointer to the structure of flux-weakening module
*                f4_ia_max - The maximum magnitude of current vector
*                f4_va_max - The maximum magnitude of voltage vector
*                p_mtr - The pointer to the motor parameter data structure
* Note         : Other parameters will be set to the corresponding default value
* Return Value : None
***********************************************************************************************************************/
void mtr_fluxwkn_init(fluxwkn_t *p_fluxwkn, float f4_ia_max, float f4_va_max, const mtr_parameter_t *p_mtr);

/***********************************************************************************************************************
* Function Name: mtr_fluxwkn_reset
* Description  : Resets flux-weakening module
* Arguments    : p_fluxwkn - The pointer to the structure of flux-weakening module
* Return Value : None
***********************************************************************************************************************/
void mtr_fluxwkn_reset(fluxwkn_t *p_fluxwkn);

/***********************************************************************************************************************
* Function Name: mtr_fluxwkn_run
* Description  : Executes the flux-weakening module
* Arguments    : p_fluxwkn - The pointer to the structure of flux-weakening module
*                f4_speed_rad - The electrical speed of motor in [rad/s]
*                p_f4_idq - The pointer to the measured current vector (array) in format {Id,Iq}
*                p_f4_idq_ref - The pointer to the reference current vector (array) in format {Idref, Iqref}
* Return Value : Status of the module, refer to @ref Flux-weakening-states
***********************************************************************************************************************/
uint16_t mtr_fluxwkn_run(fluxwkn_t *p_fluxwkn, float f4_speed_rad, const float *p_f4_idq, float *p_f4_idq_ref);

/***********************************************************************************************************************
* Function Name: mtr_fluxwkn_SetMotor
* Description  : Setups the motor parameter
* Arguments    : p_fluxwkn - The pointer to the structure of flux-weakening module
*                p_mtr - The motor parameters to be used flux-weakening module
* Return Value : None
***********************************************************************************************************************/
void mtr_fluxwkn_SetMotor(fluxwkn_t *p_fluxwkn, const mtr_parameter_t *p_mtr);

/***********************************************************************************************************************
* Function Name: mtr_fluxwkn_SetIamax
* Description  : Sets the maximum magnitude of current vector
* Arguments    : p_fluxwkn - The pointer to the structure of flux-weakening module
*                f4_ia_max - The maximum magnitude of current vector
* Return Value : None
***********************************************************************************************************************/
void mtr_fluxwkn_SetIamax(fluxwkn_t *p_fluxwkn, float f4_ia_max);

/***********************************************************************************************************************
* Function Name: mtr_fluxwkn_SetVamax
* Description  : Sets the maximum magnitude of voltage vector
* Arguments    : p_fluxwkn - The pointer to the structure of flux-weakening module
*                f4_va_max - The maximum magnitude of voltage vector
* Return Value : None
***********************************************************************************************************************/
void mtr_fluxwkn_SetVamax(fluxwkn_t *p_fluxwkn, float f4_va_max);

/***********************************************************************************************************************
* Function Name: mtr_fluxwkn_SetVfwratio
* Description  : Sets the maximum available voltage ratio for the flux-weakening module
* Arguments    : p_fluxwkn - The pointer to the structure of flux-weakening module
*                f4_vfw_ratio - The maximum ratio of voltage available for flux-weakening module
* Return Value : None
***********************************************************************************************************************/
void mtr_fluxwkn_SetVfwRatio(fluxwkn_t *p_fluxwkn, float f4_vfw_ratio);

/***********************************************************************************************************************
* Function Name: mtr_fluxwkn_GetIamax
* Description  : Gets the maximum magnitude of current vector
* Arguments    : p_fluxwkn - The pointer to the structure of flux-weakening module
* Return Value : The maximum magnitude of current vector
***********************************************************************************************************************/
float mtr_fluxwkn_GetIamax(fluxwkn_t *p_fluxwkn);

/***********************************************************************************************************************
* Function Name: mtr_fluxwkn_GetVamax
* Description  : Gets the maximum magnitude of voltage vector
* Arguments    : p_fluxwkn - The pointer to the structure of flux-weakening module
* Return Value : The maximum magnitude of voltage vector
***********************************************************************************************************************/
float mtr_fluxwkn_GetVamax(fluxwkn_t *p_fluxwkn);

/***********************************************************************************************************************
* Function Name: mtr_fluxwkn_GetVfwRatio
* Description  : Gets the maximum available voltage ratio for the flux-weakening module
* Arguments    : p_fluxwkn - The pointer to the structure of flux-weakening module
* Return Value : Maximum available voltage ratio for the flux-weakening module
***********************************************************************************************************************/
float mtr_fluxwkn_GetVfwRatio(fluxwkn_t *p_fluxwkn);

/***********************************************************************************************************************
* Function Name: mtr_fluxwkn_GetStatus
* Description  : Gets the status of flux-weakening module
* Arguments    : p_fluxwkn - The pointer to the structure of flux-weakening module
* Return Value : Status of flux-weakening module, refer to Flux-weakening-states
***********************************************************************************************************************/
uint16_t mtr_fluxwkn_GetStatus(fluxwkn_t *p_fluxwkn);

/***********************************************************************************************************************
* Function Name: mtr_fluxwkn_IsError
* Description  : Checks if the status is an error (include "invalid parameter error");
* Arguments    : p_fluxwkn - The pointer to the structure of flux-weakening module
* Return Value : True(1) or False(0);
***********************************************************************************************************************/
uint8_t mtr_fluxwkn_IsError(fluxwkn_t *p_fluxwkn);

/***********************************************************************************************************************
* Function Name: mtr_fluxwkn_IsInvalidParameter
* Description  : Checks if the status is an invalid parameter error
* Arguments    : p_fluxwkn - The pointer to the structure of flux-weakening module
* Return Value : True(1) or False(0);
***********************************************************************************************************************/
uint8_t mtr_fluxwkn_IsInvalidParameter(fluxwkn_t *p_fluxwkn);

/***********************************************************************************************************************
* Function Name: mtr_fluxwkn_IsRunTimeError
* Description  : Checks if the status is an run-time error
* Arguments    : p_fluxwkn - The pointer to the structure of flux-weakening module
* Return Value : True(1) or False(0);
***********************************************************************************************************************/
uint8_t mtr_fluxwkn_IsRunTimeError(fluxwkn_t *p_fluxwkn);

#endif /* R_MTR_FLUXWKN_H */
