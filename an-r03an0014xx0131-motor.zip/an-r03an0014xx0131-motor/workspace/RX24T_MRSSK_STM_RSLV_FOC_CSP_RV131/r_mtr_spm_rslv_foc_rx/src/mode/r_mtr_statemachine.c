/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_statemachine.c
* Description : The state machine for motor drive system
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "r_mtr_common.h"
#include "r_mtr_statemachine.h"

/***********************************************************************************************************************
* Private functions
***********************************************************************************************************************/
static uint8_t state_transition_table[MTR_SIZE_EVENT][MTR_SIZE_STATE] = {
/* State                 0:MTR_MODE_INACTIVE, 1:MTR_MODE_ACTIVE, 2:MTR_MODE_ERROR */
/* Event */
/* 0:MTR_EVENT_INACTIVE */{ MTR_MODE_INACTIVE,   MTR_MODE_INACTIVE, MTR_MODE_ERROR    },
/* 1:MTR_EVENT_ACTIVE   */{ MTR_MODE_ACTIVE,     MTR_MODE_ACTIVE,   MTR_MODE_ERROR    },
/* 2:MTR_EVENT_ERROR    */{ MTR_MODE_ERROR,      MTR_MODE_ERROR,    MTR_MODE_ERROR    },
/* 3:MTR_EVENT_RESET    */{ MTR_MODE_INACTIVE,   MTR_MODE_ERROR,    MTR_MODE_INACTIVE },};

static mtr_action_t action_table[MTR_SIZE_EVENT][MTR_SIZE_STATE] = {
/* State                 0:MTR_MODE_INACTIVE, 1:MTR_MODE_ACTIVE, 2:MTR_MODE_ERROR */
/* Event */
/* 0:MTR_EVENT_INACTIVE */{ mtr_act_inactive,    mtr_act_inactive,  mtr_act_none  },
/* 1:MTR_EVENT_ACTIVE   */{ mtr_act_active,      mtr_act_none,      mtr_act_none  },
/* 2:MTR_EVENT_ERROR    */{ mtr_act_error,       mtr_act_error,     mtr_act_none  },
/* 3:MTR_EVENT_RESET    */{ mtr_act_reset,       mtr_act_error,     mtr_act_reset },};

/***********************************************************************************************************************
* Function Name : mtr_statemachine_init
* Description   : Initializes state machine for motor drive system
* Arguments     : p_state_machine   - the pointer to the state machine data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_statemachine_init(mtr_statemachine_t *p_state_machine)
{
    mtr_statemachine_reset(p_state_machine);
} /* End of function mtr_statemachine_init */

/***********************************************************************************************************************
* Function Name : mtr_statemachine_reset
* Description   : Resets state machine
* Arguments     : p_state_machine   - the pointer to the state machine data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_statemachine_reset(mtr_statemachine_t *p_state_machine)
{
    p_state_machine->u1_status          = MTR_MODE_INACTIVE;
    p_state_machine->u1_status_next     = MTR_MODE_INACTIVE;
    p_state_machine->u2_error_status    = MTR_STATEMACHINE_ERROR_NONE;
    p_state_machine->u1_current_event   = 0;
} /* End of function mtr_statemachine_reset */

/***********************************************************************************************************************
* Function Name : mtr_statemachine_event
* Description   : Performs state transition and execute corresponding action when
*                 specified event happen
* Arguments     : p_state_machine   - the pointer to the state machine data structure
*                 p_object          - the pointer to parameters passed to the action handler
*                 u1_event          - the event index to be executed
*                       MTR_EVENT_INACTIVE  Stop the motor drive system
*                       MTR_EVENT_ACTIVE    Activate the motor drive system
*                       MTR_EVENT_ERROR     Throw an error and stop driving
*                       MTR_EVENT_RESET     Reset the configurations of motor drive system
* Return Value  : The error flags of the state machine
*                       BIT0: Event index is out of bound, please check the u1_event
*                       BIT1: State index is out of bound
*                       BIT2: Action error (value other than 0 returned from action)
***********************************************************************************************************************/
uint8_t mtr_statemachine_event(mtr_statemachine_t *p_state_machine, void *p_object, uint8_t u1_event)
{
    mtr_action_t func_action;
    uint8_t action_ret;

    /* Check if accessing state transition table out of bound */
    if (MTR_SIZE_EVENT <= u1_event)
    {
        /* Event is out of bound */
        u1_event = MTR_EVENT_ERROR;
        p_state_machine->u2_error_status |= MTR_STATEMACHINE_ERROR_EVENTOUTBOUND;
    }
    if (MTR_SIZE_STATE <= p_state_machine->u1_status)
    {
        /* State is out of bound */
        u1_event = MTR_EVENT_ERROR;
        p_state_machine->u1_status = MTR_MODE_INACTIVE;
        p_state_machine->u2_error_status |= MTR_STATEMACHINE_ERROR_STATEOUTBOUND;
    }

    /*
     * u1_current_event : Event happening
     * u1_status        : Current status
     * u1_status_next   : Status after action executed
     */
    p_state_machine->u1_current_event = u1_event;
    p_state_machine->u1_status_next   = state_transition_table[u1_event][p_state_machine->u1_status];

    /* Get action function from action table and execute action */
    func_action = action_table[u1_event][p_state_machine->u1_status];
    action_ret  = func_action(p_state_machine, p_object);

    /* If return value is not zero, set the Action Exception flag */
    if (action_ret)
    {
        p_state_machine->u2_error_status |= MTR_STATEMACHINE_ERROR_ACTIONEXCEPTION;
    }
    p_state_machine->u1_status = p_state_machine->u1_status_next;

    return (p_state_machine->u2_error_status);
} /* End of function mtr_statemachine_event */

/***********************************************************************************************************************
* Function Name : mtr_statemachine_get_status
* Description   : Gets the status of system
* Arguments     : p_state_machine - the pointer to the state machine data structure
* Return Value  : Status of system
***********************************************************************************************************************/
uint8_t mtr_statemachine_get_status(mtr_statemachine_t *p_state_machine)
{
    return (p_state_machine->u1_status);
} /* End of function mtr_statemachine_get_status */
