/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_foc_action.c
* Description : The implementations of action functions required by FOC state machine (r_mtr_statemachine)
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <stdint.h>

/* Main associated header file */
#include "r_mtr_foc_stm_rslv_control.h"

/* Project headers */
#include "r_mtr_common.h"
#include "r_mtr_ctrl_mcu.h"
#include "r_mtr_statemachine.h"
#include "r_rslv_api.h"

/***********************************************************************************************************************
* Function Name : mtr_act_active
* Description   : Activates the motor control system and enables PWM output
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the FOC structure
* Return Value  : The result of action, Always success(0)
***********************************************************************************************************************/
uint8_t mtr_act_active(mtr_statemachine_t *st_stm, void *p_param)
{
    mtr_foc_control_t *pfoc = p_param;

    mtr_foc_motor_reset(pfoc);                  /* Initialize variables when motor control start */
    mtr_ctrl_start(pfoc->u1_id);                /* PWM output enable */

    return (0);
} /* End of function mtr_act_active */

/***********************************************************************************************************************
* Function Name : mtr_act_inactive
* Description   : Deactivates the motor control system and disables PWM output
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the FOC structure
* Return Value  : The result of action, Always success(0)
***********************************************************************************************************************/
uint8_t mtr_act_inactive(mtr_statemachine_t *st_stm, void *p_param)
{
    mtr_foc_control_t *pfoc = p_param;

    mtr_ctrl_stop(pfoc->u1_id);                       /* PWM output disable */
    mtr_foc_motor_reset(pfoc);                  /* Initialize variables when motor control start */

    return (0);
} /* End of function mtr_act_inactive */

/***********************************************************************************************************************
* Function Name : mtr_act_none
* Description   : The empty dummy function used to fill the blank in action table
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the FOC structure
* Return Value  : Always success (0)
***********************************************************************************************************************/
uint8_t mtr_act_none(mtr_statemachine_t *st_stm, void *p_param)
{
    /* Do Nothing */

    return (0);
} /* End of function mtr_act_none */

/***********************************************************************************************************************
* Function Name : mtr_act_reset
* Description   : Resets the configurations to default and clear error flags
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the FOC structure
* Return Value  : The result of action, Always success(0)
***********************************************************************************************************************/
uint8_t mtr_act_reset(mtr_statemachine_t *st_stm, void *p_param)
{
    mtr_foc_control_t *pfoc = p_param;

    mtr_foc_motor_default_init(pfoc);

    return (0);
} /* End of function mtr_act_reset */

/***********************************************************************************************************************
* Function Name : mtr_act_error
* Description   : Executes the post-processing (include stopping the PWM output) when an error has been detected
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the FOC structure
* Return Value  : The result of action, Always success(0)
***********************************************************************************************************************/
uint8_t mtr_act_error(mtr_statemachine_t *st_stm, void *p_param)
{
    mtr_foc_control_t *pfoc = p_param;

    mtr_ctrl_stop(pfoc->u1_id);                       /* PWM output disable */

    R_RSLV_Rdc_AlarmCancel();

    return (0);
} /* End of function mtr_act_error */
