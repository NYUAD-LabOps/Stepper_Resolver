/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : r_mtr_stm_rslv_foc_rx.c
 * Version      : 1.00
 * Description  :
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * History : DD.MM.YYYY Version
 *           23.04.2021 1.31     First Release
 *********************************************************************************************************************/

/**********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
 *********************************************************************************************************************/
/* Standard library headers */
#include <stdint.h>
#include <math.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <machine.h>
/* Main associated header file */
#include "r_mtr_stm_rslv_foc_rx_if.h"

/* Project headers */
#include "r_mtr_ics.h"
#include "r_mtr_common.h"
#include "r_mtr_statemachine.h"
#include "r_mtr_parameter.h"
#include "r_mtr_foc_speed.h"
#include "r_mtr_ctrl_mcu.h"
#include "r_mtr_ctrl_inverter.h"
#include "r_mtr_foc_stm_rslv_control.h"
#include "r_flash_access.h"
#include "r_mtr_variables.h"
#include "r_mtr_ctrl_gain_calc.h"
#include "r_ctrl_rdc_driver_adapter.h"

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static uint8_t r_mtr_chk_input_id(uint8_t u1_id);

mtr_ctrl_input_t gs_st_ctrl_input_buff;     /* Structure for ICS input */
static uint8_t          gs_u1_trig_enable_write;   /* The trigger for FOC command and configuration update */
static mtr_foc_control_t *sp_st_mtr;               /* Pointer of Real Motor Instance */

/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_Open
 * Description  : Create a Motor Instance of Resolver Foc Control
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 * Return Value : MTR_SUCCESS -
 *                   A motor instance was opened(created) successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_Open(uint8_t u1_id)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    sp_st_mtr = &g_st_foc;

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_Open
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_Close
 * Description  : Close a Motor Instance of Resolver Foc Control
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 * Return Value : MTR_SUCCESS -
 *                   A motor instance was closed successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_Close(uint8_t u1_id)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    sp_st_mtr = NULL;

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_Close
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_InitVariables
 * Description  : Initialize Common Parameters for Resolver Vector Control
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 * Return Value : MTR_SUCCESS -
 *                   Parameters are set successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_InitVariables(uint8_t u1_id)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    /* Initialize system state machine */
    mtr_statemachine_init(&sp_st_mtr->st_stm);

    /* Store the id to access HW resources */
    sp_st_mtr->u1_id = u1_id;

    /* Reset configurations to default */
    mtr_foc_motor_default_init(sp_st_mtr);

    /* initialize member of ICS input buffer structure */
    gs_st_ctrl_input_buff.u1_flag_angle_spl_comp_use = USE_RSLV_SPLTM_COMP;
    gs_st_ctrl_input_buff.u1_flag_cc_spl_comp_use    = USE_CC_SPLDLY_COMP;
    gs_st_ctrl_input_buff.u1_flag_bpf_delay_comp_use = USE_BPF_DELAY_COMP;
    gs_st_ctrl_input_buff.u1_flag_sob_use            = USE_SOB;
    gs_st_ctrl_input_buff.u1_flag_volt_err_comp_use  = USE_VOLT_ERR_COMP;
    gs_st_ctrl_input_buff.u1_flag_flux_weakening_use = USE_FLUX_WEAKENING;

    gs_st_ctrl_input_buff.u1_ctrl_loop_mode_buff     = LOOP_MODE;
    gs_st_ctrl_input_buff.u1_ctrl_method_mode        = POS_CTRL_MODE;
    gs_st_ctrl_input_buff.u1_state_pos_ref_buff      = MTR_POS_TRAPEZOID;
    gs_st_ctrl_input_buff.u1_offset_adjust_mode_buff = OFFSET_ADJUST_MODE;

    gs_st_ctrl_input_buff.u1_direction          = MTR_CW;
    gs_st_ctrl_input_buff.f4_ref_position_deg   = 0;
    gs_st_ctrl_input_buff.s2_ref_speed_rpm      = 0;
    gs_st_ctrl_input_buff.u2_min_speed_rpm      = MTR_MIN_SPEED_RPM;
    gs_st_ctrl_input_buff.u2_max_speed_rpm      = MTR_MAX_SPEED_RPM;
    gs_st_ctrl_input_buff.u2_speed_limit_rpm    = MTR_SPEED_LIMIT_RPM;
    gs_st_ctrl_input_buff.u2_offset_calc_time   = MTR_OFFSET_CALC_TIME;
    gs_st_ctrl_input_buff.u2_offset_calc_wait   = MTR_OFFSET_CALC_WAIT;
    gs_st_ctrl_input_buff.u2_pos_dead_band      = MTR_POS_DEAD_BAND;
    gs_st_ctrl_input_buff.u2_pos_band_limit     = MTR_POS_BAND_LIMIT;
    gs_st_ctrl_input_buff.u2_pos_interval_time  = MTR_POS_INTERVAL_TIME;
    gs_st_ctrl_input_buff.u2_run_mode           = MTR_MODE_DRIVE;
    gs_st_ctrl_input_buff.f4_ipd_pos_kp_ratio   = POS_KP_RATIO;
    gs_st_ctrl_input_buff.f4_ipd_speed_k_ratio  = POS_SPEED_RATIO;
    gs_st_ctrl_input_buff.f4_ipd_err_limit_1    = POS_IPD_ERR_LIMIT_1;
    gs_st_ctrl_input_buff.f4_ipd_err_limit_2    = POS_IPD_ERR_LIMIT_2;
    gs_st_ctrl_input_buff.f4_speed_rate_limit   = MTR_RATE_LIMIT_SPEED;
    gs_st_ctrl_input_buff.f4_accel_time         = MTR_ACCEL_TIME;
    gs_st_ctrl_input_buff.f4_ref_id             = MTR_REF_ID;
    gs_st_ctrl_input_buff.f4_ref_iq             = 0.0f;
    gs_st_ctrl_input_buff.f4_current_rate_limit = MTR_RATE_LIMIT_CURRENT;
    gs_st_ctrl_input_buff.f4_bpf_comp_base_cw   = BPF_COMP_GAIN_BASE_CW;
    gs_st_ctrl_input_buff.f4_bpf_comp_base_ccw  = BPF_COMP_GAIN_BASE_CCW;
    gs_st_ctrl_input_buff.f4_bpf_comp_gain_cw   = BPF_COMP_GAIN_MULT_CW;
    gs_st_ctrl_input_buff.f4_bpf_comp_gain_ccw  = BPF_COMP_GAIN_MULT_CCW;

    /* motor parameter */
    gs_st_ctrl_input_buff.st_motor.u2_mtr_pp = MTR_POLE_PAIRS;
    gs_st_ctrl_input_buff.st_motor.f4_mtr_r  = MTR_R;
    gs_st_ctrl_input_buff.st_motor.f4_mtr_ld = MTR_LD;
    gs_st_ctrl_input_buff.st_motor.f4_mtr_lq = MTR_LQ;
    gs_st_ctrl_input_buff.st_motor.f4_mtr_m  = MTR_M;
    gs_st_ctrl_input_buff.st_motor.f4_mtr_j  = MTR_J;
    gs_st_ctrl_input_buff.st_motor.f4_nominal_current_rms = MTR_NOMINAL_CURRENT_RMS;

    /* design parameter */
    gs_st_ctrl_input_buff.st_design_params.f4_current_omega   = MTR_CURRENT_OMEGA;
    gs_st_ctrl_input_buff.st_design_params.f4_current_zeta    = MTR_CURRENT_ZETA;
    gs_st_ctrl_input_buff.st_design_params.f4_speed_omega     = MTR_SPEED_OMEGA;
    gs_st_ctrl_input_buff.st_design_params.f4_speed_zeta      = MTR_SPEED_ZETA;
    gs_st_ctrl_input_buff.st_design_params.f4_speed_lpf_omega = MTR_SPEED_LPF_OMEGA;
    gs_st_ctrl_input_buff.st_design_params.f4_pos_omega       = MTR_POS_OMEGA;
    gs_st_ctrl_input_buff.st_design_params.f4_sob_omega       = SOB_OMEGA;
    gs_st_ctrl_input_buff.st_design_params.f4_sob_zeta        = SOB_ZETA;

    /* pi gain */
    gs_st_ctrl_input_buff.st_ctrl_gain.f4_id_kp    = 0;
    gs_st_ctrl_input_buff.st_ctrl_gain.f4_id_ki    = 0;
    gs_st_ctrl_input_buff.st_ctrl_gain.f4_iq_kp    = 0;
    gs_st_ctrl_input_buff.st_ctrl_gain.f4_iq_ki    = 0;
    gs_st_ctrl_input_buff.st_ctrl_gain.f4_speed_kp = 0;
    gs_st_ctrl_input_buff.st_ctrl_gain.f4_speed_ki = 0;
    gs_st_ctrl_input_buff.st_ctrl_gain.f4_pos_kp   = 0;

    /* resolver parameter */
    gs_st_ctrl_input_buff.f4_esig_freq             = 0;
    gs_st_ctrl_input_buff.f4_esig_cnt              = 0;
    gs_st_ctrl_input_buff.f4_esig_cnt_inv          = 0;
    gs_st_ctrl_input_buff.f4_esig_half_cnt         = 0;
    gs_st_ctrl_input_buff.f4_rslv_angle_diff       = 0;

    /* initialize control gains */
    mtr_CtrlGainCalc(sp_st_mtr);

    /* initialize write enable switch */
    gs_u1_trig_enable_write = MTR_FLG_CLR;

    return( MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_InitVariables
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_GetStatus
 * Description  : Get Current Motor Status
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 *                p_u1_status -
 *                   received data pointer
 * Return Value : MTR_SUCCESS -
 *                   Motor can be started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_GetStatus(uint8_t u1_id,
                                        uint8_t *p_u1_status)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return (MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    *p_u1_status = mtr_statemachine_get_status(&sp_st_mtr->st_stm);

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_GetStatus
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_GetErrStatus
 * Description  : Get Current Motor Status
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 *                p_u2_error_status -
 *                   received data pointer
 * Return Value : MTR_SUCCESS -
 *                   Motor can be started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_GetErrStatus( uint8_t u1_id,
                                            uint16_t *p_u2_error_status)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return (MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    /*  */
    *p_u2_error_status = sp_st_mtr->u2_error_status;

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_GetErrStatus
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_ExecEvent
* Description   : Excecution Event
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 *                u1_event -
 *                   Event
 * Return Value : MTR_SUCCESS -
 *                   Adjustment Process started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_ExecEvent(uint8_t u1_id,
                                        uint8_t u1_event)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    mtr_statemachine_event(&sp_st_mtr->st_stm, sp_st_mtr, u1_event);

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_ExecEvent
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_GetVersion
 * Description  : Returns the version of this module. The version number is encoded such
 *                that the top two bytes are the major version number and the bottom two bytes are
 *                the minor version number.
 * Arguments    : none
 * Return Value : version number
 *********************************************************************************************************************/
uint32_t R_MTR_SR_Foc_GetVersion(void)
{
    uint32_t version = (MTR_SPM_RSLV_FOC_VERSION_MAJOR << 16) | MTR_SPM_RSLV_FOC_VERSION_MINOR;

    return (version);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_GetVersion
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_INT_PosSpdCtrl
 * Description  : 250ms interrupt handler of FOC control
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 * Return Value : MTR_SUCCESS -
 *                   Adjustment Process started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_INT_PosSpdCtrl(uint8_t u1_id)
{
    uint8_t ret;
    float f4_idq_ref[2];
    f4_idq_ref[0] = 0.0f;
    f4_idq_ref[1] = 0.0f;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return (MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    /* */
    /*====================*/
    /*   Set references   */
    /*====================*/
    if (MTR_MODE_INACTIVE == mtr_statemachine_get_status(&sp_st_mtr->st_stm))
    {
        /*=================================*/
        /*   Setting of references state   */
        /*=================================*/
        mtr_set_ref_state(sp_st_mtr);
    }
    else if (MTR_MODE_ACTIVE == mtr_statemachine_get_status(&sp_st_mtr->st_stm))
    {
        /*======================*/
        /*   Decide direction   */
        /*======================*/
        mtr_decide_direction(sp_st_mtr);

        /*================================================*/
        /*   Id, Iq, speed, position references setting   */
        /*================================================*/
        switch (sp_st_mtr->u2_run_mode)
        {
            case MTR_MODE_OFFSET_ADJUST:
            {
                /*=========================================*/
                /*   Check ab-axis current offset adjust   */
                /*=========================================*/
                if (MTR_FLG_SET == sp_st_mtr->u1_flag_offset_calc)
                {
                    sp_st_mtr->u1_offset_adjust_mode = MTR_OFAJ_POS_OFFSET;
                }

                /*================================*/
                /*   Position offset adjustment   */
                /*================================*/
                if (MTR_OFAJ_POS_OFFSET == sp_st_mtr->u1_offset_adjust_mode)
                {
                    f4_idq_ref[0] = mtr_pos_offset_adjust(sp_st_mtr);
                    f4_idq_ref[1] = 0.0f;
                }
            }
            break;

            case MTR_MODE_DRIVE:
            {
                /*=======================================*/
                /*   Setting of position command value   */
                /*=======================================*/
                sp_st_mtr->st_pc.f4_ref_pos_rad_ctrl = mtr_set_pos_ref(sp_st_mtr);

                /*====================================*/
                /*   Setting of speed command value   */
                /*====================================*/
                sp_st_mtr->st_sc.f4_ref_speed_rad_ctrl = mtr_set_speed_ref(sp_st_mtr);

                /*==============================================*/
                /*   Setting of dq-axis current command value   */
                /*==============================================*/
                f4_idq_ref[1] = mtr_set_iq_ref(sp_st_mtr);
                f4_idq_ref[0] = mtr_set_id_ref(sp_st_mtr);

                /*=================================*/
                /*   Executes the Flux-weakening   */
                /*=================================*/
                if ((MTR_ENABLE == sp_st_mtr->u1_flag_flux_weakening_use)
                 && (MTR_LOOP_CURRENT_ID != sp_st_mtr->u1_ctrl_loop_mode)
                 && (MTR_LOOP_CURRENT_IQ != sp_st_mtr->u1_ctrl_loop_mode))
                {
                    mtr_flux_weakng(sp_st_mtr, f4_idq_ref);
                }
            }
            break;

            default:
            {
                /* Do Nothing */
            }
            break;
        }

        /*======================================*/
        /*   Setting of control command value   */
        /*======================================*/
        sp_st_mtr->st_cc.f4_ref_id_ctrl = f4_idq_ref[0];
        sp_st_mtr->st_cc.f4_ref_iq_ctrl = f4_idq_ref[1];
    }
    else
    {
        /* Do Nothing */
    }

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_INT_PosSpdCtrl
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_INT_CrntCtrl
 * Description  : The carrier interrupt handler of FOC control
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 * Return Value : MTR_SUCCESS -
 *                   Adjustment Process started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_INT_CrntCtrl(uint8_t u1_id)
{
    uint8_t ret;
    float f4_angle_rad;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return (MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    /*=======================*/
    /*   Current detection   */
    /*=======================*/
    mtr_get_current_iaib(&sp_st_mtr->f4_ia_ad, &sp_st_mtr->f4_ib_ad, MTR_ID_A);

    /*===================*/
    /*   Vdc detection   */
    /*===================*/
    sp_st_mtr->f4_vdc_ad = mtr_get_vdc(sp_st_mtr->u1_id);
    mtr_mod_SetVdc(&sp_st_mtr->st_mod, sp_st_mtr->f4_vdc_ad);

    /*===============================*/
    /*   Current offset adjustment   */
    /*===============================*/
    mtr_current_offset_adjustment_iaib(sp_st_mtr);

    /*==================*/
    /*    Error check   */
    /*==================*/
    mtr_error_check(sp_st_mtr);

    /* SYSTEM MODE is ACTIVE */
    if (MTR_MODE_ACTIVE == mtr_statemachine_get_status(&sp_st_mtr->st_stm))
    {
        /* Calculate offset current values */
        if (MTR_OFAJ_CURRENT_OFFSET == sp_st_mtr->u1_offset_adjust_mode)
        {
            /*================================*/
            /*   Current offset calibration   */
            /*================================*/
            mtr_calib_current_offset_iaib(sp_st_mtr);
        }
        else
        {
            /*==================================*/
            /*   Position & speed calculation   */
            /*==================================*/
            mtr_rslv_pos_speed_calc(sp_st_mtr);

            /*=============================*/
            /*   Speed & angle detection   */
            /*=============================*/
            mtr_angle_speed(sp_st_mtr);

            /*========================================*/
            /*   Coordinate transformation (ab->dq)   */
            /*========================================*/
            mtr_transform_ab_dq(&sp_st_mtr->st_rotor_angle,
                                &sp_st_mtr->f4_ia_ad,
                                &sp_st_mtr->st_cc.f4_id_ad);

            /*================================*/
            /*   Feedback control (Current)   */
            /*================================*/
            mtr_foc_current_pi_ctrl(&(sp_st_mtr->st_cc));

            /*========================*/
            /*   Decoupling control   */
            /*========================*/
            mtr_foc_current_decoupling( &(sp_st_mtr->st_cc),
                                        sp_st_mtr->st_sc.f4_speed_rad_ctrl,
                                        &(sp_st_mtr->st_motor));

            /*==========================*/
            /*   Limit voltage vector   */
            /*==========================*/
            mtr_foc_voltage_limit(sp_st_mtr);

            /* Phase value considering voltage conversion timing */
            if((MTR_ENABLE == sp_st_mtr->u1_flag_cc_spl_comp_use) && (MTR_MODE_DRIVE == sp_st_mtr->u2_run_mode))
            {
                f4_angle_rad = mtr_current_ctrl_smpldly_comp(   sp_st_mtr->st_rotor_angle.f4_rotor_angle_rad,
                                                                sp_st_mtr->st_sc.f4_speed_rad_ctrl);
                mtr_rotor_angle_update( &sp_st_mtr->st_rotor_angle,
                                        f4_angle_rad);
            }

            /*========================================*/
            /*   Coordinate transformation (dq->ab)   */
            /*========================================*/
            mtr_transform_dq_ab(&sp_st_mtr->st_rotor_angle,
                                &sp_st_mtr->st_cc.f4_ref_vd,
                                &sp_st_mtr->f4_ref_va);

            /*================================*/
            /*   Voltage error compensation   */
            /*================================*/
            if (MTR_ENABLE == sp_st_mtr->u1_flag_volt_err_comp_use)
            {
                float f4_iab_ref[2];
                mtr_transform_dq_ab(&sp_st_mtr->st_rotor_angle,
                                    &sp_st_mtr->st_cc.f4_ref_id_ctrl,
                                    f4_iab_ref);
                mtr_volt_err_comp_main_ab(  &sp_st_mtr->st_volt_comp_p,
                                            &sp_st_mtr->f4_ref_va,
                                            f4_iab_ref,
                                            sp_st_mtr->f4_vdc_ad);
            }

            /*===============================*/
            /*   Limit voltage vector (ab)   */
            /*===============================*/
            mtr_foc_voltage_limit_ab(   &sp_st_mtr->f4_ref_va,
                                        sp_st_mtr->f4_vdc_ad);

            /*=============================*/
            /*   Space vector modulation   */
            /*=============================*/
            mtr_mod2ab_run( sp_st_mtr->f4_ref_va,
                            sp_st_mtr->f4_ref_vb,
                            sp_st_mtr->f4_vdc_ad,
                            &sp_st_mtr->f4_moda,
                            &sp_st_mtr->f4_modb);

            /*===========================*/
            /*   PWM reference setting   */
            /*===========================*/
            mtr_inv_set_ab( sp_st_mtr->f4_moda,
                            sp_st_mtr->f4_modb,
                            MTR_ID_A);
        }
    }

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_INT_CrntCtrl
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_RSLV_Foc_ChargeCapacitor
 * Description  : Wait for charging capacitor
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 * Return Value : MTR_SUCCESS -
 *                   Adjustment Process started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_RSLV_Foc_ChargeCapacitor(uint8_t u1_id)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    /* wait until Vdc exceed MTR_MCU_ON_V */
    while (MTR_MCU_ON_V > sp_st_mtr->f4_vdc_ad)
    {
        sp_st_mtr->f4_vdc_ad = mtr_get_vdc(u1_id);

        /* watch dog timer clear */
        R_MTR_ClearWdt();
    }

    /* flag set "capacitor charge completed" */
    sp_st_mtr->u1_flag_charge_cap = MTR_FLG_SET;

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_RSLV_Foc_ChargeCapacitor
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_IsInPosition
 * Description  :
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 *                p_u1_position -
 *                   Completed positioning flag pointer
 * Return Value : MTR_SUCCESS -
 *                   Motor can be started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_IsInPosition( uint8_t u1_id,
                                            uint8_t *p_u1_position)
{
    uint8_t ret;
    float   f4_temp;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    /*  */
    if ((MTR_MODE_DRIVE == sp_st_mtr->u2_run_mode) && (MTR_LOOP_POSITION == sp_st_mtr->u1_ctrl_loop_mode))
    {
        /* Completed Positioning Flag */
        f4_temp = fabsf(sp_st_mtr->st_pc.f4_pos_err_rad);
        if ((sp_st_mtr->st_pc.u2_pos_band_limit * gs_st_ctrl_input_buff.f4_rslv_angle_diff) >= f4_temp)
        {
            *p_u1_position = MTR_FLG_SET;
        }
        else
        {
            *p_u1_position = MTR_FLG_CLR;
        }
    }
    else
    {
        *p_u1_position = MTR_FLG_CLR;
    }

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_IsInPosition
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_IsOffsetCalFinished
 * Description  :
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 *                p_u1_flag_mode_inactive -
 *
 * Return Value : MTR_SUCCESS -
 *                   Motor can be started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_IsOffsetCalFinished(  uint8_t u1_id,
                                                    uint8_t *p_u1_flag_mode_inactive)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    /*  */
    if (MTR_ENABLE == sp_st_mtr->u1_flag_mode_inactive)
    {
        *p_u1_flag_mode_inactive = TRUE;
    }
    else
    {
        *p_u1_flag_mode_inactive = FALSE;
    }

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_IsOffsetCalFinished
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_CtrlInput
 * Description  :
 * Arguments    : p_st_ctrl_input -
 *
 * Return Value : MTR_SUCCESS -
 *                   Motor can be started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
void R_MTR_SR_Foc_CtrlInput(mtr_ctrl_input_t * p_st_ctrl_input)
{
    /* transfer control input value to buffer structure */
    memcpy(&gs_st_ctrl_input_buff, p_st_ctrl_input, sizeof(mtr_ctrl_input_t));

    /* initialize write enable switch */
    gs_u1_trig_enable_write = MTR_FLG_SET;
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_CtrlInput
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_UpdateVariables
 * Description  :
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 * Return Value : MTR_SUCCESS -
 *                   Motor can be started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_UpdateVariables(uint8_t u1_id)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    /*  */
    if (MTR_FLG_SET == gs_u1_trig_enable_write)
    {
        mtr_SetVariables(sp_st_mtr);
        mtr_CtrlGainCalc(sp_st_mtr);
        gs_u1_trig_enable_write = MTR_FLG_CLR;
    }

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_UpdateVariables
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_INT_OverCur
 * Description  :
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 * Return Value : MTR_SUCCESS -
 *                   Motor can be started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_INT_OverCur(uint8_t u1_id)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    /*  */
    mtr_foc_error(sp_st_mtr, MTR_ERROR_OVER_CURRENT_HW);

    mtr_clear_oc_flag();                              /* Clear forced cutoff flag (detect over current) */

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_INT_OverCur
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_INT_RdcAlarm
 * Description  :
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 * Return Value : MTR_SUCCESS -
 *                   Motor can be started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_INT_RdcAlarm(uint8_t u1_id)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    mtr_foc_error(sp_st_mtr, MTR_ERROR_RDC);

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_INT_RdcAlarm
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_SetAngleInfo
 * Description  :
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 *                u2_angle_cnt -
 *
 *                s2_angle_diff -
 *
 * Return Value : MTR_SUCCESS -
 *                   Motor can be started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_SetAngleInfo( uint8_t u1_id,
                                            uint16_t u2_angle_cnt,
                                            int16_t s2_angle_diff)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    /*  */
    sp_st_mtr->st_rcomp.u2_rslv_pre_timer_cnt_capture = sp_st_mtr->st_rcomp.u2_rslv_timer_cnt_capture;
    sp_st_mtr->st_rcomp.u2_rslv_timer_cnt_capture     = u2_angle_cnt;

    sp_st_mtr->u2_rslv_angle_cnt = u2_angle_cnt;
    sp_st_mtr->s2_angle_err_cnt  = s2_angle_diff;

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_SetAngleInfo
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_GetPosDeg
 * Description  : Write data of flash variables
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 *                *pos_rad -
 *                   position value [degree] (mechanical)
 * Return Value : MTR_SUCCESS -
 *                   Motor can be started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_GetPosDeg(uint8_t u1_id,
                                        float *pos_deg)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    *pos_deg = sp_st_mtr->st_pc.f4_pos_rad * 360.0f / MTR_TWOPI;

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_GetPosDeg
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_GetSpeed
 * Description  : Write data of flash variables
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 *                *speed_rad -
 *                   reference speed value [rad/s]
 *                *speed_rad_ctrl -
 *                   speed_value for speed loop control [rad/s]
 * Return Value : MTR_SUCCESS -
 *                   Motor can be started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_GetSpeed(uint8_t u1_id,
                                       float *speed_rad,
                                       float *speed_rad_ctrl)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    *speed_rad = sp_st_mtr->st_sc.f4_speed_rad;
    *speed_rad_ctrl = sp_st_mtr->st_sc.f4_speed_rad_ctrl;

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_GetSpeed
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_SetFlash2Ctrl
 * Description  : Read data for flash variables
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 *                *pst_val -
 *
 * Return Value : MTR_SUCCESS -
 *                   Motor can be started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_SetFlash2Ctrl(uint8_t u1_id,
                                            mtr_flash_val *pst_val)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    sp_st_mtr->f4_rslv_angle_offset_rad = pst_val->f4_rslv_angle_offset_rad;
    sp_st_mtr->u2_rslv_angle_offset_cnt = (uint16_t)(sp_st_mtr->f4_rslv_angle_offset_rad * gs_st_ctrl_input_buff.f4_esig_cnt * MTR_TWOPI_INV);
    sp_st_mtr->f4_offset_ia = pst_val->f4_offset_ia;
    sp_st_mtr->f4_offset_ib = pst_val->f4_offset_ib;

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_SetFlash2Ctrl
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: R_MTR_SR_Foc_GetCtrl2Flash
 * Description  : Write data of flash variables
 * Arguments    : u1_id -
 *                   The motor ID which specify the motor connectors
 *                *pst_val -
 *
 * Return Value : MTR_SUCCESS -
 *                   Motor can be started successfully
 *                MTR_ERR_BAD_ID -
 *                   Inputted ID was over the range or not exist
 *                MTR_ERR_NO_OPEN -
 *                   Motor instance not created
 *********************************************************************************************************************/
r_mtr_rslv_ret_t R_MTR_SR_Foc_GetCtrl2Flash(uint8_t u1_id,
                                            mtr_flash_val *pst_val)
{
    uint8_t ret;

    ret = r_mtr_chk_input_id(u1_id);

    /* Cannot find out the target */
    if (FALSE == ret)
    {
        return(MTR_ERR_BAD_ID);
    }

    /*  */
    if (NULL == sp_st_mtr)
    {
        return(MTR_ERR_NO_OPEN);
    }

    pst_val->f4_rslv_angle_offset_rad = sp_st_mtr->f4_rslv_angle_offset_rad;
    pst_val->f4_offset_ia = sp_st_mtr->f4_offset_ia;
    pst_val->f4_offset_ib = sp_st_mtr->f4_offset_ib;

    return (MTR_SUCCESS);
}
/**********************************************************************************************************************
 * End of function R_MTR_SR_Foc_GetCtrl2Flash
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * Function Name: r_mtr_chk_input_id
 * Description  : Check inputted ID is valid or not
 * Arguments    : u1_id -
 *                   user inputted Motor ID
 * Return Value : TRUE -
 *                   The motor ID is valid
 *                FALSE -
 *                   The motor ID is invalid
 *********************************************************************************************************************/
static uint8_t r_mtr_chk_input_id(uint8_t u1_id)
{
    uint8_t u1_ret;

    switch (u1_id)
    {
        case MTR_ID_A:
            u1_ret = TRUE;
        break;

        default:
            u1_ret = FALSE;
        break;
    }
    return (u1_ret);
}
/**********************************************************************************************************************
 * End of function r_mtr_chk_input_id
 *********************************************************************************************************************/
