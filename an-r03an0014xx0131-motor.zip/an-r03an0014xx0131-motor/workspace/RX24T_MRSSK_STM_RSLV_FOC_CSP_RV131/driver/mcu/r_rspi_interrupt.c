/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_rspi_interrupt.c
* Description : Interrupt Handlers
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
s*******************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <machine.h>
#include "iodefine.h"
#include "r_rslv_api.h"

/***********************************************************************************************************************
* Private functions definitions
***********************************************************************************************************************/
#define FAST_INTERRUPT_VECTOR 0
/***********************************************************************************************************************
* Function Name : r_rspi0_transmit_interrupt
* Description   : Hundler function at RSPI transmit interrupt
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
#if FAST_INTERRUPT_VECTOR == VECT_RSPI0_SPTI0
#pragma interrupt r_rspi0_transmit_interrupt(vect=VECT(RSPI0,SPTI0),fint)
#else
#pragma interrupt r_rspi0_transmit_interrupt(vect=VECT(RSPI0,SPTI0))
#endif
static void r_rspi0_transmit_interrupt( void )
{
setpsw_i();                                       /* Interrupt enable */
    R_RSLV_INT_RdcCom_Trans();
}/* End of function mtr_over_current_interrupt */

/***********************************************************************************************************************
* Function Name: r_rspi0_receive_interrupt
* Description  : Hundler function at RSPI receive interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
#if FAST_INTERRUPT_VECTOR == VECT_RSPI0_SPRI0
#pragma interrupt r_rspi0_receive_interrupt(vect=VECT(RSPI0,SPRI0),fint)
#else
#pragma interrupt r_rspi0_receive_interrupt(vect=VECT(RSPI0,SPRI0))
#endif
static void r_rspi0_receive_interrupt( void )
{
setpsw_i();                                       /* Interrupt enable */
    R_RSLV_INT_RdcCom_Recv();
} /* end of function r_rspi0_receive_interrupt */

/***********************************************************************************************************************
* Function Name: r_rspi0_error_interrupt
* Description  : Hundler function at RSPI error interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
#if FAST_INTERRUPT_VECTOR == VECT_RSPI0_SPEI0
#pragma interrupt r_rspi0_error_interrupt(vect=VECT(RSPI0,SPEI0),fint)
#else
#pragma interrupt r_rspi0_error_interrupt(vect=VECT(RSPI0,SPEI0))
#endif
static void r_rspi0_error_interrupt( void )
{
setpsw_i();                                       /* Interrupt enable */
    R_RSLV_INT_RdcCom_Recv();
} /* end of function r_rspi0_error_interrupt */

/***********************************************************************************************************************
* Function Name: r_rspi0_idle_interrupt
* Description  : Hundler function at RSPI idle interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
#if FAST_INTERRUPT_VECTOR == VECT_RSPI0_SPII0
#pragma interrupt r_rspi0_idle_interrupt(vect=VECT(RSPI0,SPII0),fint)
#else
#pragma interrupt r_rspi0_idle_interrupt(vect=VECT(RSPI0,SPII0))
#endif
static void r_rspi0_idle_interrupt( void )
{
setpsw_i();                                       /* Interrupt enable */
    R_RSLV_INT_RdcCom_Idle();
} /* end of function r_rspi0_idle_interrupt */
