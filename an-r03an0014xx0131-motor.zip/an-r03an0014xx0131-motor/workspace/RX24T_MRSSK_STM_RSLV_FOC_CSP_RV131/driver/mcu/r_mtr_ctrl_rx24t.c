/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_ctrl_rx24t.c
* Description : The processes of MCU & inverter control layer for RX24T
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include <machine.h>
#include "iodefine.h"
#include "r_mtr_common.h"
#include "r_mtr_parameter.h"
#include "r_mtr_ctrl_rx24t.h"
#include "r_mtr_ctrl_mcu.h"


/***********************************************************************************************************************
* Private functions definitions
***********************************************************************************************************************/
static void    mtr_init_clock(void);           /* Initializes clock */
static void    mtr_init_wdt(void);             /* Initializes WDT */
static void    mtr_init_cmt0(void);            /* Initializes CMT0*/
static void    mtr_init_poe3(void);            /* Initializes POE3 */
static void    mtr_init_mtu_2(void);           /* Initializes MTU3_2 */
static void    mtr_init_mtu_3_4_6_7(void);     /* Initializes MTU3_3 MTU3_4 MTU_6 MTU3_7 */
static void    mtr_init_port(void);            /* Initializes PORT */
static void    mtr_init_ad_converter(void);    /* Initializes A/D converter */
static void    mtr_init_irq(void);             /* Initializes external(Hall) interrupt */
static void    mtr_init_register(uint8_t u1_id);
                                               /* Removes unintentional first pulse */
static void    mtr_init_flash_memory(void);    /* Initialize Flash Memory */

#define MTU_TCSYSTR_SCH7    (1 << 0)
#define MTU_TCSYSTR_SCH6    (1 << 1)
#define MTU_TCSYSTR_SCH9    (1 << 2)
#define MTU_TCSYSTR_SCH4    (1 << 3)
#define MTU_TCSYSTR_SCH3    (1 << 4)
#define MTU_TCSYSTR_SCH2    (1 << 5)
#define MTU_TCSYSTR_SCH1    (1 << 6)
#define MTU_TCSYSTR_SCH0    (1 << 7)

/***********************************************************************************************************************
* Function Name : R_MTR_InitHardware
* Description   : Initializes peripheral function
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_InitHardware(void)
{

    /*=========================*/
    /*     Initialize port     */
    /*=========================*/
    mtr_init_port();

    /*=========================*/
    /*     Initialize clock    */
    /*=========================*/
    mtr_init_clock();

    /*========================*/
    /*     Initialize WDT     */
    /*========================*/
    mtr_init_wdt();

    /*========================*/
    /*     Initialize CMT0    */
    /*========================*/
    mtr_init_cmt0();

    /*=========================*/
    /*     Initialize POE3     */
    /*=========================*/
    mtr_init_poe3();

    /*=========================*/
    /*     Initialize MTU3_2   */
    /*=========================*/
    mtr_init_mtu_2();

    /*===================================*/
    /*     Initialize MTU3_3,MTU3_4      */
    /*===================================*/
    mtr_init_mtu_3_4_6_7();

    /*==================================*/
    /*     Initialize A/D converter     */
    /*==================================*/
    mtr_init_ad_converter();

    /*======================================*/
    /*     initialize External Interrupt    */
    /*======================================*/
    mtr_init_irq();

    /*==================================*/
    /*     initialize Flash Memory      */
    /*==================================*/
    mtr_init_flash_memory();
} /* End of function R_MTR_InitHardware */

/***********************************************************************************************************************
* Function Name : R_MTR_ClearWdt
* Description   : Clears watch dog timer
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_ClearWdt(void)
{
    IWDT.IWDTRR = 0x00;                                 /* IWDT Refresh Operation */
    IWDT.IWDTRR = 0xFF;
} /* End of function R_MTR_ClearWdt */

/***********************************************************************************************************************
* Function Name : mtr_init_clock
* Description   : Initializes clock
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_clock(void)
{
    int32_t i;

    /* ---- Enable write protection ---- */
    /* PRCR - Protect Register
    b15:b8 PRKEY    - PRC Key Code - A5h
                      (The write value should be A5h to permission writing PRCi bit)
    b4:b7  Reserved - The write value should be 0.
    b3     PRC3     - Protect Bit 0 - Write disabled
    b2     Reserved - The write value should be 0.
    b1     PRC1     - Protect Bit 1 - Write enabled
    b0     PRC0     - Protect Bit 1 - Write enabled */
    SYSTEM.PRCR.WORD = 0xA503;

    /* ---- Set the main clock ---- */
    /* ----  Set the main clock oscillator drive capability ---- */
    /* MOFCR - Main Clock Oscillator Forced Oscillation Control Register
    b7       Reserved - The write value should be 0.
    b6       MOSEL    - Main Clock Oscillator Switch - Resonator
    b5       MODRV21  - Main Clock Oscillator Drive Capability Switch
                      - 10 MHz to 20 MHz
    b4:b0    Reserved - The write value should be 0. */
    SYSTEM.MOFCR.BYTE = 0x20;

    /* ---- Set wait time until the main clock oscillator stabilizes ---- */
    /* MOSCWTCR - Main Clock Oscillator Wait Control Register
    b7:b5    Reserved - The write value should be 0.
    b4:b0    MSTS     - Main Clock Oscillator Waiting Time
                      - Wait time is 32768 cycles (8.192 ms). */
    SYSTEM.MOSCWTCR.BYTE = 0x06;

    /* ---- Operate the main clock oscillator ---- */
    /* MOSCCR   - Main Clock Oscillator Control Register
    b7:b1    Reserved - The write value should be 0.
    b0       MOSTP    - Main Clock Oscillator Stop - Main clock oscillator is operating. */
    SYSTEM.MOSCCR.BYTE = 0x00;

    /* ---- Wait processing for the clock oscillation stabilization ---- */
    while (1 != SYSTEM.OSCOVFSR.BIT.MOOVF)
    {
        /* Waits until MOOVF bit is set to 1. Main clock can be used after MOOVF bit is set to 1. */
    }

    /* ---- Set the PLL clock ---- */
    /* ---- Set the PLL division ratio and multiplication factor ---- */
    /* PLLCR - PLL Control Register
    b15:b14  Reserved - The write value should be 0.
    b13:b8   STC      - Frequency Multiplication Factor Select
                      - Frequency multiplication factor is multiply-by-8.
    b7:b2    Reserved - The write value should be 0.
    b1:b0    PLIDIV   - PLL Input Frequency Division Ratio Select
                      - PLL input division ratio is not divide. */
    SYSTEM.PLLCR.WORD = 0x0700;

    /* ---- Operate the PLL clock oscillator ---- */
    /* PLLCR2 - PLL Control Register 2
    b7:b1    Reserved - The write value should be 0.
    b0       PLLEN    - PLL Stop Control - PLL is operating. */
    SYSTEM.PLLCR2.BYTE = 0x00;

    /* ---- Wait processing for the clock oscillation stabilization ---- */
    while (1 != SYSTEM.OSCOVFSR.BIT.PLOVF)
    {
        /* Waits until PLOVF bit is set to 1. Main clock can be used after PLOVF bit is set to 1. */
    }

    /* ---- Set the wait cycle of the ROM ---- */
    /* MEMWAIT - Memory Wait Cycle Setting Register
    b7:b2   Reserved - The write value should be 0.
    b1:b0   MEMWAIT  - Memory Wait Cycle Setting - Wait states */
    SYSTEM.MEMWAIT.BYTE = 0x02;
    while (0x02 != SYSTEM.MEMWAIT.BYTE)
    {
        /* Confirm that the written value can be read correctly. */
    }

    /* ---- Set the internal clock division ratio ---- */
    /* SCKCR - System Clock Control Register
    b31:b28 FCK      - FlashIF Clock(FCLK) Select - divide-by-4
    b27:b24 ICK      - System Clock (ICLK) Select - not divide
    b23:b20 Reserved - The write value should be 0.
    b19:b16 Reserved - Among the setting values of ICK[3:0] bit and PCKB[3:0] bit,
                       please set the same value as the large value of division number.
    b12:b15 PCLKA    - Peripheral Module Clock A(PCLKA) Select - not divide
    b11:b8  PCLKB    - Peripheral Module Clock B(PCLKB) Select - divide-by-2
    b7:b4   Reserved - The write value should be 0.
    b3:b0   PCLKD    - Peripheral Module Clock D(PCLKD) Select - divide-by-2 */
    /*        (iclk should be equal to or less than 32MHz) */
    SYSTEM.SCKCR.LONG = 0x20010101;
    while (0x20010101 != SYSTEM.SCKCR.LONG)
    {
         /* Confirm that the written value can be read correctly. */
    }

    /* ---- Set the internal clock source ---- */
    /* SCKCR3 - System Clock Control Register 3
    b10:b8  CKSEL    - Clock Source Select - PLL circuit is selected. */
    SYSTEM.SCKCR3.WORD = 0x0400;
    while (0x0400 != SYSTEM.SCKCR3.WORD)
    {
        /* Confirm that the written value can be read correctly. */
    }

    /* ---- Wait for the stabilization time ---- */
    for (i = 0; i < 60; i++)
    {
        /* Do Nothing */
    }

    while (0 != SYSTEM.OPCCR.BIT.OPCMTSF)
    {
        /* Check that operation power control mode transition is completed. */
    }

    /* ---- Set the operating power control mode ---- */
    /* OPCCR - Operating Power Control Register
    b7:b5   Reserved - The write value should be 0.
    b4      OPCMTSF  - Operating Power Control Mode Transition Status Flag
    b3      Reserved - The write value should be 0.
    b2:b0   OPCM     - Operating Power Control Mode Select - High-speed operating mode */
    SYSTEM.OPCCR.BYTE = 0x00;
    while (0 != SYSTEM.OPCCR.BIT.OPCMTSF)
    {
        /* Confirm that the operation power control mode transition completed. */
    }

    /* ---- Disable write protection ---- */
    /* PRCR - Protect Register
    b15:b8 PRKEY    - PRC Key Code - A5h
                      (The write value should be A5h to permission writing PRCi bit)
    b4:b7  Reserved - The write value should be 0.
    b3     PRC3     - Protect Bit 0 - Write disabled
    b2     Reserved - The write value should be 0.
    b1     PRC1     - Protect Bit 0 - Write disabled
    b0     PRC0     - Protect Bit 0 - Write disabled */
    SYSTEM.PRCR.WORD = 0xA500;
} /* End of function mtr_init_clock */

/***********************************************************************************************************************
* Function Name : mtr_init_wdt
* Description   : Initializes IWDT
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_wdt(void)
{
    SYSTEM.PRCR.WORD = 0xA503;                          /* PRCR write enabled */
    SYSTEM.ILOCOCR.BIT.ILCSTP = 0;                      /* IWDT-dedicated on-chip oscillator is operating */
    SYSTEM.PRCR.WORD = 0xA500;                          /* PRCR write disabled */
    IWDT.IWDTRR = 0x00;                                 /* IWDT Refresh Operation */
    IWDT.IWDTRR = 0xFF;
} /* End of function mtr_init_wdt */

/***********************************************************************************************************************
* Function Name : mtr_init_cmt0
* Description   : Initializes CMT0
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_cmt0(void)
{
    SYSTEM.PRCR.WORD = 0xA502;                          /* Enable write protection */
    MSTP_CMT0 = 0;                                      /* The module stop state is canceled */
    SYSTEM.PRCR.WORD = 0xA500;                          /* Disable write protection */

    CMT.CMSTR0.BIT.STR0 = 0;                            /* CMT0 count is stopped */
    CMT0.CMCNT = 0;                                     /* Counter clear */
    CMT0.CMCR.BIT.CKS = 0;                              /* Clock : PCLK/8 = 5[MHz] */
    CMT0.CMCOR = 1249;                                  /* Set interval period : 250 [us] */
                                                        /* 1249 = (5[MHz] * 250[us]) - 1 */

    IPR(CMT0,CMI0)  = 9;                                /* Interrupt priority level : 9 */
    IR(CMT0,CMI0)   = 0;                                /* Clear interrupt request */
    IEN(CMT0,CMI0)  = 0;                                /* Interrupt request disable */

    CMT0.CMCR.BIT.CMIE = 1;                             /* Compare match interrupt (CMI0) enabled */

} /* End of function mtr_init_cmt0 */

/***********************************************************************************************************************
* Function Name : R_MTR_Start_cmt0
* Description   : This function starts the CMT0 channel counter.
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Start_cmt0( void )
{
    IEN(CMT0,CMI0) = 1;                                  /* Interrupt enable */
    CMT.CMSTR0.BIT.STR0 = 1;                             /* Timer Start */
}/* End of function R_MTR_Start_cmt0 */

/***********************************************************************************************************************
* Function Name : R_MTR_Stop_cmt0
* Description   : This function stops the CMT0 channel counter.
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Stop_cmt0( void )
{
    IEN(CMT0,CMI0) = 0;                                  /* Interrupt disable */
    CMT.CMSTR0.BIT.STR0 = 0;                             /* Timer Stop */
}/* End of function R_MTR_Stop_cmt0 */


/***********************************************************************************************************************
* Function Name : mtr_init_poe3
* Description   : Initializes POE3 (Over-current protection)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_poe3(void)
{
    /* Solution board use P70 (POE#0) as HW over-current detection pin */
    PORT7.PMR.BIT.B0 = 0;                            /* Use pin as general I/O port */

    MPC.PWPR.BIT.B0WI = 0;                           /* Writing to the PFSWE bit is enabled */
    MPC.PWPR.BIT.PFSWE = 1;                          /* Writing to the PFS register is enabled */

    MPC.P70PFS.BIT.PSEL = 7;                         /* Set peripheral for POE0# */

    MPC.PWPR.BIT.PFSWE = 0;                          /* Writing to the PFS register is disabled */
    MPC.PWPR.BIT.B0WI = 1;                           /* Writing to the PFSWE bit is disabled */

    PORT7.PMR.BIT.B0 = 1;                            /* Use pin as I/O port for peripheral functions */

    POE.ICSR1.BIT.POE0M = 0;                         /* Accepts a request on the falling edge of POE0# input */
    POE.ICSR1.BIT.PIE1 = 1;                          /* OEI1 interrupt requests by the input level detection enabled */

    /* Set active level MTU3,4 pins, 3B & 4A is low-active other high-active */
    POE.ALR1.WORD = 0x00BF;// & ~((1 << 0) | (1 << 2) | (1 << 4));

    /* Set active level MTU6,7 pins, 6B & 7A is low-active other high-active */
    POE.ALR2.WORD = 0x00BF;// & ~((1 << 0) | (1 << 2) | (1 << 4));

    POE.OCSR1.BIT.OCE1 = 1;                          /* Interrupt (OEI1) enabled */
    POE.OCSR1.BIT.OIE1 = 1;                          /* Places the pins in high-impedance */

    POE.POECR4.BIT.IC1ADDMT67ZE = 1;                 /* Add setting to make MTU 3 high impedance by POE0F */

    POE.POECR2.WORD = 0x0707;                        /* Enable high impedance of MTU complementary PWM output terminal */

    IPR(POE,OEI1) = 15;                              /* Interrupt priority level */
    IR(POE,OEI1) = 0;                                /* Clear interrupt request */
    IEN(POE,OEI1) = 1;                               /* Interrupt request enable */
} /* End of function mtr_init_poe3 */

/***********************************************************************************************************************
* Function Name : mtr_init_mtu_2
* Description   : Initialize MTU3 Encoder counter
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_mtu_2(void)
{
    /***** module stop state *****/
    SYSTEM.PRCR.WORD = 0xA502;                          /* enable write protection */
    MSTP_MTU = 0;                                       /* the module stop state is canceled */
    SYSTEM.PRCR.WORD = 0xA500;                          /* disable write protection */

    MTU.TSTRA.BIT.CST2 = 0;                             /* stop MTU3_2 */

    /***** encoder timer setting *****/
    PORT3.PMR.BIT.B0 = 0;                               /* use pin as general I/O port */
    PORT3.PMR.BIT.B1 = 0;                               /* use pin as general I/O port */

    PORT3.PDR.BIT.B0 = 0;                               /* input mode */
    PORT3.PDR.BIT.B1 = 0;                               /* input mode */

    MPC.PWPR.BIT.B0WI = 0;                              /* writing to the PFSWE bit is enabled */
    MPC.PWPR.BIT.PFSWE = 1;                             /* writing to the PFS register is enabled */

    MPC.P30PFS.BIT.PSEL = 2;                            /* set peripheral for MTCLKD */
    MPC.P31PFS.BIT.PSEL = 2;                            /* set peripheral for MTCLKC */

    MPC.PWPR.BIT.PFSWE = 0;                             /* writing to the PFS register is disabled */
    MPC.PWPR.BIT.B0WI = 1;                              /* writing to the PFSWE bit is disabled */

    PORT3.PMR.BIT.B0 = 1;                               /* use pin as I/O port for peripheral functions */
    PORT3.PMR.BIT.B1 = 1;                               /* use pin as I/O port for peripheral functions */

    MTU1.TMDR3.BIT.PHCKSEL = 1;                         /* Select MTCLKC and MTCLKD */
    MTU2.TMDR1.BIT.MD  = 4;                             /* MD[3:0]=0b0100:phase counting mode 1 */
    MTU2.TCR.BIT.CCLR  = 0;                             /* TCNT clear prohibition */
    MTU2.TGRA          = 0;                             /* clear counter */

    MTU2.TCNT = 0;
} /* End of function mtr_init_mtu_2 */

/***********************************************************************************************************************
* Function Name : R_MTR_Start_mtu_c2
* Description   : MTU3 Encoder counter timer start
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Start_mtu_c2( void )
{
    /***** Start count operation *****/
    MTU.TSTRA.BIT.CST2 = 1;                             /* start MTU3_2 */
}/* End of function R_MTR_Start_mtu_c2 */

/***********************************************************************************************************************
* Function Name : R_MTR_Stop_mtu_c2
* Description   : MTU3 Encoder counter timer stop
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Stop_mtu_c2( void )
{
    /***** Stop count operation *****/
    MTU.TSTRA.BIT.CST2 = 0;                             /* stop MTU3_2 */
}/* End of function R_MTR_Stop_mtu_c2 */

/***********************************************************************************************************************
* Function Name : mtr_init_mtu_3_4_6_7
* Description   : Initializes MTU3 timer for PWM output
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_mtu_3_4_6_7(void)
{
    /***** Module stop state *****/
    SYSTEM.PRCR.WORD = 0xA502;                       /* Enable write protection */
    MSTP_MTU = 0;                                    /* The module stop state is canceled */
    SYSTEM.PRCR.WORD = 0xA500;                       /* Disable write protection */

    /***** Stop count operation *****/
    MTU.TSTRA.BIT.CST3 = 0;                          /* Stop MTU3_3 */
    MTU.TSTRA.BIT.CST4 = 0;                          /* Stop MTU3_4 */

    MTU.TSTRB.BIT.CST6 = 0;                          /* stop MTU3_6 */
    MTU.TSTRB.BIT.CST7 = 0;                          /* stop MTU3_6 */

    /***** Count clock selection *****/
    MTU3.TCR.BIT.TPSC   = 0;                         /* MTU3_3 clock : PCLKA */
    MTU3.TCR.BIT.CKEG   = 0;                         /* MTU3_3 count at rising edge */
    MTU3.TCR2.BIT.TPSC2 = 0;                         /* MTU3_3 clock : PCLKA */
    MTU4.TCR.BIT.TPSC   = 0;                         /* MTU3_4 clock : PCLKA */
    MTU4.TCR.BIT.CKEG   = 0;                         /* MTU3_4 count at rising edge */
    MTU4.TCR2.BIT.TPSC2 = 0;                         /* MTU3_4 clock : PCLKA */

    MTU6.TCR.BIT.TPSC   = 0;                         /* MTU3_6 clock : PCLKA */
    MTU6.TCR.BIT.CKEG   = 0;                         /* MTU3_6 count at rising edge */
    MTU6.TCR2.BIT.TPSC2 = 0;                         /* MTU3_6 clock : PCLKA */
    MTU7.TCR.BIT.TPSC   = 0;                         /* MTU3_7 clock : PCLKA */
    MTU7.TCR.BIT.CKEG   = 0;                         /* MTU3_7 count at rising edge */
    MTU7.TCR2.BIT.TPSC2 = 0;                         /* MTU3_7 clock : PCLKA */

    /***** TCNT setting *****/
    MTU3.TCNT = MTR_DEADTIME_SET;                    /* Set dead-time */
    MTU4.TCNT = 0;                                   /* Set "0" */

    MTU6.TCNT = MTR_DEADTIME_SET;                    /* Set dead-time */
    MTU7.TCNT = 0;                                   /* Set "0" */


    /***** TGR setting *****/
    MTU3.TGRB = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f + (MTR_DEADTIME_SET * 0.5f));
    MTU4.TGRA = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f + (MTR_DEADTIME_SET * 0.5f));
    MTU4.TGRB = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f + (MTR_DEADTIME_SET * 0.5f));
                                                     /* Set initial duty */
    MTU3.TGRD = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f + (MTR_DEADTIME_SET * 0.5f));
    MTU4.TGRC = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f + (MTR_DEADTIME_SET * 0.5f));
    MTU4.TGRD = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f + (MTR_DEADTIME_SET * 0.5f));
                                                     /* Set initial duty */
    MTU6.TGRB = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f + (MTR_DEADTIME_SET * 0.5f));
    MTU7.TGRA = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f + (MTR_DEADTIME_SET * 0.5f));
    MTU7.TGRB = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f + (MTR_DEADTIME_SET * 0.5f));
                                                     /* Set initial duty */
    MTU6.TGRD = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f + (MTR_DEADTIME_SET * 0.5f));
    MTU7.TGRC = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f + (MTR_DEADTIME_SET * 0.5f));
    MTU7.TGRD = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f + (MTR_DEADTIME_SET * 0.5f));
                                                     /* Set initial duty */

    /***** Dead-time and carrier period setting *****/
    MTU.TDDRA = MTR_DEADTIME_SET;                    /* Set dead-time */

    MTU.TDDRB = MTR_DEADTIME_SET;                    /* set dead-time */

    MTU.TCDRA = (uint16_t)(MTR_CARRIER_SET_BASE);
    MTU.TCBRA = (uint16_t)(MTR_CARRIER_SET_BASE);
                                                     /* Set carrier period */


    MTU.TCDRB = (uint16_t)(MTR_CARRIER_SET_BASE);
#if (PWM_DECAY_MODE == 1)
    /* To synchronize left upper arm MOSFET and right lower arm MOSFET,
       first carrier period should be set 0.5x */
    MTU.TCBRB = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f);
#else
    MTU.TCBRB = (uint16_t)(MTR_CARRIER_SET_BASE);
#endif

    MTU3.TGRA = MTR_CARRIER_SET;                     /* Set "carrier period + dead-time" */
    MTU3.TGRC = MTR_CARRIER_SET;


    MTU6.TGRA = MTR_CARRIER_SET;
#if (PWM_DECAY_MODE == 1)
    MTU6.TGRC = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f) + MTR_DEADTIME_SET;
#else
    MTU6.TGRC = MTR_CARRIER_SET;
#endif

    /***** Enable PWM output, set PWM output level *****/
    MTU.TOCR1A.BIT.PSYE = 0;                         /* Toggle output is disabled */
    MTU.TOCR1B.BIT.PSYE = 0;                         /* toggle output is disabled */

    MTU.TOCR1A.BIT.OLSP = 1;   /* Positive phase : initial output"H",active level"L" */
    MTU.TOCR1B.BIT.OLSP = 1;

    MTU.TOCR1A.BIT.OLSN = 1;                         /* Negative phase : initial output"L",active level"H" */
    MTU.TOCR1B.BIT.OLSN = 1;

    /***** Complementary PWM mode setting *****/
    MTU3.TMDR1.BIT.MD = 14;                          /* MD[3:0]=0b1110 : complementary PWM mode */
                                                     /* (transfer at trough) */
    MTU3.TMDR1.BIT.BFA = 1;                          /* TGRA and TGRC used together for buffer operation */
    MTU3.TMDR1.BIT.BFB = 1;                          /* TGRB and TGRD used together for buffer operation */

    MTU6.TMDR1.BIT.MD = 14;                          /* MD[3:0]=0b1110 : complementary PWM mode */
                                                     /* (transfer at trough) */
    MTU6.TMDR1.BIT.BFA = 1;                          /* TGRA and TGRC used together for buffer operation */
    MTU6.TMDR1.BIT.BFB = 1;                          /* TGRB and TGRD used together for buffer operation */

    /***** Waveform output setting *****/
    MTU.TOERA.BYTE = 0xC0;                           /* PWM output disable  */
    MTU3.TIORH.BYTE = 0x00;                          /* MTIOC3B output prohibited */
    MTU3.TIORL.BYTE = 0x00;                          /* MTIOC3D output prohibited */
    MTU4.TIORH.BYTE = 0x00;                          /* MTIOC4B output prohibited */
    MTU4.TIORL.BYTE = 0x00;                          /* MTIOC4D output prohibited */

    MTU.TOERB.BYTE = 0xC0;                           /* PWM output disable  */
    MTU6.TIORH.BYTE = 0x00;                          /* MTIOC6B output prohibited */
    MTU6.TIORL.BYTE = 0x00;                          /* MTIOC6D output prohibited */
    MTU7.TIORH.BYTE = 0x00;                          /* MTIOC7B output prohibited */
    MTU7.TIORL.BYTE = 0x00;                          /* MTIOC7D output prohibited */

    /***** MPC setting *****/
    PORT7.PMR.BIT.B1 = 0;                            /* Use pin as general I/O port */
    PORT7.PMR.BIT.B2 = 0;                            /* Use pin as general I/O port */
    PORT7.PMR.BIT.B3 = 0;                            /* Use pin as general I/O port */
    PORT7.PMR.BIT.B4 = 0;                            /* Use pin as general I/O port */
    PORT7.PMR.BIT.B5 = 0;                            /* Use pin as general I/O port */
    PORT7.PMR.BIT.B6 = 0;                            /* Use pin as general I/O port */

    PORT9.PMR.BIT.B0 = 0;                            /* use pin as general I/O port */
    PORT9.PMR.BIT.B1 = 0;                            /* use pin as general I/O port */
    PORT9.PMR.BIT.B2 = 0;                            /* use pin as general I/O port */
    PORT9.PMR.BIT.B3 = 0;                            /* use pin as general I/O port */
    PORT9.PMR.BIT.B4 = 0;                            /* use pin as general I/O port */
    PORT9.PMR.BIT.B5 = 0;                            /* use pin as general I/O port */

    PORT7.PODR.BIT.B1 = 0;                           /* Up = "H" */
    PORT7.PODR.BIT.B2 = 0;                           /* Vp = "H" */
    PORT7.PODR.BIT.B3 = 0;                           /* Wp = "H" */
    PORT7.PODR.BIT.B4 = 0;                           /* Un = "L" */
    PORT7.PODR.BIT.B5 = 0;                           /* Vn = "L" */
    PORT7.PODR.BIT.B6 = 0;                           /* Wn = "L" */
    PORT7.PDR.BIT.B1 = 1;                            /* Output mode for Up */
    PORT7.PDR.BIT.B2 = 1;                            /* Output mode for Vp */
    PORT7.PDR.BIT.B3 = 1;                            /* Output mode for Wp */
    PORT7.PDR.BIT.B4 = 1;                            /* Output mode for Un */
    PORT7.PDR.BIT.B5 = 1;                            /* Output mode for Vn */
    PORT7.PDR.BIT.B6 = 1;                            /* Output mode for Wn */

    PORT9.PODR.BIT.B0 = 0;                           /* Wn = "L" */
    PORT9.PODR.BIT.B1 = 0;                           /* Vn = "L" */
    PORT9.PODR.BIT.B2 = 0;                           /* Un = "L" */
    PORT9.PODR.BIT.B3 = 0;                           /* Wp = "H" */
    PORT9.PODR.BIT.B4 = 0;                           /* Vp = "H" */
    PORT9.PODR.BIT.B5 = 0;                           /* Up = "H" */
    PORT9.PDR.BIT.B0 = 1;                            /* output mode for Up */
    PORT9.PDR.BIT.B1 = 1;                            /* output mode for Vp */
    PORT9.PDR.BIT.B2 = 1;                            /* output mode for Wp */
    PORT9.PDR.BIT.B3 = 1;                            /* output mode for Un */
    PORT9.PDR.BIT.B4 = 1;                            /* output mode for Vn */
    PORT9.PDR.BIT.B5 = 1;                            /* output mode for Wn */

    MPC.PWPR.BIT.B0WI = 0;                           /* Writing to the PFSWE bit is enabled */
    MPC.PWPR.BIT.PFSWE = 1;                          /* Writing to the PFS register is enabled */

    MPC.P71PFS.BIT.PSEL = 1;                         /* Set peripheral for MTIOC3B */
    MPC.P72PFS.BIT.PSEL = 1;                         /* Set peripheral for MTIOC4A */
    MPC.P73PFS.BIT.PSEL = 1;                         /* Set peripheral for MTIOC4B */
    MPC.P74PFS.BIT.PSEL = 1;                         /* Set peripheral for MTIOC3D */
    MPC.P75PFS.BIT.PSEL = 1;                         /* Set peripheral for MTIOC4C */
    MPC.P76PFS.BIT.PSEL = 1;                         /* Set peripheral for MTIOC4D */

    MPC.P90PFS.BIT.PSEL = 1;                         /* set peripheral for MTIOC7D */
    MPC.P91PFS.BIT.PSEL = 1;                         /* set peripheral for MTIOC7C */
    MPC.P92PFS.BIT.PSEL = 1;                         /* set peripheral for MTIOC6D */
    MPC.P93PFS.BIT.PSEL = 1;                         /* set peripheral for MTIOC7B */
    MPC.P94PFS.BIT.PSEL = 1;                         /* set peripheral for MTIOC7A */
    MPC.P95PFS.BIT.PSEL = 1;                         /* set peripheral for MTIOC6B */

    MPC.PWPR.BIT.PFSWE = 0;                          /* Writing to the PFS register is disabled */
    MPC.PWPR.BIT.B0WI = 1;                           /* Writing to the PFSWE bit is disabled */

    /***** Interrupt setting *****/
    MTU4.TIER.BIT.TCIEV = 1;                         /* Enable underflow interrupt when operation is */
                                                     /* in complementary PWM mode */
    MTU4.TIER.BIT.TTGE2 = 1;                         /* Enable TCNT underflow A/D convert */
    MTU4.TIER.BIT.TTGE = 0;                          /* Disable A/D convert request */

    MTU7.TIER.BIT.TCIEV = 0;                         /* Disable interrupt */
    MTU7.TIER.BIT.TTGE2 = 0;                         /* Disable TCNT underflow A/D convert */
    MTU7.TIER.BIT.TTGE = 0;                          /* Disable A/D convert request */

    IPR(MTU4, TCIV4) = 12;                           /* interrupt priority level 12 */
    IR(MTU4, TCIV4)  = 0;                            /* clear interrupt request */
    IEN(MTU4,TCIV4)  = 1;                            /* enable TCIV4 interrupt in MTU4 */
} /* End of function mtr_init_mtu_3_4 */

/***********************************************************************************************************************
* Function Name : R_MTR_Stop_mtu_c3_4
* Description   : MTU3_4 timer stop
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Stop_mtu_c3_4(void)
{
    /***** Stop count operation *****/
    MTU.TSTRA.BIT.CST3 = 0;                          /* Stop MTU3_3 */
    MTU.TSTRA.BIT.CST4 = 0;                          /* Stop MTU3_4 */
}/* End of function R_MTR_Stop_mtu_c3_4 */

/***********************************************************************************************************************
* Function Name : R_MTR_Sync_StartCH3467
* Description   : MTU3_4_6_9 timer start
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Sync_StartCH3467(void)
{
    /***** Start count operation *****/
    /* Sync start of timer MTU3,4  MTU6 , MTU9 */
    MTU.TCSYSTR.BYTE = (MTU_TCSYSTR_SCH3 | MTU_TCSYSTR_SCH4 | MTU_TCSYSTR_SCH6 | MTU_TCSYSTR_SCH7);
}/* End of function R_MTR_Sync_StartCH3467 */

/***********************************************************************************************************************
* Function Name: r_mtu4_setting_normal
* Description  : setting MTU4 interrupt for normal
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void r_mtu4_setting_normal( void )
{
    IEN(MTU4,TCIV4) = 0;          /* Disable TCIV4 interrupt in MTU4 */
    MTU4.TADCR.WORD = 0x84;       /* ITA4VE,UT4AE Enable */
}

/***********************************************************************************************************************
* Function Name : mtr_init_port
* Description   : Initializes PORT function
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_port(void)
{
    /***** port data *****/
    PORT0.PODR.BIT.B0 = 0;                              /* P00 data : Low */
    PORT0.PODR.BIT.B1 = 0;                              /* P01 data : Low */
    PORT0.PODR.BIT.B2 = 0;                              /* P02 data : Low */

    PORT1.PODR.BIT.B1 = 0;                              /* P11 data : Low */

    PORT2.PODR.BIT.B1 = 0;                              /* P21 data : Low */
    PORT2.PODR.BIT.B2 = 0;                              /* P22 data : Low */
    PORT2.PODR.BIT.B3 = 0;                              /* P23 data : Low */
    PORT2.PODR.BIT.B4 = 0;                              /* P24 data : Low */

    PORT3.PODR.BIT.B0 = 0;                              /* P30 data : Low */
    PORT3.PODR.BIT.B1 = 0;                              /* P31 data : Low */
    PORT3.PODR.BIT.B6 = 0;                              /* P36 data : Low */
    PORT3.PODR.BIT.B7 = 0;                              /* P37 data : Low */

    // PORT7.PODR.BIT.B0 = 0;                              /* P70 data : Low */
    // PORT7.PODR.BIT.B1 = 0;                              /* P71 data : Low */
    // PORT7.PODR.BIT.B2 = 0;                              /* P72 data : Low */
    // PORT7.PODR.BIT.B3 = 0;                              /* P73 data : Low */
    // PORT7.PODR.BIT.B4 = 0;                              /* P74 data : Low */
    // PORT7.PODR.BIT.B5 = 0;                              /* P75 data : Low */
    // PORT7.PODR.BIT.B6 = 0;                              /* P76 data : Low */

    // PORT9.PODR.BIT.B0 = 0;                              /* P90 data : Low */
    // PORT9.PODR.BIT.B1 = 0;                              /* P91 data : Low */
    // PORT9.PODR.BIT.B2 = 0;                              /* P92 data : Low */
    // PORT9.PODR.BIT.B3 = 0;                              /* P93 data : Low */
    // PORT9.PODR.BIT.B4 = 0;                              /* P94 data : Low */
    // PORT9.PODR.BIT.B5 = 0;                              /* P95 data : Low */
    PORT9.PODR.BIT.B6 = 0;                              /* P96 data : Low */

    PORTB.PODR.BIT.B1 = 0;                              /* PB1 data : Low */
    PORTB.PODR.BIT.B2 = 0;                              /* PB2 data : Low */
    PORTB.PODR.BIT.B3 = 0;                              /* PB3 data : Low */
    PORTB.PODR.BIT.B4 = 0;                              /* PB4 data : Low */
    PORTB.PODR.BIT.B5 = 0;                              /* PB5 data : Low */
    PORTB.PODR.BIT.B6 = 0;                              /* PB6 data : Low */

    PORTD.PODR.BIT.B3 = 0;                              /* PD3 data : Low */
    PORTD.PODR.BIT.B4 = 0;                              /* PD4 data : Low */
    PORTD.PODR.BIT.B5 = 0;                              /* PD5 data : Low */
    PORTD.PODR.BIT.B6 = 0;                              /* PD6 data : Low */
    PORTD.PODR.BIT.B7 = 0;                              /* PD7 data : Low */

    PORTE.PODR.BIT.B2 = 0;                              /* PE2 data : Low */

    /***** port direction *****/
    PORT0.PDR.BIT.B0 = 1;                               /* P00 direction : OUT */
    PORT0.PDR.BIT.B1 = 1;                               /* P01 direction : OUT */
    PORT0.PDR.BIT.B2 = 1;                               /* P02 direction : OUT */

    PORT1.PDR.BIT.B1 = 1;                               /* P11 direction : OUT */

    PORT2.PDR.BIT.B1 = 1;                               /* P21 direction : OUT */
    PORT2.PDR.BIT.B2 = 1;                               /* P22 direction : OUT */
    PORT2.PDR.BIT.B3 = 1;                               /* P23 direction : OUT */
    PORT2.PDR.BIT.B4 = 1;                               /* P24 direction : OUT */

    PORT3.PDR.BIT.B1 = 1;                               /* P31 direction : OUT */
    PORT3.PDR.BIT.B2 = 1;                               /* P32 direction : OUT */
    PORT3.PDR.BIT.B6 = 1;                               /* P36 direction : OUT */
    PORT3.PDR.BIT.B7 = 1;                               /* P37 direction : OUT */

    // PORT7.PDR.BIT.B0 = 0;                               /* P70 direction : IN */
    // PORT7.PDR.BIT.B1 = 0;                               /* P71 direction : IN */
    // PORT7.PDR.BIT.B2 = 0;                               /* P72 direction : IN */
    // PORT7.PDR.BIT.B3 = 0;                               /* P73 direction : IN */
    // PORT7.PDR.BIT.B4 = 0;                               /* P74 direction : IN */
    // PORT7.PDR.BIT.B5 = 0;                               /* P75 direction : IN */
    // PORT7.PDR.BIT.B6 = 0;                               /* P76 direction : IN */

    // PORT9.PDR.BIT.B0 = 1;                               /* P90 direction : OUT */
    // PORT9.PDR.BIT.B1 = 1;                               /* P91 direction : OUT */
    // PORT9.PDR.BIT.B2 = 1;                               /* P92 direction : OUT */
    // PORT9.PDR.BIT.B3 = 1;                               /* P93 direction : OUT */
    // PORT9.PDR.BIT.B4 = 1;                               /* P94 direction : OUT */
    // PORT9.PDR.BIT.B5 = 0;                               /* P95 direction : IN */
    PORT9.PDR.BIT.B6 = 1;                               /* P96 direction : OUT */

    PORTB.PDR.BIT.B1 = 1;                               /* PB1 direction : OUT */
    PORTB.PDR.BIT.B2 = 1;                               /* PB2 direction : OUT */
    PORTB.PDR.BIT.B3 = 1;                               /* PB3 direction : OUT */
    PORTB.PDR.BIT.B4 = 0;                               /* PB4 direction : IN (POE#8) */
    PORTB.PDR.BIT.B5 = 1;                               /* PB5 direction : OUT */
    PORTB.PDR.BIT.B6 = 0;                               /* PB6 direction : IN */

    PORTD.PDR.BIT.B3 = 1;                               /* PD3 direction : OUT */
    PORTD.PDR.BIT.B4 = 1;                               /* PD4 direction : OUT */
    PORTD.PDR.BIT.B5 = 0;                               /* PD5 direction : IN */
    PORTD.PDR.BIT.B6 = 1;                               /* PD6 direction : OUT */
    PORTD.PDR.BIT.B7 = 1;                               /* PD7 direction : OUT */

    PORTE.PDR.BIT.B2 = 1;                               /* PE2 direction : OUT */
}
/***********************************************************************************************************************
* Function Name: R_PORT_Set_RdcReset
* Description  : Initializes the Port I/O for RDC control.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_PORT_Set_RdcReset( void )
{
    PORT0.PODR.BIT.B1 = 0;
} /* end of function R_PORT_Set_RdcReset */

/***********************************************************************************************************************
* Function Name: R_PORT_Cancel_RdcReset
* Description  : Cancel RDC reset (Set RDC reset port to "High".)
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_PORT_Cancel_RdcReset( void )
{
    PORT0.PODR.BIT.B1 = 1;
} /* end of function R_PORT_RdcResetCancel */

/***********************************************************************************************************************
* Function Name : mtr_init_ad_converter
* Description   : Initializes A/D converter
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_ad_converter(void)
{
    SYSTEM.PRCR.WORD = 0xA502;                          /* Enable write protection */
    MSTP_S12AD  = 0;                                    /* The module stop state is canceled */
    MSTP_S12AD1 = 0;                                    /* The module stop state is canceled */
    MSTP_S12AD2 = 0;                                    /* The module stop state is canceled */
    SYSTEM.PRCR.WORD = 0xA500;                          /* Disable write protection */

    S12AD.ADCSR.BIT.EXTRG = 0;                          /* Use single-cycle scan mode with sample-and-hold function */
    S12AD.ADCSR.BIT.TRGE = 1;                           /* Enables A/D conversion trigger */
    S12AD.ADCSR.BIT.ADIE = 0;                           /* Disables S12ADI interrupt generation upon scan completion */
    S12AD.ADCSR.BIT.ADCS = 0;                           /* Single scan mode */

    S12AD1.ADCSR.BIT.EXTRG = 0;                         /* Use single-cycle scan mode with sample-and-hold function */
    S12AD1.ADCSR.BIT.TRGE = 1;                          /* Enables A/D conversion trigger */
    S12AD1.ADCSR.BIT.ADIE = 1;                          /* Disables S12ADI1 interrupt generation upon scan completion */
    S12AD1.ADCSR.BIT.ADCS = 0;                          /* Single scan mode */

    S12AD2.ADCSR.BIT.EXTRG = 0;                         /* Use single-cycle scan mode with sample-and-hold function */
    S12AD2.ADCSR.BIT.TRGE = 1;                          /* Enables A/D conversion trigger */
    S12AD2.ADCSR.BIT.ADIE = 0;                          /* Disables S12ADI2 interrupt generation upon scan completion */
    S12AD2.ADCSR.BIT.ADCS = 0;                          /* Single scan mode */

    PORT4.PDR.BIT.B0 = 0;                               /* P40 direction : IN, Ia AN000 (IA-) */
    PORT4.PDR.BIT.B4 = 0;                               /* P44 direction : IN, Ia AN100 (IA+) */
    PORT4.PDR.BIT.B5 = 0;                               /* P45 direction : IN, Ib AN101 (IB+) */
    PORT4.PDR.BIT.B6 = 0;                               /* P46 direction : IN, Ib AN102 (IB-) */
    PORT4.PDR.BIT.B7 = 0;                               /* P46 direction : IN, MNT, AC, AN103 */
    PORT5.PDR.BIT.B1 = 0;                               /* P51 direction : IN, Va+ AN207 */
    PORT5.PDR.BIT.B2 = 0;                               /* P52 direction : IN, Vb+ AN208*/
    PORT5.PDR.BIT.B3 = 0;                               /* P52 direction : IN, Vb- AN209 */
    PORT5.PDR.BIT.B4 = 0;                               /* P52 direction : IN, Va- AN210 */
    PORT5.PDR.BIT.B5 = 0;                               /* P55 direction : IN, Vdc AN211 (VDC) */

    MPC.PWPR.BIT.B0WI = 0;                              /* Writing to the PFSWE bit is enabled */
    MPC.PWPR.BIT.PFSWE = 1;                             /* Writing to the PFS register is enabled */

    MPC.P40PFS.BIT.ASEL = 1;                            /* P40 Pin function selection : IN, Ia AN000 (IA-) */
    MPC.P44PFS.BIT.ASEL = 1;                            /* P44 Pin function selection : IN, Ia AN100 (IA+) */
    MPC.P45PFS.BIT.ASEL = 1;                            /* P45 Pin function selection : IN, Ib AN101 (IB+) */
    MPC.P46PFS.BIT.ASEL = 1;                            /* P46 Pin function selection : IN, Ib AN102 (IB-) */
    MPC.P47PFS.BIT.ASEL = 1;                            /* P46 Pin function selection : IN, MNT, AC, AN103 */
    MPC.P51PFS.BIT.ASEL = 1;                            /* P51 Pin function selection : IN, Va+ AN207 */
    MPC.P52PFS.BIT.ASEL = 1;                            /* P52 Pin function selection : IN, Vb+ AN208*/
    MPC.P53PFS.BIT.ASEL = 1;                            /* P52 Pin function selection : IN, Vb- AN209 */
    MPC.P54PFS.BIT.ASEL = 1;                            /* P52 Pin function selection : IN, Va- AN210 */
    MPC.P55PFS.BIT.ASEL = 1;                            /* P55 Pin function selection : IN, Vdc AN211 (VDC) */

    MPC.PWPR.BIT.PFSWE = 0;                             /* Writing to the PFS register is disabled */
    MPC.PWPR.BIT.B0WI = 1;                              /* Writing to the PFSWE bit is disabled */

    /* Configure AD conversion for current sensing group */
    S12AD.ADANSA0.WORD  = (1 << 0);                     /* Enable A/D convert channel AN000 */
    S12AD1.ADANSA0.WORD = (1 << 0) | (1 << 1) | (1 << 2);
                                                        /* Enable A/D convert channel AN100,AN101,AN102 */

    /* Configure AD conversion for voltage sensing group */
    S12AD2.ADANSA0.WORD = (1 << 0) | (1 << 7) | (1 << 8) | (1 << 9) | (1 << 10) | (1 << 11);
                                                        /* Enable A/D convert channel AN200,AN207,AN208,AN209,AN210,AN211 */

    /* Configure AD sampling hold for current sensing */
    S12AD1.ADSHCR.BIT.SHANS = (1 << 0) | (1 << 1) | (1 << 2);
                                                       /* Enable sampling & hold AN100 ~ AN102 */

    S12AD.ADCER.BIT.ADRFMT  = 0;                        /* A/D data format "aligning to the right" */
    S12AD1.ADCER.BIT.ADRFMT = 0;                        /* A/D data format "aligning to the right" */
    S12AD2.ADCER.BIT.ADRFMT = 0;                        /* A/D data format "aligning to the right" */

    S12AD.ADSTRGR.BIT.TRSA  = 5;                        /* A/D convert trigger MTU4.TCNT underflow */
    S12AD1.ADSTRGR.BIT.TRSA = 5;                        /* A/D convert trigger MTU4.TCNT underflow */
    S12AD2.ADSTRGR.BIT.TRSA = 5;                        /* A/D convert trigger MTU4.TCNT underflow */

    IPR(S12AD1, S12ADI1) = 10;                          /* Set S12ADI interrupt priority level : level 10 */
    IR(S12AD1, S12ADI1) = 0;                            /* Clear interrupt request */

} /* End of function mtr_init_ad_converter */

/***********************************************************************************************************************
* Function Name : R_MTR_Start_s12ad
* Description   : A/D Interrupt enable
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Start_s12ad(void)
{
    IR(S12AD1, S12ADI1) = 0;                            /* Interrupt flag clear */
    IEN(S12AD1, S12ADI1) = 1;                           /* Interrupt enable */
    S12AD1.ADCSR.BIT.TRGE = 1;                          /* A/D converter start enable */
}/* End of function R_MTR_Start_s12ad */

/***********************************************************************************************************************
* Function Name : R_MTR_Stop_s12ad
* Description   : A/D Interrupt disable
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Stop_s12ad(void)
{
    S12AD1.ADCSR.BIT.TRGE = 0;                          /* A/D converter start disable */
    S12AD1.ADCSR.BIT.ADST = 0;                          /* */
    IEN(S12AD1, S12ADI1) = 0;                           /* Interrupt disable */
    IR(S12AD1, S12ADI1) = 0;                            /* Interrupt flag clear */
}/* End of function R_MTR_Stop_s12ad */

/***********************************************************************************************************************
* Function Name : mtr_init_register
* Description   : Avoid unintentional first pulse
* Arguments     : u1_id - Motor ID
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_register(uint8_t u1_id)
{
    uint16_t u2_temp;

    u2_temp = (uint16_t)(MTR_CARRIER_SET_BASE * 0.5f + (MTR_DEADTIME_SET * 0.5f));

    switch (u1_id)
    {
        case MTR_ID_A:
            MTU3.TGRD = u2_temp;
            MTU4.TGRC = u2_temp;
            MTU4.TGRD = u2_temp;

            MTU6.TGRD = u2_temp;
            MTU7.TGRC = u2_temp;
            MTU7.TGRD = u2_temp;                        /* Set duty */
        break;

        default:
            /* Do Nothing */
        break;
    }
} /* End of function mtr_init_register */

/***********************************************************************************************************************
* Function Name : mtr_init_irq
* Description   : Initialize of External(Hall) Interrupt
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_irq(void)
{
    /*************** PORT Setting ******************/
    MPC.PWPR.BIT.B0WI = 0;                              /* Writing to the PFSWE bit is enabled */
    MPC.PWPR.BIT.PFSWE = 1;                             /* Writing to the PFS register is enabled */

    MPC.P70PFS.BIT.ISEL = 1;                            /* PORT70 is used as IRQ5. */

    PORT7.PMR.BIT.B0 = 1;                               /* Peripheral Function */
    PORT7.PDR.BIT.B0 = 0;                               /* IRQ5:input mode for RDC_ALARM */

    MPC.PWPR.BIT.PFSWE = 0;                             /* Writing to the PFS register is disabled */
    MPC.PWPR.BIT.B0WI = 1;                              /* Writing to the PFSWE bit is disabled */

    /*************** IRQ5 (RDC_ALARM) *********/
    IEN(ICU,IRQ5) = 0;                                  /* IRQ5 interrupt disable */
    IPR(ICU,IRQ5) = 15;                                 /* IRQ5 interrupt priority level is set to "15". */
    ICU.IRQCR[5].BIT.IRQMD = 1;                         /* IRQ5 use down edge */
    IR(ICU,IRQ5) = 0;                                   /* IRQ5 interrupt requirement enable clear */

} /* End of function mtr_init_irq */

/***********************************************************************************************************************
* Function Name : R_ICU_Start_irq5
* Description   : IRQ5 Interrupt enable
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_ICU_Start_irq5(void)
{
    IEN(ICU,IRQ5) = 1;                                  /* IRQ5 interrupt enable */
}/* End of function R_ICU_Start_irq5 */

/***********************************************************************************************************************
* Function Name : R_ICU_Stop_irq5
* Description   : IRQ5 Interrupt disable
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_ICU_Stop_irq5(void)
{
    IEN(ICU,IRQ5) = 0;                                  /* IRQ5 interrupt disable */
}/* End of function R_ICU_Stop_irq5 */

/***********************************************************************************************************************
* Function Name : R_ICU_Clear_irq5_request
* Description   : IRQ5 Interrupt request clear
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_ICU_Clear_irq5_request(void)
{
    IR(ICU,IRQ5) = 0;                                   /* IRQ5 interrupt requirement enable clear */
}/* End of function R_ICU_Clear_irq5_request */

/***********************************************************************************************************************
* Function Name : mtr_init_flash_memory
* Description   : Enables ROM Cache
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
static void mtr_init_flash_memory(void)
{
    /******************************/
    /*  ROM Cache Enable Process  */
    /******************************/
    FLASH.ROMCIV.BIT.ROMCIV = 1;                        /* Start ROM Cache invalidation. */
    while (1 == FLASH.ROMCIV.BIT.ROMCIV)
    {
        /* Wait for the ROMCIV.ROMCIV bit to become 0. (1: Invalidation is in progress.) */
    }
    FLASH.ROMCE.BIT.ROMCEN = 1;                         /* ROM cache operation enabled. */
    while (0 == FLASH.ROMCE.BIT.ROMCEN)
    {
        /* Confirm that the ROMCE.ROMCEN bit is 1. */
    }
} /* End of function mtr_init_flash_memory */

/***********************************************************************************************************************
* Function Name : mtr_ctrl_start
* Description   : Starts PWM output
* Arguments     : u1_id - Motor ID
* Return Value  : None
***********************************************************************************************************************/
void mtr_ctrl_start(uint8_t u1_id)
{
    mtr_init_register(u1_id);
    switch (u1_id)
    {
        case MTR_ID_A:

#if (IP_PWM_INDEPENDENT == 1)
            MTR_PORT_A_PH = 0;                            /* Up = "L" */
            MTR_PORT_A_PL = 0;                            /* Un = "L" */
            MTR_PORT_B_PH = 0;                            /* Vp = "L" */
            MTR_PORT_B_PL = 0;                            /* Vn = "L" */
            MTR_PORT_C_PH = 0;                            /* Wp = "L" */
            MTR_PORT_C_PL = 0;                            /* Wn = "L" */
            PORT7.PMR.BIT.B1 = 1;                       /* I/O port for peripheral functions */
            PORT7.PMR.BIT.B2 = 1;                       /* I/O port for peripheral functions */
            PORT7.PMR.BIT.B3 = 1;                       /* I/O port for peripheral functions */
            PORT7.PMR.BIT.B4 = 1;                       /* I/O port for peripheral functions */
            PORT7.PMR.BIT.B5 = 1;                       /* I/O port for peripheral functions */
            PORT7.PMR.BIT.B6 = 1;                       /* I/O port for peripheral functions */
            MTU.TOERA.BYTE = 0xFF;                      /* PWM output enable */

            MTR_PORT_A_MH = 0;                          /* A-H = "L" */
            MTR_PORT_A_ML = 0;                          /* A-L = "L" */
            MTR_PORT_B_MH = 0;                          /* B-H = "L" */
            MTR_PORT_B_ML = 0;                          /* B-L = "L" */
            MTR_PORT_C_MH = 0;                          /* C-H = "L" */
            MTR_PORT_C_ML = 0;                          /* C-L = "L" */
            PORT9.PMR.BIT.B5 = 1;                       /* I/O port for peripheral functions */
            PORT9.PMR.BIT.B2 = 1;                       /* I/O port for peripheral functions */
            PORT9.PMR.BIT.B4 = 1;                       /* I/O port for peripheral functions */
            PORT9.PMR.BIT.B1 = 1;                       /* I/O port for peripheral functions */
            PORT9.PMR.BIT.B3 = 1;                       /* I/O port for peripheral functions */
            PORT9.PMR.BIT.B0 = 1;                       /* I/O port for peripheral functions */
            MTU.TOERB.BYTE = 0xFF;                      /* PWM output enable */
#else
            MTR_PORT_AP = 0;                            /* Up = "L" */
            MTR_PORT_AN = 0;                            /* Un = "L" */
            MTR_PORT_BP = 0;                            /* Vp = "L" */
            MTR_PORT_BN = 0;                            /* Vn = "L" */
            MTR_PORT_CP = 0;                            /* Wp = "L" */
            MTR_PORT_CN = 0;                            /* Wn = "L" */
            PORT7.PMR.BIT.B1 = 1;                       /* I/O port for peripheral functions */
            PORT7.PMR.BIT.B2 = 1;                       /* I/O port for peripheral functions */
            PORT7.PMR.BIT.B3 = 1;                       /* I/O port for peripheral functions */
            PORT7.PMR.BIT.B4 = 1;                       /* I/O port for peripheral functions */
            PORT7.PMR.BIT.B5 = 1;                       /* I/O port for peripheral functions */
            PORT7.PMR.BIT.B6 = 1;                       /* I/O port for peripheral functions */
            MTU.TOERA.BYTE = 0xFF;                      /* PWM output enable */

#endif
        break;

        default:
            /* Do Nothing */
        break;
    }
} /* End of function mtr_ctrl_start */

/***********************************************************************************************************************
* Function Name : mtr_ctrl_stop
* Description   : Stops PWM output disable for motor control
* Arguments     : u1_id - Motor ID
* Return Value  : None
***********************************************************************************************************************/
void mtr_ctrl_stop(uint8_t u1_id)
{
    switch (u1_id)
    {
        case MTR_ID_A:
#if (IP_PWM_INDEPENDENT == 1)
            MTU.TOERA.BYTE = 0xC0;                      /* PWM output disable */
            PORT7.PMR.BIT.B1 = 0;                       /* General I/O port */
            PORT7.PMR.BIT.B2 = 0;                       /* General I/O port */
            PORT7.PMR.BIT.B3 = 0;                       /* General I/O port */
            PORT7.PMR.BIT.B4 = 0;                       /* General I/O port */
            PORT7.PMR.BIT.B5 = 0;                       /* General I/O port */
            PORT7.PMR.BIT.B6 = 0;                       /* General I/O port */

            MTR_PORT_A_PH = 0;                            /* Up = "L" */
            MTR_PORT_A_PL = 0;                            /* Un = "L" */
            MTR_PORT_B_PH = 0;                            /* Vp = "L" */
            MTR_PORT_B_PL = 0;                            /* Vn = "L" */
            MTR_PORT_C_PH = 0;                            /* Wp = "L" */
            MTR_PORT_C_PL = 0;                            /* Wn = "L" */

            MTU.TOERB.BYTE = 0xC0;                      /* PWM output disable */
            PORT9.PMR.BIT.B5 = 0;                       /* I/O port for peripheral functions */
            PORT9.PMR.BIT.B2 = 0;                       /* I/O port for peripheral functions */
            PORT9.PMR.BIT.B4 = 0;                       /* I/O port for peripheral functions */
            PORT9.PMR.BIT.B1 = 0;                       /* I/O port for peripheral functions */
            PORT9.PMR.BIT.B3 = 0;                       /* I/O port for peripheral functions */
            PORT9.PMR.BIT.B0 = 0;                       /* I/O port for peripheral functions */
            MTR_PORT_A_MH = 0;                          /* A-H = "L" */
            MTR_PORT_A_ML = 0;                          /* A-L = "L" */
            MTR_PORT_B_MH = 0;                          /* B-H = "L" */
            MTR_PORT_B_ML = 0;                          /* B-L = "L" */
            MTR_PORT_C_MH = 0;                          /* C-H = "L" */
            MTR_PORT_C_ML = 0;                          /* C-L = "L" */
#endif
        break;

        default:
            /* Do Nothing */
        break;
    }
    mtr_init_register(u1_id);
} /* End of function mtr_ctrl_stop */

/***********************************************************************************************************************
* Function Name : mtr_inv_set_ab
* Description   : PWM duty setting
* Arguments     : f4_duty_a - The duty cycle of Phase-a (0.0 - 1.0)
*                 f4_duty_b - The duty cycle of Phase-b (0.0 - 1.0)
*               : u1_id - Motor ID
* Return Value  : none
***********************************************************************************************************************/
void mtr_inv_set_ab(float f4_duty_a, float f4_duty_b, uint8_t u1_id)
{
#if (IP_PWM_INDEPENDENT == 1)
    uint16_t u2_temp_a_p;
    uint16_t u2_temp_a_n;
    uint16_t u2_temp_b_p;
    uint16_t u2_temp_b_n;
    uint16_t u2_temp;
#if (PWM_DECAY_MODE == 0)
    /* Asynchronous decay, requires 8 channel independent PWM */
    u2_temp_a_p = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (1.0f - f4_duty_a)) + ((float)MTR_DEADTIME_SET * 0.5f));
    u2_temp_a_n = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (f4_duty_a)) + ((float)MTR_DEADTIME_SET * 0.5f));
    u2_temp_b_p = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (1.0f - f4_duty_b)) + ((float)MTR_DEADTIME_SET * 0.5f));
    u2_temp_b_n = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (f4_duty_b)) + ((float)MTR_DEADTIME_SET * 0.5f));

#elif (PWM_DECAY_MODE == 1)
    /* Synchronous fast decay, software workaround in 8 channel independent PWM composition */
    u2_temp_a_p = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (1.0f - f4_duty_a)) + ((float)MTR_DEADTIME_SET * 0.5f));
    u2_temp_a_n = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (f4_duty_a)) + ((float)MTR_DEADTIME_SET * 0.5f));
    u2_temp_b_p = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (1.0f - f4_duty_b)) + ((float)MTR_DEADTIME_SET * 0.5f));
    u2_temp_b_n = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (f4_duty_b)) + ((float)MTR_DEADTIME_SET * 0.5f));

#elif (PWM_DECAY_MODE == 2)
    /* Note: uses the current measured from low duty cycle side to extend the range of voltage output
     * Using only one-side is also OK if the current sensing window is ensured, which will lower the voltage output range */
    if(f4_duty_a >= 0.5f)
    {
        u2_temp_a_p = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (2.0f - 2.0f * f4_duty_a)) + ((float)MTR_DEADTIME_SET * 0.5f));
        u2_temp_a_n = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (1.0f)) + ((float)MTR_DEADTIME_SET * 0.5f));
    }
    else
    {
        u2_temp_a_p = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (1.0f)) + ((float)MTR_DEADTIME_SET * 0.5f));
        u2_temp_a_n = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (2.0f * f4_duty_a)) + ((float)MTR_DEADTIME_SET * 0.5f));
    }
    if(f4_duty_b >= 0.5f)
    {
        u2_temp_b_p = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (2.0f - 2.0f * f4_duty_b)) + ((float)MTR_DEADTIME_SET * 0.5f));
        u2_temp_b_n = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (1.0f)) + ((float)MTR_DEADTIME_SET * 0.5f));
    }
    else
    {
        u2_temp_b_p = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (1.0f)) + ((float)MTR_DEADTIME_SET * 0.5f));
        u2_temp_b_n = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (2.0f * f4_duty_b)) + ((float)MTR_DEADTIME_SET * 0.5f));
    }
#else
    #error "Invalid decay mode:PWM_DECAY_MODE"
#endif
    u2_temp   = (uint16_t)(((float)MTR_CARRIER_SET_BASE * 0.5f) + ((float)MTR_DEADTIME_SET * 0.5f));

    switch (u1_id)
    {
        case MTR_ID_A:
            MTU3.TGRD = (uint16_t)u2_temp_a_p;
                                                        /* set a-phase + duty */
            MTU4.TGRC = (uint16_t)u2_temp_b_p;
                                                        /* set b-phase + duty */
            MTU4.TGRD = (uint16_t)u2_temp;              /* write enable */

            MTU6.TGRD = (uint16_t)u2_temp_a_n;
                                                        /* set a-phase - duty */
            MTU7.TGRC = (uint16_t)u2_temp_b_n;
                                                        /* set b-phase - duty */
            MTU7.TGRD = (uint16_t)u2_temp;              /* write enable */
        break;

        default:
            /* Do nothing */
        break;
    }
#else /* IP_PWM_INDEPENDENT */
    uint16_t u2_temp_a;
    uint16_t u2_temp_b;
    uint16_t u2_temp;

    u2_temp_a = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (1.0f - f4_duty_a)) + ((float)MTR_DEADTIME_SET * 0.5f));
    u2_temp_b = (uint16_t)(((float)MTR_CARRIER_SET_BASE * (1.0f - f4_duty_b)) + ((float)MTR_DEADTIME_SET * 0.5f));
    u2_temp   = (uint16_t)(((float)MTR_CARRIER_SET_BASE * 0.5f) + ((float)MTR_DEADTIME_SET * 0.5f));

    switch (u1_id)
    {
        case MTR_ID_A:
            MTU3.TGRD = (uint16_t)u2_temp_a;
                                                        /* set a-phase duty */
            MTU4.TGRC = (uint16_t)u2_temp_b;
                                                        /* set b-phase duty */
            MTU4.TGRD = (uint16_t)u2_temp;              /* write enable */
        break;

        default:
            /* Do nothing */
        break;
    }
#endif /* IP_PWM_INDEPENDENT */
} /* End of function mtr_inv_set_ab */

/***********************************************************************************************************************
* Function Name : mtr_get_current_iaib_adc
* Description   : A/D conversion for Ia,Ib
* Arguments     : *f4_ia_ad, *f4_ib_ad - Current variables for Ia, Ib
*               : u1_id - Motor ID
* Return Value  : none
***********************************************************************************************************************/
void mtr_get_current_iaib_adc(float *f4_ia_ad, float *f4_ib_ad, uint8_t u1_id)
{
    switch (u1_id)
    {
        case MTR_ID_A:
            while (1 == S12AD1.ADCSR.BIT.ADST)
            {
                /* wait until AD conversion finish */
            }
            *f4_ia_ad = (float)S12AD1.ADDR0;
            *f4_ib_ad = (float)S12AD1.ADDR1;
        break;

        default:
            /* Do nothing */
        break;
    }
} /* End of function mtr_get_iaib_adc */

/***********************************************************************************************************************
* Function Name : mtr_get_voltage_vavb_adc
* Description   : A/D conversion for Va,Vb
* Arguments     : *f4_va_ad, *f4_vb_ad - Voltage variables for Va, Vb
*               : u1_id - Motor ID
* Return Value  : none
***********************************************************************************************************************/
void mtr_get_voltage_vavb_adc(float *f4_va_ad, float *f4_vb_ad, uint8_t u1_id)
{
    switch (u1_id)
    {
        case MTR_ID_A:
            while (1 == S12AD2.ADCSR.BIT.ADST)
            {
                /* wait until AD conversion finish */
            }
            *f4_va_ad = (float)S12AD2.ADDR7;
            *f4_vb_ad = (float)S12AD2.ADDR8;
        break;

        default:
            /* Do nothing */
        break;
    }
} /* End of function mtr_get_voltage_vavb_adc */

/***********************************************************************************************************************
* Function Name : mtr_get_rdc_mnt_adc
* Description   : A/D conversion for RDC Monitor
* Arguments     : u1_id - Motor ID
* Return Value  : A/D converted value
***********************************************************************************************************************/
float mtr_get_rdc_mnt_adc(uint8_t u1_id)
{
    float f4_temp;

    switch (u1_id)
    {
        case MTR_ID_A:
            while (1 == S12AD.ADCSR.BIT.ADST)
            {
                /* Wait until AD conversion finish */
            }
            f4_temp = (float)S12AD.ADDR2;
        break;

        default:
            /* Do Nothing */
        break;
    }

    return (f4_temp);
} /* End of function mtr_get_rdc_mnt_adc */

/***********************************************************************************************************************
* Function Name : mtr_get_vdc_adc
* Description   : A/D conversion for Vdc
* Arguments     : u1_id - Motor ID
* Return Value  : A/D converted value
***********************************************************************************************************************/
float mtr_get_vdc_adc(uint8_t u1_id)
{
    float f4_temp;

    switch (u1_id)
    {
        case MTR_ID_A:
            while (1 == S12AD2.ADCSR.BIT.ADST)
            {
                /* Wait until AD conversion finish */
            }
            f4_temp = (float)S12AD2.ADDR11;

        break;

        default:
            /* Do Nothing */
        break;
    }

    return (f4_temp);
} /* End of function mtr_get_vdc_adc */

/***********************************************************************************************************************
* Function Name : mtr_get_vol_adc
* Description   : A/D conversion for Volume
* Arguments     : u1_id - Motor ID
* Return Value  : A/D converted value
***********************************************************************************************************************/
float mtr_get_vol_adc(uint8_t u1_id)
{
    float f4_temp;

    switch (u1_id)
    {
        case MTR_ID_A:
            while (1 == S12AD2.ADCSR.BIT.ADST)
            {
                /* Wait until AD conversion finish */
            }
            f4_temp = (float)S12AD2.ADDR0;

        break;

        default:
            /* Do Nothing */
        break;
    }

    return (f4_temp);
} /* End of function mtr_get_vol_adc */

/***********************************************************************************************************************
* Function Name : mtr_clear_oc_flag
* Description   : Clears forced cutoff flag (detect over current)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_clear_oc_flag(void)
{

    /* Release from high-impedance state */
    IR(POE,OEI1) = 1;                                   /* Interrupt request flag clear */
    POE.ICSR1.BIT.POE0F = 0;                            /* POE0# high-impedance request clear */
    POE.OCSR2.BIT.OSF2 = 0;                             /* Output short circuit flag clear */

} /* End of function mtr_clear_oc_flag */
