/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_interrupt.c
* Description : Interrupt Handlers
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <machine.h>
#include "iodefine.h"
#include "r_mtr_ics.h"
#include "r_mtr_foc_stm_rslv_control.h"
#include "r_mtr_stm_rslv_foc_rx_if.h"
#include "r_ctrl_rdc_driver_adapter.h"

#include "r_rslv_api.h"

uint16_t mtu9_interrupt_decimation_flag = 0;

#define VECT_RSLV_CAPTURE       VECT_MTU2_TGIA2
#define VECT_RSLV_CSIG          VECT_CMT1_CMI1
#define VECT_RSLV_ESIG          VECT_MTU9_TGIC9

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
mtr_foc_control_t g_st_foc;

/***********************************************************************************************************************
* Function Name : mtr_over_current_interrupt
* Description   : POE interrupt
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
#pragma interrupt (mtr_over_current_interrupt(vect = VECT_POE_OEI1))
static void mtr_over_current_interrupt(void)
{
    R_MTR_SR_Foc_INT_OverCur(MTR_ID_A);
} /* End of function mtr_over_current_interrupt */

/***********************************************************************************************************************
* Function Name : mtr_cmt0_interrupt
* Description   : CMT0 interrupt (Period: 250us)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
#pragma interrupt (mtr_cmt0_interrupt(vect = VECT_CMT0_CMI0))
static void mtr_cmt0_interrupt(void)
{
setpsw_i();                                       /* Interrupt enable */
    /* Position and Speed control */
    R_MTR_SR_Foc_INT_PosSpdCtrl(MTR_ID_A);

    /* ICS Watch */
    mtr_ics_interrupt_process();
} /* End of function mtr_cmt0_interrupt */

/***********************************************************************************************************************
* Function Name : mtr_get_rdc_alarm_interrupt
* Description   : IRQ5 interrupt
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
#pragma interrupt (mtr_get_rdc_alarm_interrupt(vect = VECT_ICU_IRQ5))
static void mtr_get_rdc_alarm_interrupt(void)
{
setpsw_i();                                       /* Interrupt enable */
    R_MTR_SR_Foc_INT_RdcAlarm(MTR_ID_A);
} /* End of function mtr_get_rdc_alarm_interrupt */

/***********************************************************************************************************************
* Function Name : mtr_csig_interrupt
* Description   : CMI1 interrupt(Duty update of PWM for carrier correction)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
#pragma interrupt (mtr_csig_interrupt(vect = VECT_RSLV_CSIG))
static void mtr_csig_interrupt(void)
{
setpsw_i();                                       /* Interrupt enable */
    R_RSLV_INT_CSig_UpdatePwmDuty();
} /* End of function mtr_csig_interrupt */

/***********************************************************************************************************************
* Function Name : mtr_cmt2_interrupt
* Description   : CMI2 interrupt(Duty update of PWM for resolver excitation signal)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
#pragma interrupt (mtr_cmt2_interrupt(vect = VECT_CMT2_CMI2))
static void mtr_cmt2_interrupt(void)
{
setpsw_i();                                       /* Interrupt enable */
        /*Do Nothing */

} /* End of function mtr_cmt2_interrupt */

/***********************************************************************************************************************
* Function Name : rslv_capture_interrupt
* Description   : TGIB6 interrupt(Detection of resolver position signal)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
#pragma interrupt (rslv_capture_interrupt(vect = VECT_RSLV_CAPTURE))
static void rslv_capture_interrupt(void)
{
    R_RSLV_INT_GetCaptureCount();
} /* End of function rslv_capture_interrupt */

/***********************************************************************************************************************
* Function Name : rslv_esig_interrupt
* Description   : TGIC9 interrupt
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
#pragma interrupt (rslv_esig_interrupt(vect = VECT_RSLV_ESIG))
static void rslv_esig_interrupt(void)
{
setpsw_i();

    if(mtu9_interrupt_decimation_flag == 0)
    {
        R_RSLV_INT_CSig_SyncStart();
        mtu9_interrupt_decimation_flag ++;
        R_RSLV_INT_ESigCounter();
    }
    else
    {
        mtu9_interrupt_decimation_flag = 0;
    }

} /* End of function rslv_esig_interrupt */

/***********************************************************************************************************************
* Function Name : mtr_s12ad_interrupt
* Description   : TGIA9 interrupt
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
#pragma interrupt (mtr_s12ad_interrupt(vect = VECT_S12AD1_S12ADI1))
static void mtr_s12ad_interrupt(void)
{
setpsw_i();                                       /* Interrupt enable */
    if (TRUE == R_RSLVADP_IsRDCReady())
    {
        R_MTR_SR_Foc_INT_CrntCtrl(MTR_ID_A);
    }
} /* End of function mtr_s12ad_interrupt */

/***********************************************************************************************************************
* Function Name: mtr_mtu3_tciv4_interrupt
* Description  : This function MTU3 TCIV4 interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
#pragma interrupt mtr_mtu3_tciv4_interrupt(vect=VECT(MTU4,TCIV4))
static void mtr_mtu3_tciv4_interrupt( void )
{
    uint16_t u2_angle_cnt;
    int16_t  s2_angle_diff;
#ifndef RISE_EDGE_ONLY
    uint16_t s2_AngleDiffHi;
    uint16_t s2_AngleDiffLo;
#endif
setpsw_i();                                       /* Interrupt enable */
    R_RSLV_GetAngleCountFirstEdge(&u2_angle_cnt);
    R_RSLV_GetAngleDifferenceFirstEdge(&s2_angle_diff);
    R_MTR_SR_Foc_SetAngleInfo(MTR_ID_A, u2_angle_cnt, s2_angle_diff);

#ifdef RISE_EDGE_ONLY

#else
    /* Get angle count value of resolver */
    if(RSLV_HIGH == R_RSLV_GetCaptureEdge())
    {
        R_RSLV_GetAngleCountFirstEdge(&g_st_foc.u2_rslv_angle_cnt);
    }
    else
    {
        R_RSLV_GetAngleCountSecondEdge(&g_st_foc.u2_rslv_angle_cnt);
    }
    R_RSLV_GetAngleDifferenceFirstEdge(&s2_AngleDiffHi);
    R_RSLV_GetAngleDifferenceSecondEdge(&s2_AngleDiffLo);
    g_st_foc.s2_angle_err_cnt = u2_AngleDiffHi + u2_AngleDiffLo;
    g_st_foc.s2_angle_err_cnt *= 0.5f;
#endif
    R_RSLVADP_IncreaseWaitTimer();

} /* End of function mtr_mtu3_tciv4_interrupt */
