/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_ctrl_mcu.h
* Description : Definitions for processing MCU control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

#ifndef R_MTR_CTRL_MCU_H
#define R_MTR_CTRL_MCU_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_config.h"
#include "r_mtr_ctrl_rx24t.h"

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/

/***** r_mtr_ctrl_rx24t *****/
/***********************************************************************************************************************
* Function Name : R_MTR_InitHardware
* Description   : Initialize peripheral functions
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_InitHardware(void);

/***********************************************************************************************************************
* Function Name : R_MTR_ClearWdt
* Description   : Clears Watch Dog Timer
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_ClearWdt(void);

/***********************************************************************************************************************
* Function Name : R_MTR_Start_cmt0
* Description   : This function starts the CMT0 channel counter.
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Start_cmt0( void );

/***********************************************************************************************************************
* Function Name : R_MTR_Stop_cmt0
* Description   : This function stops the CMT0 channel counter.
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Stop_cmt0( void );

/***********************************************************************************************************************
* Function Name : R_MTR_Start_mtu_c2
* Description   : MTU3 Encoder counter timer start
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Start_mtu_c2( void );

/***********************************************************************************************************************
* Function Name : R_MTR_Stop_mtu_c2
* Description   : MTU3 Encoder counter timer stop
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Stop_mtu_c2( void );

/***********************************************************************************************************************
* Function Name : R_MTR_Stop_mtu_c3_4
* Description   : MTU3_4 timer stop
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Stop_mtu_c3_4(void);

/***********************************************************************************************************************
* Function Name : R_MTR_Sync_StartCH3467
* Description   : MTU3_4_6_9 timer start
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Sync_StartCH3467(void);

/***********************************************************************************************************************
* Function Name: R_PORT_Set_RdcReset
* Description  : This function initializes the Port I/O for RDC control.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_PORT_Set_RdcReset( void );

/***********************************************************************************************************************
* Function Name: R_PORT_Cancel_RdcReset
* Description  : Cancel RDC reset (Set RDC reset port to "High".)
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_PORT_Cancel_RdcReset( void );

/***********************************************************************************************************************
* Function Name : R_MTR_Start_s12ad
* Description   : A/D Interrupt enable
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Start_s12ad(void);

/***********************************************************************************************************************
* Function Name : R_MTR_Stop_s12ad
* Description   : A/D Interrupt disable
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_Stop_s12ad(void);

/***********************************************************************************************************************
* Function Name : R_ICU_Start_irq5
* Description   : IRQ5 Interrupt enable
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_ICU_Start_irq5(void);

/***********************************************************************************************************************
* Function Name : R_ICU_Stop_irq5
* Description   : IRQ5 Interrupt disable
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_ICU_Stop_irq5(void);

/***********************************************************************************************************************
* Function Name : R_ICU_Clear_irq5_request
* Description   : IRQ5 Interrupt request clear
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_ICU_Clear_irq5_request(void);

/***********************************************************************************************************************
* Function Name : mtr_ctrl_start
* Description   : Starts PWM output
* Arguments     : u1_id - Motor ID
* Return Value  : None
***********************************************************************************************************************/
void mtr_ctrl_start(uint8_t u1_id);

/***********************************************************************************************************************
* Function Name : mtr_ctrl_stop
* Description   : Disable PWM output to stop motor control
* Arguments     : u1_id - Motor ID
* Return Value  : None
***********************************************************************************************************************/
void mtr_ctrl_stop(uint8_t u1_id);

/***********************************************************************************************************************
* Function Name : mtr_inv_set_ab
* Description   : PWM duty setting
* Arguments     : f4_duty_a - The duty cycle of Phase-a (0.0 - 1.0)
*                 f4_duty_b - The duty cycle of Phase-b (0.0 - 1.0)
*               : u1_id - Motor ID
* Return Value  : none
***********************************************************************************************************************/
void mtr_inv_set_ab(float f4_duty_a, float f4_duty_b, uint8_t u1_id);

/***********************************************************************************************************************
* Function Name : mtr_get_current_iaib_adc
* Description   : A/D conversion for Iu,Iw
* Arguments     : *f4_ia_ad, *f4_ib_ad - Current variables for Iu, Iw
*               : u1_id - Motor ID
* Return Value  : none
***********************************************************************************************************************/
void mtr_get_current_iaib_adc(float *f4_ia_ad, float *f4_ib_ad, uint8_t u1_id);

/***********************************************************************************************************************
* Function Name : mtr_get_voltage_vavb_adc
* Description   : A/D conversion for Va,Vb
* Arguments     : *f4_va_ad, *f4_vb_ad - Voltage variables for Va, Vb
*               : u1_id - Motor ID
* Return Value  : none
***********************************************************************************************************************/
void mtr_get_voltage_vavb_adc(float *f4_va_ad, float *f4_vb_ad, uint8_t u1_id);

/***********************************************************************************************************************
* Function Name : mtr_get_rdc_mnt_adc
* Description   : A/D conversion for RDC Monitor
* Arguments     : u1_id - Motor ID
* Return Value  : A/D converted value
***********************************************************************************************************************/
float mtr_get_rdc_mnt_adc(uint8_t u1_id);

/***********************************************************************************************************************
* Function Name : mtr_get_vdc_adc
* Description   : A/D conversion for Vdc
* Arguments     : u1_id - Motor ID
* Return Value  : A/D converted value
***********************************************************************************************************************/
float mtr_get_vdc_adc(uint8_t u1_id);

/***********************************************************************************************************************
* Function Name : mtr_get_vol_adc
* Description   : A/D conversion for Volume
* Arguments     : u1_id - Motor ID
* Return Value  : A/D converted value
***********************************************************************************************************************/
float mtr_get_vol_adc(uint8_t u1_id);

/***********************************************************************************************************************
* Function Name : mtr_clear_oc_flag
* Description   : Clears forced cutoff flag (detect over current);
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_clear_oc_flag(void);

/***** r_rslv_cmt_rx24t *****/
/***********************************************************************************************************************
* Function Name : R_RSLV_Init_cmt1
* Description   : Initializes CMT1()
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Init_cmt1(void);

/***********************************************************************************************************************
* Function Name : R_CMT1_Start
* Description   : This function starts the CMT1 channel counter.
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Start_cmt1( void );

/***********************************************************************************************************************
* Function Name : R_CMT1_Stop
* Description   : This function stops the CMT1 channel counter.
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Stop_cmt1( void );

/***********************************************************************************************************************
* Function Name : R_RSLV_set_cmt1_cmcnt
* Description   : CMT1.CMCNT setting
* Arguments     : timer_cnt - CMT1.CMCNT setting value
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_set_cmt1_cmcnt(uint16_t timer_cnt);

/***********************************************************************************************************************
* Function Name : R_RSLV_get_cmt1_cmcnt
* Description   : CMT1.CMCNT read
* Arguments     : None
* Return Value  : CMT1.CMCNT read value
***********************************************************************************************************************/
uint16_t R_RSLV_get_cmt1_cmcnt(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Init_cmt2
* Description   : Initializes CMT2()
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Init_cmt2(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Start_cmt2
* Description   : This function starts the CMT2 channel counter.
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Start_cmt2( void );

/***********************************************************************************************************************
* Function Name : R_RSLV_Stop_cmt2
* Description   : This function stops the CMT2 channel counter.
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Stop_cmt2( void );

/***********************************************************************************************************************
* Function Name : R_RSLV_set_cmt2_cmcnt
* Description   : CMT2.CMCNT setting
* Arguments     : timer_cnt - CMT2.CMCNT setting value
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_set_cmt2_cmcnt(uint16_t timer_cnt);

/***********************************************************************************************************************
* Function Name : R_RSLV_get_cmt2_cmcnt
* Description   : CMT2.CMCNT read
* Arguments     : None
* Return Value  : CMT2.CMCNT read value
***********************************************************************************************************************/
uint16_t R_RSLV_get_cmt2_cmcnt(void);

/***** r_rslv_rmr_rx24t *****/
/***********************************************************************************************************************
* Function Name : R_RSLV_Init_tmr1
* Description   : Initialize of TMR1 (RDC_CLK output)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Init_tmr1(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Start_tmr1
* Description   : TMR1 Timer start
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Start_tmr1(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Stop_tmr1
* Description   : TMR1 Timer stop
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Stop_tmr1(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Init_tmr3
* Description   : Initialize of TMR3 (RDC_CC output)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Init_tmr3(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Start_tmr3
* Description   : TMR3 Timer start
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Start_tmr3(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Stop_tmr3
* Description   : TMR3 Timer stop
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Stop_tmr3(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_set_tmr3_tcnt
* Description   : TMR3.TCNT setting
* Arguments     : timer_cnt - TMR3 TCNT setting value
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_set_tmr3_tcnt(uint16_t timer_cnt);

/***********************************************************************************************************************
* Function Name : R_RSLV_get_tmr3_tcnt
* Description   : MTU3_9.TCNT read
* Arguments     : None
* Return Value  : MTU3_9 TCNT read value
***********************************************************************************************************************/
uint16_t R_RSLV_get_tmr3_tcnt(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_set_tmr3_tcora
* Description   : TMR3.TCORA setting
* Arguments     : timer_cnt - TMR3.TCORA setting value
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_set_tmr3_tcora(uint16_t timer_cnt);

/***********************************************************************************************************************
* Function Name : R_RSLV_get_tmr3_tcora
* Description   : TMR3.TCORA read
* Arguments     : None
* Return Value  : TMR3.TCORA read value
***********************************************************************************************************************/
uint16_t R_RSLV_get_tmr3_tcora(void);

/***** r_rslv_mtu_rx24t *****/
/***********************************************************************************************************************
* Function Name : R_RSLV_Init_mtu_c6
* Description   : Initializes MTU3_6 timer
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Init_mtu_c6(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Start_mtu_c6
* Description   : MTU3_6 timer start
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Start_mtu_c6(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Stop_mtu_c6
* Description   : MTU3_6 timer stop
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Stop_mtu_c6(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Interrupt_Enable_mtu_c6
* Description   : Enable MTU3_6 timer interrupt
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Interrupt_Enable_mtu_c6(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Interrupt_Disable_mtu_c6
* Description   : Disable MTU3_6 timer interrupt
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Interrupt_Disable_mtu_c6(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_set_mtu6_tcnt
* Description   : MTU3_6.TCNT setting
* Arguments     : timer_cnt - MTU3_6 TCNT setting value
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_set_mtu6_tcnt(uint16_t timer_cnt);

/***********************************************************************************************************************
* Function Name : R_RSLV_get_mtu6_tcnt
* Description   : MTU3_6 TCNT read
* Arguments     : None
* Return Value  : MTU3_6 TCNT read value
***********************************************************************************************************************/
uint16_t R_RSLV_get_mtu6_tcnt(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_set_mtu6_tgrb
* Description   : MTU3_6.TGRB setting
* Arguments     : timer_cnt - MTU3_6 TGRB setting value
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_set_mtu6_tgrb(uint16_t timer_cnt);

/***********************************************************************************************************************
* Function Name : R_RSLV_get_mtu6_tgrb
* Description   : MTU3_6.TGRB read
* Arguments     : None
* Return Value  : MTU3_6 TGRB read value
***********************************************************************************************************************/
uint16_t R_RSLV_get_mtu6_tgrb(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_get_mtu6_io
* Description   : MTU3_6.TGRB read
* Arguments     : None
* Return Value  : MTU3_6 TGRB read value
***********************************************************************************************************************/
uint16_t R_RSLV_get_mtu6_io(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Init_mtu_7
* Description   : Initializes MTU3_7 timer
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Init_mtu_c7(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Start_mtu_c7
* Description   : MTU3_7 timer start
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Start_mtu_c7(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Stop_mtu_c7
* Description   : MTU3_7 timer stop
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Stop_mtu_c7(void);

/***********************************************************************************************************************
* Function Name: R_MTU3_C7_Set_PWM_duty
* Description  : This function set PWM duty of MTU3 Channel 0 (call in main.c)
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_MTU3_C7_Set_PWM_duty( void );

/***********************************************************************************************************************
* Function Name: R_MTU3_C7_Chg_APF_PWMA_Duty
* Description  : This function receive change request of PWM_A duty of MTU3 Channel 0 (APF signal)
* Arguments    : duty : requested change duty
* Return Value : None
***********************************************************************************************************************/
void R_MTU3_C7_Chg_APF_PWMA_Duty( uint16_t duty );

/***********************************************************************************************************************
* Function Name: R_MTU3_C6_Chg_APF_PWMB_Duty
* Description  : This function receive change request of PWM_B duty of MTU3 Channel 0 (APF signal)
* Arguments    : duty : requested change duty
* Return Value : None
***********************************************************************************************************************/
void R_MTU3_C7_Chg_APF_PWMB_Duty( uint16_t duty );

/***********************************************************************************************************************
* Function Name : R_RSLV_Init_mtu_c9
* Description   : Initializes MTU3_9 timer (Excitation signal output)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Init_mtu_c9(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Start_mtu_c9
* Description   : MTU3_9 timer start
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Start_mtu_c9(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Stop_mtu_c9
* Description   : MTU3_9 timer stop
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Stop_mtu_c9(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Interrupt_Enable_mtu_c9
* Description   : Enable MTU3_9 timer interrupt
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Interrupt_Enable_mtu_c9(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_Interrupt_Disable_mtu_c9
* Description   : Disable MTU3_9 timer interrupt
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_Interrupt_Disable_mtu_c9(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_set_mtu9_tcnt
* Description   : MTU3_9.TCNT setting
* Arguments     : timer_cnt - MTU3_9 TCNT setting value
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_set_mtu9_tcnt(uint16_t timer_cnt);

/***********************************************************************************************************************
* Function Name : R_RSLV_get_mtu9_tcnt
* Description   : MTU3_9.TCNT read
* Arguments     : None
* Return Value  : MTU3_9 TCNT read value
***********************************************************************************************************************/
uint16_t R_RSLV_get_mtu9_tcnt(void);

/***********************************************************************************************************************
* Function Name : R_RSLV_set_mtu9_tgra
* Description   : MTU3_9.TGRA setting
* Arguments     : timer_cnt - MTU3_9 TGRA setting value
* Return Value  : None
***********************************************************************************************************************/
void R_RSLV_set_mtu9_tgra(uint16_t timer_cnt);

/***********************************************************************************************************************
* Function Name : R_RSLV_get_mtu9_tgra
* Description   : MTU3_9.TGRA read
* Arguments     : None
* Return Value  : MTU3_9 TGRA read value
***********************************************************************************************************************/
uint16_t R_RSLV_get_mtu9_tgra(void);

#endif /* R_MTR_CTRL_MCU_H */
