/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_ctrl_rx24t.h
* Description : Definitions of MCU & inverter control layer for RX24T
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef MTR_CTRL_RX24T_H
#define MTR_CTRL_RX24T_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_parameter.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
#define     MTR_PWM_TIMER_FREQ      (80.0f)             /* PWM timer frequency [MHz] */
#define     MTR_CARRIER_FREQ        (20.0f)             /* Carrier wave frequency [kHz] */

#define     MTR_INT_DECIMATION      (0)                 /* Interrupt skipping number */
#define     MTR_CTRL_PERIOD         ((MTR_INT_DECIMATION + 1) / (MTR_CARRIER_FREQ * 1000))
                                                        /* Control period */

#define     MTR_AD_FREQ             (80.0f)             /* A/D frequency [MHz] */
#define     MTR_AD_SAMPLING_CYCLE   (47.0f)             /* Start-of-A/D-conversion delay time + sampling time [cycle] */
#define     MTR_AD_SAMPLING_TIME    (MTR_AD_SAMPLING_CYCLE / MTR_AD_FREQ)
                                                        /* A/D sampling time [us] */
#define     MTR_CARRIER_SET_BASE    ((uint16_t)(MTR_PWM_TIMER_FREQ * 1000 / MTR_CARRIER_FREQ / 2))
#define     MTR_DEADTIME_SET        ((uint16_t)(MTR_DEADTIME * MTR_PWM_TIMER_FREQ))
                                                        /* Setting value of deadtime */
#define     MTR_CARRIER_SET         ((uint16_t)(MTR_CARRIER_SET_BASE + MTR_DEADTIME_SET))
                                                        /* Max setting value of carrier period */

#define     MTR_ENCD_TIMER_FREQ     (80.0f)             /* Encoder phase counter capture clock frequency */
#define     MTR_ENCD_TCNT           (MTU2.TCNT)         /* Encoder timer counter */

#define     MTR_PORT_A_PH           (PORT7.PODR.BIT.B1) /* Output port of PWM timer(A+H) */
#define     MTR_PORT_A_PL           (PORT7.PODR.BIT.B4) /* Output port of PWM timer(A+L) */
#define     MTR_PORT_B_PH           (PORT7.PODR.BIT.B2) /* Output port of PWM timer(B+H) */
#define     MTR_PORT_B_PL           (PORT7.PODR.BIT.B5) /* Output port of PWM timer(B+L) */
#define     MTR_PORT_C_PH           (PORT7.PODR.BIT.B3) /* Output port of PWM timer(C+H) */
#define     MTR_PORT_C_PL           (PORT7.PODR.BIT.B6) /* Output port of PWM timer(C+L) */

#define     MTR_PORT_A_MH           (PORT9.PODR.BIT.B5) /* output port of PWM timer(A-H) */
#define     MTR_PORT_A_ML           (PORT9.PODR.BIT.B2) /* output port of PWM timer(A-L) */
#define     MTR_PORT_B_MH           (PORT9.PODR.BIT.B4) /* output port of PWM timer(B-H) */
#define     MTR_PORT_B_ML           (PORT9.PODR.BIT.B1) /* output port of PWM timer(B-L) */
#define     MTR_PORT_C_MH           (PORT9.PODR.BIT.B3) /* output port of PWM timer(C-H) */
#define     MTR_PORT_C_ML           (PORT9.PODR.BIT.B0) /* output port of PWM timer(C-L) */

#define     MTR_PORT_SW1            (PORT6.PIDR.BIT.B1)     /* Input port of SW1 */
#define     MTR_PORT_SW2            (PORT6.PIDR.BIT.B2)     /* Input port of SW2 */

#define     MTR_PORT_LED1           (PORT8.PODR.BIT.B1)     /* Output port of LED1 */
#define     MTR_PORT_LED2           (PORT8.PODR.BIT.B0)     /* Output port of LED2 */
#define     MTR_PORT_LED3           (PORTA.PODR.BIT.B2)     /* Output port of LED3 */

#define     MTR_AD12BIT_DATA        (4095.0f)           /* AD 12Bit data */
#define     MTR_CURRENT_SCALING     (MTR_CURRENT_RANGE / MTR_AD12BIT_DATA)
                                                        /* For current scaling */
#define     MTR_VDC_SCALING         (MTR_VDC_RANGE / MTR_AD12BIT_DATA)
                                                        /* For Vdc scaling */
#define     MTR_ADC_OFFSET          (0x7FF)             /* A/D offset */


#endif /* MTR_CTRL_RX24T_H */
