/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_ctrl_rdc_driver_adapter.c
* Description : This adapter is working with RX24T resolver solution board only
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "iodefine.h"

#include "r_ctrl_rdc_driver_adapter.h"
#include "r_mtr_config.h"
#include "r_mtr_common.h"
#include "r_resolver_rdc_command.h"
#include "r_mtr_ctrl_mcu.h"

#define DEF_DELAY_ADJ_ESIG      (2700U)             /* Adjustment of the start timing of excitation signal */
#define DEF_SFT_ADJ_ESIG        (0U)                /* Adjustment of the shift between excitation signal */

#define PRV_RDC_SPI_WAIT        (1000U)             /* Wait about 50ms */

#define MTU_TCSYSTR_BIT_MTU7  (1 << 0)
#define MTU_TCSYSTR_BIT_MTU6  (1 << 1)
#define MTU_TCSYSTR_BIT_MTU9  (1 << 2)
#define MTU_TCSYSTR_BIT_MTU4  (1 << 3)
#define MTU_TCSYSTR_BIT_MTU3  (1 << 4)
#define MTU_TCSYSTR_BIT_MTU2  (1 << 5)
#define MTU_TCSYSTR_BIT_MTU1  (1 << 6)
#define MTU_TCSYSTR_BIT_MTU0  (1 << 7)

/*==============================*/
/* <RDC_DRV> driver parameter   */
/*==============================*/
static const uint8_t s_u1_rdc_init_data[] =
{
    RDC_CMD_INITIAL_VALUE_02h,
    RDC_CMD_INITIAL_VALUE_04h,
    RDC_CMD_INITIAL_VALUE_0Ah,
    RDC_CMD_INITIAL_VALUE_16h,
    RDC_CMD_INITIAL_VALUE_2Eh,
    RDC_CMD_INITIAL_VALUE_42h,
};

ST_INIT_REG_PARAM       st_init_reg_param;
ST_RDC_DRV_SETTING_INFO st_drv_info;
ST_SYSTEM_PARAM         st_system_param;
uint16_t g_u2_rdc_reset_wait_count  = 0U;     /* Counter for waiting at initialization process */
uint8_t  g_u1_rdc_reset_wait_status = RDC_RESET_STATE_NON;

uint8_t     com_u1_flg_csig = TRUE;           /* Flag of carrier correction ON /OFF signal */
uint8_t     g_u1_flg_pre_csig = FALSE;        /* Previous value of the flag of carrier correction ON/OFF signal */
uint8_t     com_u1_flg_upd_csigparam = FALSE; /* Update shift value of carrier correction */
uint16_t    com_u2_csig_shiftnum = 184U;      /* Shift number of carrier compensation signal */
uint16_t    com_u2_csig_amplvl = 4U;          /* Amplitude level of carrier compensation signal */
uint8_t     com_u1_flg_rdc_sequence = TRUE;
uint8_t     g_u1_flg_rdc_state_ready = FALSE;

static void RESOLVER_peripheral_init(void);
static void RDC_peripheral_init(void);
static void resolver_csig_ui(void);
static void write_rdc_reset_gpio(uint8_t val);

/***********************************************************************************************************************
* Function Name : R_RSLVADP_Init
* Description   : Resolver related processing initialization
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLVADP_Init(void)
{
    /* Setting of peripheral function for resolver */
    RESOLVER_peripheral_init();

    /* Initializes of RDC Register Values */
    R_RSLV_Rdc_VariableInit((unsigned char*)s_u1_rdc_init_data);

    /* Initializes of peripherals related to RDC */
    RDC_peripheral_init();
}

/***********************************************************************************************************************
* Function Name : R_RSLVADP_InitOnlyPGA
* Description   : Initialization related to RDC
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLVADP_InitOnlyPGA(void)
{
    /* Initializes of RDC Register Values */
    R_RSLV_Rdc_VariableInit((unsigned char*)s_u1_rdc_init_data);

    /* Initializes of peripherals related to RDC */
    RDC_peripheral_init();
}

/***********************************************************************************************************************
* Function Name : R_RSLVADP_Start
* Description   : Resolver start processing
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLVADP_Start(void)
{
    /* Initialize resolver setting */
    R_RSLV_ESig_Start();
    R_RSLV_MTU_SyncStart(MTU_TCSYSTR_BIT_MTU9 | MTU_TCSYSTR_BIT_MTU2
                        | MTU_TCSYSTR_BIT_MTU3 | MTU_TCSYSTR_BIT_MTU4 | MTU_TCSYSTR_BIT_MTU6 | MTU_TCSYSTR_BIT_MTU7);

    /* Output carrier correction signal (current default is "TRUE") */
    if (TRUE == com_u1_flg_csig)
    {
        R_RSLV_CSig_Start(com_u2_csig_shiftnum, com_u2_csig_amplvl);
    }
    else
    {
        R_RSLV_CSig_Stop();
    }
    g_u1_flg_pre_csig = com_u1_flg_csig;
}

/***********************************************************************************************************************
* Function Name : R_RSLVADP_MainLoopProcess
* Description   : Resolver management process for main loop
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLVADP_MainLoopProcess(void)
{
    uint16_t rdc_result = RSLV_MD_BUSY1;

    resolver_csig_ui();

    if (TRUE == com_u1_flg_rdc_sequence)
    {
         g_u1_flg_rdc_state_ready = FALSE;

        if(RDC_RESET_STATE_NON == g_u1_rdc_reset_wait_status)
        {
            write_rdc_reset_gpio(1);
            g_u1_rdc_reset_wait_status = RDC_RESET_STATE_ACT;
            g_u2_rdc_reset_wait_count = 0;
        }
        else if(RDC_RESET_STATE_ACT == g_u1_rdc_reset_wait_status)
        {
            if(PRV_RDC_SPI_WAIT < g_u2_rdc_reset_wait_count)   /* Wait 1000 count * 50[us] = 50[ms] */
            {
                g_u1_rdc_reset_wait_status = RDC_RESET_STATE_FIN;
            }
        }
        else if(RDC_RESET_STATE_FIN == g_u1_rdc_reset_wait_status)
        {
            R_RSLV_Rdc_Init_Sequence(&rdc_result);
            if (RSLV_MD_OK == rdc_result)
            {
                 com_u1_flg_rdc_sequence = FALSE;
                 g_u1_flg_rdc_state_ready = TRUE;
                 /* Start of IRQ5 */
                 R_ICU_Start_irq5();
            }
        }
        else
        {
            ;
        }
    }

    /* RDC SPI main Function */
    R_RSLV_Rdc_Communication();

    /* Update PWM timer registers for phase adjust signals */
    R_RSLV_Phase_AdjUpdate();
}

/***********************************************************************************************************************
* Function Name : R_RSLVADP_IsRDCReady
* Description   : Get RDC ready status
* Arguments     : None
* Return Value  : RDC ready status
***********************************************************************************************************************/
uint8_t R_RSLVADP_IsRDCReady(void)
{
    return g_u1_flg_rdc_state_ready;
}

/***********************************************************************************************************************
* Function Name : R_RSLVADP_IncreaseWaitTimer
* Description   : Increase processing of wait timer counter
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLVADP_IncreaseWaitTimer(void)
{
    if (RDC_RESET_STATE_ACT == g_u1_rdc_reset_wait_status)
    {
        g_u2_rdc_reset_wait_count++;
    }
}

/***********************************************************************************************************************
* Function Name : RESOLVER_peripheral_init
* Description   : Peripheral module initialization for resolver
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void RESOLVER_peripheral_init(void)
{
    ST_SYSTEM_PARAM   st_system_param;
    ST_INIT_REG_PARAM rdc_init_param;

    /* RX24T 100pin */
    st_system_param.u1_mcu_type = MCU_TYPE_R5F524TAADFP;
    /* ESig frequency 20kHz */
    st_system_param.u1_esig_freq = R_ESIG_SET_FREQ_20K;
    /* CSig frequency 200kHz */
    st_system_param.u1_csig_freq = R_CSIG_SET_FREQ_200K;
    /* Update Count 2 times*/
    st_system_param.u1_csig_upd_duty_cycle = R_CSIG_SET_DCNT_02;
    /* Use MTU synchronize start */
    st_system_param.u1_mtu3_sync_start = MTU_SYNC_START_ENABLE;
    /* Target Motor is a STM motor */
    st_system_param.u1_motor_kind = MOTOR_STM;
    /* Disable extension function */
    st_system_param.u1_extension_use = R_EXT_INACTIVE;
    R_RSLV_SetSystemInfo(&st_system_param);

    R_RSLV_SetCaptureTiming(DEF_SFT_ADJ_ESIG);      /* Capture start timing */
    R_RSLV_ESigStartTiming(DEF_DELAY_ADJ_ESIG);     /* Esig start timing*/

    // MTU3_9 ESig12
    rdc_init_param.u1_sel_reg_type    = T_MTU3_9;
    rdc_init_param.u1_sel_reg_func    = F_ESIG12;
    rdc_init_param.u1_sel_int_flg     = INT_ENABLE;
    rdc_init_param.u1_sel_int_priorty = 11;
    rdc_init_param.u1_capture_trig    = CAPTURE_TRIG_NONE;
    rdc_init_param.u1_use_port1       = P_P21;
    rdc_init_param.u1_use_port2       = P_PE0;
    rdc_init_param.u1_use_port3       = 0xFF;       /* Not use */
    rdc_init_param.u1_use_port4       = 0xFF;       /* Not use */
    R_RSLV_CreatePeripheral(&rdc_init_param);

    // MTU3_0 CSig
    rdc_init_param.u1_sel_reg_type    = T_MTU3_0;
    rdc_init_param.u1_sel_reg_func    = F_CSIG;
    rdc_init_param.u1_sel_int_flg     = INT_DISABLE;
    rdc_init_param.u1_sel_int_priorty = 0;
    rdc_init_param.u1_capture_trig    = CAPTURE_TRIG_NONE;
    rdc_init_param.u1_use_port1       = P_P31;
    rdc_init_param.u1_use_port2       = 0xFF;       /* Not use */
    rdc_init_param.u1_use_port3       = 0xFF;       /* Not use */
    rdc_init_param.u1_use_port4       = 0xFF;       /* Not use */
    R_RSLV_CreatePeripheral(&rdc_init_param);
#if (IP_PWM_INDEPENDENT == 0)
    // MTU3_6 Capture
    rdc_init_param.u1_sel_reg_type    = T_MTU3_6;
    rdc_init_param.u1_sel_reg_func    = F_CAPTURE;
    rdc_init_param.u1_sel_int_flg     = INT_ENABLE;
    rdc_init_param.u1_sel_int_priorty = 13;
    rdc_init_param.u1_capture_trig    = CAPTURE_TRIG_FIRST_EDGE;
    rdc_init_param.u1_use_port1       = P_P95;
    rdc_init_param.u1_use_port2       = 0xFF;       /* Not use */
    rdc_init_param.u1_use_port3       = 0xFF;       /* Not use */
    rdc_init_param.u1_use_port4       = 0xFF;       /* Not use */
    R_RSLV_CreatePeripheral(&rdc_init_param);
#elif (IP_PWM_INDEPENDENT == 1)
    // MTU3_2 Capture
    rdc_init_param.u1_sel_reg_type    = T_MTU3_2;
    rdc_init_param.u1_sel_reg_func    = F_CAPTURE;
    rdc_init_param.u1_sel_int_flg     = INT_ENABLE;
    rdc_init_param.u1_sel_int_priorty = 13;
    rdc_init_param.u1_capture_trig    = CAPTURE_TRIG_FIRST_EDGE;
    rdc_init_param.u1_use_port1       = P_PA3;
    rdc_init_param.u1_use_port2       = 0xFF;       /* Not use */
    rdc_init_param.u1_use_port3       = 0xFF;       /* Not use */
    rdc_init_param.u1_use_port4       = 0xFF;       /* Not use */
    R_RSLV_CreatePeripheral(&rdc_init_param);
#endif
    // CMT1 CSig Update Timer
    rdc_init_param.u1_sel_reg_type    = T_CMT1;
    rdc_init_param.u1_sel_reg_func    = F_CSIG_UPD_TIMER;
    rdc_init_param.u1_sel_int_flg     = INT_ENABLE;
    rdc_init_param.u1_sel_int_priorty = 14;
    rdc_init_param.u1_capture_trig    = CAPTURE_TRIG_NONE;
    rdc_init_param.u1_use_port1       = 0xFF;       /* Not use */
    rdc_init_param.u1_use_port2       = 0xFF;       /* Not use */
    rdc_init_param.u1_use_port3       = 0xFF;       /* Not use */
    rdc_init_param.u1_use_port4       = 0xFF;       /* Not use */
    R_RSLV_CreatePeripheral(&rdc_init_param);

    R_RSLV_ESig_Stop();
    R_RSLV_CSig_Stop();

    /* Get resolver setting  */
    R_RSLV_GetRdcDrvSettingInfo(&st_drv_info);

} /* End of function RESOLVER_peripheral_init() */

/***********************************************************************************************************************
* Function Name : RDC_peripheral_init
* Description   : Peripheral module initialization for RDC
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void RDC_peripheral_init(void)
{
    ST_INIT_REG_PARAM rdc_init_param;

    /* Initialize pin3 of PORT4 for reset signal of RDC, starting with low-level will enter reset process */
    /* STM board use P43 as RDC reset pin */
    PORT4.PODR.BIT.B3   = 0;
    PORT4.PDR.BIT.B3    = 1;

    /* TMR0 PhaseA */
    rdc_init_param.u1_sel_reg_type    = T_TMR0;
    rdc_init_param.u1_sel_reg_func    = F_PHASE_A;
    rdc_init_param.u1_sel_int_flg     = INT_DISABLE;
    rdc_init_param.u1_sel_int_priorty = 0;
    rdc_init_param.u1_capture_trig    = CAPTURE_TRIG_NONE;
    rdc_init_param.u1_use_port1       = P_PB0;
    rdc_init_param.u1_use_port2       = 0xFF;
    rdc_init_param.u1_use_port3       = 0xFF;       /* Not use */
    rdc_init_param.u1_use_port4       = 0xFF;       /* Not use */
    R_RSLV_CreatePeripheral(&rdc_init_param);

    /* TMR4 PhaseB */
    rdc_init_param.u1_sel_reg_type    = T_TMR4;
    rdc_init_param.u1_sel_reg_func    = F_PHASE_B;
    rdc_init_param.u1_sel_int_flg     = INT_DISABLE;
    rdc_init_param.u1_sel_int_priorty = 0;
    rdc_init_param.u1_capture_trig    = CAPTURE_TRIG_NONE;
    rdc_init_param.u1_use_port1       = P_P82;
    rdc_init_param.u1_use_port2       = 0xFF;
    rdc_init_param.u1_use_port3       = 0xFF;       /* Not use */
    rdc_init_param.u1_use_port4       = 0xFF;       /* Not use */
    R_RSLV_CreatePeripheral(&rdc_init_param);

    /* TMR3 RDC CLOCK */
    rdc_init_param.u1_sel_reg_type    = T_TMR3;
    rdc_init_param.u1_sel_reg_func    = F_RDC_CLK;
    rdc_init_param.u1_sel_int_flg     = INT_DISABLE;
    rdc_init_param.u1_sel_int_priorty = 0;
    rdc_init_param.u1_capture_trig    = CAPTURE_TRIG_NONE;
    rdc_init_param.u1_use_port1       = P_P11;
    rdc_init_param.u1_use_port2       = 0xFF;       /* Not use */
    rdc_init_param.u1_use_port3       = 0xFF;       /* Not use */
    rdc_init_param.u1_use_port4       = 0xFF;       /* Not use */
    R_RSLV_CreatePeripheral(&rdc_init_param);

    /* RSPI0 RDC Communication */
    rdc_init_param.u1_sel_reg_type    = T_RSPI;
    rdc_init_param.u1_sel_reg_func    = F_RDC_COM;
    rdc_init_param.u1_sel_int_flg     = INT_ENABLE;
    rdc_init_param.u1_sel_int_priorty = 9;
    rdc_init_param.u1_capture_trig    = CAPTURE_TRIG_NONE;
    rdc_init_param.u1_use_port1       = P_PA4;      /* SCK */
    rdc_init_param.u1_use_port2       = P_P23;      /* MOSIA */
    rdc_init_param.u1_use_port3       = P_P22;      /* MISOA */
    rdc_init_param.u1_use_port4       = P_PD6;      /* CS(SSLAX) */
    R_RSLV_CreatePeripheral(&rdc_init_param);

} /* End of function RDC_peripheral_init */

/***********************************************************************************************************************
* Function Name : resolver_csig_ui
* Description   : CSIG interface setting process
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void resolver_csig_ui(void)
{
    if ((TRUE == com_u1_flg_csig ))
    {
        if (FALSE ==g_u1_flg_pre_csig)
        {
            R_RSLV_CSig_Start(com_u2_csig_shiftnum, com_u2_csig_amplvl);
            g_u1_flg_pre_csig = TRUE;
        }
        if (TRUE == com_u1_flg_upd_csigparam)
        {
            com_u1_flg_upd_csigparam = FALSE;
            R_RSLV_CSig_Stop();
            R_RSLV_CSig_Start(com_u2_csig_shiftnum, com_u2_csig_amplvl);
        }
    }
    if (FALSE == com_u1_flg_csig)
    {
        R_RSLV_CSig_Stop();
        g_u1_flg_pre_csig = FALSE;
    }
}

/***********************************************************************************************************************
* Function Name : write_rdc_reset_gpio
* Description   : RDC reset processing
* Arguments     : val    - Reset pin value(1: high level, 0: low level)
* Return Value  : None
***********************************************************************************************************************/
static void write_rdc_reset_gpio(uint8_t val)
{
    PORT4.PODR.BIT.B3 = val & 0x01;
}
