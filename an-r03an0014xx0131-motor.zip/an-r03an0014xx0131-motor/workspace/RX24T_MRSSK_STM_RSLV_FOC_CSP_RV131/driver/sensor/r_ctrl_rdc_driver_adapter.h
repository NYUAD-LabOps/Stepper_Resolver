/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_ctrl_rdc_driver_adapter.h
* Description : Definitions of resolver control processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/**********************************************************************************************************************
 * Includes <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "r_rslv_api.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* RDC reset status */
#define RDC_RESET_STATE_NON       (0)         /* RDC reset cancel unprocessed     */
#define RDC_RESET_STATE_ACT       (1)         /* RDC reset cancel in progress     */
#define RDC_RESET_STATE_FIN       (2)         /* RDC reset cancel finish          */

/***********************************************************************************************************************
* global functions
***********************************************************************************************************************/
/* guard against multiple inclusion */
/***********************************************************************************************************************
* Function Name : R_RSLVADP_Init
* Description   : Resolver related processing initialization
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLVADP_Init(void);

/***********************************************************************************************************************
* Function Name : R_RSLVADP_InitOnlyPGA
* Description   : Initialization related to RDC
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLVADP_InitOnlyPGA(void);

/***********************************************************************************************************************
* Function Name : R_RSLVADP_Start
* Description   : Resolver start processing
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLVADP_Start(void);

/***********************************************************************************************************************
* Function Name : R_RSLVADP_MainLoopProcess
* Description   : Resolver management process for main loop
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLVADP_MainLoopProcess(void);

/***********************************************************************************************************************
* Function Name : R_RSLVADP_IsRDCReady
* Description   : Get RDC ready status
* Arguments     : None
* Return Value  : RDC ready status
***********************************************************************************************************************/
uint8_t R_RSLVADP_IsRDCReady(void);

/***********************************************************************************************************************
* Function Name : R_RSLVADP_IncreaseWaitTimer
* Description   : Increase processing of wait timer counter
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_RSLVADP_IncreaseWaitTimer(void);

/***********************************************************************************************************************
Exported global variables
***********************************************************************************************************************/
extern uint8_t     com_u1_flg_csig;
extern uint16_t    com_u2_csig_shiftnum;        /* Shift number of carrier compensation signal */
extern uint16_t    com_u2_csig_amplvl;          /* Amplitude level of carrier compensation signal */
extern uint8_t     com_u1_flg_upd_csigparam;
extern ST_RDC_DRV_SETTING_INFO st_drv_info;

