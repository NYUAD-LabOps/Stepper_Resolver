/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_ctrl_inverter.h
* Description : Definitions of processes of a H/W control layer(Inverter board dependence)
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*           23.04.2021 1.31     First Release
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MTR_CTRL_MRSSK_H
#define R_MTR_CTRL_MRSSK_H

/***********************************************************************************************************************
* Function Name : led1_on
* Description   : Turn on LED1
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void led1_on(void);

/***********************************************************************************************************************
* Function Name : led1_off
* Description   : Turn off LED1
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void led1_off(void);

/***********************************************************************************************************************
* Function Name : led2_on
* Description   : Turn on LED2
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void led2_on(void);

/***********************************************************************************************************************
* Function Name : led2_off
* Description   : Turn off LED2
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void led2_off(void);

/***********************************************************************************************************************
* Function Name : mtr_get_vdc
* Description   : Get Vdc
* Arguments     : u1_id - Motor ID
* Return Value  : Vdc value
***********************************************************************************************************************/
float mtr_get_vdc(uint8_t u1_id);

/***********************************************************************************************************************
* Function Name : mtr_get_current_iaib
* Description   : Get current
* Arguments     : f4_ia_ad, f4_ib_ad - Current variables for a,b phase [A] (pointer),
*               : u1_id - Motor ID
* Return Value  : none
***********************************************************************************************************************/
void mtr_get_current_iaib(float *f4_ia_ad, float *f4_ib_ad, uint8_t u1_id);

/***********************************************************************************************************************
* Function Name : mtr_get_voltage_vavb
* Description   : Get voltage
* Arguments     : f4_va_ad, f4_vb_ad - Voltage variables for a,b phase [V] (pointer),
* Return Value  : none
***********************************************************************************************************************/
void mtr_get_voltage_vavb(float *f4_va_ad, float *f4_vb_ad, uint8_t u1_id);

/***********************************************************************************************************************
* Function Name : mtr_get_rdc_mnt
* Description   : Get rdc mnt
* Arguments     : u1_id - Motor ID
* Return Value  : Rdc monitor value
***********************************************************************************************************************/
float mtr_get_rdc_mnt(uint8_t u1_id);

#endif /* R_MTR_CTRL_MRSSK_H */
