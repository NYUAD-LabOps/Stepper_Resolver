/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_rslv_api.h
* Version      :
* Device(s)    : R5F524T***** & R5F523T*****
* Tool-Chain   : CCRX
* Description  : Header of interface with resolver functions
* Creation Date: 2019/XX/XX
***********************************************************************************************************************/
#ifndef R_RSLV_API_H
#define R_RSLV_API_H

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions (compile SW)
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* Status list definition */
#define RSLV_MD_STATUSBASE        (0x00U)
#define RSLV_MD_OK                (RSLV_MD_STATUSBASE + 0x00U) /* register setting OK */
#define RSLV_MD_SPT               (RSLV_MD_STATUSBASE + 0x01U) /* IIC stop */
#define RSLV_MD_NACK              (RSLV_MD_STATUSBASE + 0x02U) /* IIC no ACK */
#define RSLV_MD_BUSY1             (RSLV_MD_STATUSBASE + 0x03U) /* busy 1 */
#define RSLV_MD_BUSY2             (RSLV_MD_STATUSBASE + 0x04U) /* busy 2 */
/* Error list definition */
#define RSLV_MD_ERRORBASE         (0x80U)
#define RSLV_MD_ERROR             (RSLV_MD_ERRORBASE + 0x00U)  /* error */
#define RSLV_MD_ARGERROR          (RSLV_MD_ERRORBASE + 0x01U)  /* error argument input error */
#define RSLV_MD_ERROR1            (RSLV_MD_ERRORBASE + 0x02U)  /* error 1 */
#define RSLV_MD_ERROR2            (RSLV_MD_ERRORBASE + 0x03U)  /* error 2 */
#define RSLV_MD_ERROR3            (RSLV_MD_ERRORBASE + 0x04U)  /* error 3 */
#define RSLV_MD_ERROR4            (RSLV_MD_ERRORBASE + 0x05U)  /* error 4 */
#define RSLV_MD_ERROR5            (RSLV_MD_ERRORBASE + 0x06U)  /* error 5 */

/* Do not edit the macro definition given bellow! */
#define R_ESIG_FREQUENCY_5K       (5000.0f)   /* Setting ESig frequency as 5kHz            */
#define R_ESIG_FREQUENCY_10K      (10000.0f)  /* Setting ESig frequency as 10kHz           */
#define R_ESIG_FREQUENCY_20K      (20000.0f)  /* Setting ESig frequency as 20kHz           */

/* Definition of register type. */
#define T_TMR0                    (0)         /* TMR0 register                           */
#define T_TMR1                    (1)         /* TMR1 register                           */
#define T_TMR2                    (2)         /* TMR2 register                           */
#define T_TMR3                    (3)         /* TMR3 register                           */
#define T_TMR4                    (4)         /* TMR4 register(RX24T)                    */
#define T_TMR5                    (5)         /* TMR5 register(RX24T)                    */
#define T_TMR6                    (6)         /* TMR6 register(RX24T)                    */
#define T_TMR7                    (7)         /* TMR7 register(RX24T)                    */
#define T_MTU3_0                  (8)         /* MTU3_0 register                         */
#define T_MTU3_1                  (9)         /* MTU3_1 register                         */
#define T_MTU3_2                  (10)        /* MTU3_2 register                         */
#define T_RESERVE1                (11)        /* MTU3_5 register(Setting prohibited)     */
#define T_MTU3_6                  (12)        /* MTU3_6 register(RX24T)                  */
#define T_MTU3_7                  (13)        /* MTU3_7 register(RX24T)                  */
#define T_MTU3_9                  (14)        /* MTU3_9 register(RX24T)                  */
#define T_CMT0                    (15)        /* CMT0 register                           */
#define T_CMT1                    (16)        /* CMT1 register                           */
#define T_CMT2                    (17)        /* CMT2 register                           */
#define T_CMT3                    (18)        /* CMT3 register                           */
#define T_RSPI                    (19)        /* RSPI register                           */
#define T_RESERVE2                (20)        /* PORT0 register(Setting prohibited)      */
#define T_SCI1                    (21)        /* SCI1 register                           */
#define T_SCI5                    (22)        /* SCI5 register                           */
#define T_SCI6                    (23)        /* SCI6 register                           */
#define T_REG_MAX                 (24)        /* Peripheral ID Max                       */

/* Definition of function type */
#define F_ESIG1                   (0)         /* Excitation signal only                               */
#define F_ESIG2_1                 (1)         /* Excitation signal when outputting                    */
                                              /* signals with different timers (Setting prohibited)   */
#define F_ESIG2_2                 (2)         /* For excitation signal synthesis (Setting prohibited) */
#define F_ESIG12                  (3)         /* When outputting excitation signal and                */
                                              /* synthesis signal by 1 register                       */
#define F_CSIG                    (4)         /* Carrier correction signal                            */
#define F_PHASE_A                 (5)         /* Phase adjustment signal-A                            */
#define F_PHASE_B                 (6)         /* Phase adjustment signal-B                            */
#define F_PHASE_AB                (7)         /* Phase adjustment signal-A/B (Setting prohibited)     */
#define F_CAPTURE                 (8)         /* Phase signal input(Input Capture)                    */
#define F_CSIG_UPD_TIMER          (9)         /* Carrier correction duty update timer                 */
#define F_RDC_COM                 (10)        /* RDC communication                                    */
#define F_RDC_CLK                 (11)        /* RDC clock                                            */
#define F_RESERVE1                (12)        /* RDC reset (Setting prohibited)                       */
#define F_FUNC_MAX                (13)        /* Function ID Max                                      */

/* Definition value for port specification */
#define P_P00                     (0)         /* P00(Setting prohibited)                 */
#define P_P01                     (1)         /* P01(Setting prohibited)                 */
#define P_P02                     (2)         /* MTU3_9:MTIOC9D                          */
#define P_P10                     (3)         /* MTU3_9:MTIOC9B                          */
#define P_P11                     (4)         /* TMO3                                    */
#define P_P20                     (5)         /* MTU3_9:MTIOC9C                          */
#define P_P21                     (6)         /* MTU3_9:MTIOC9A                          */
#define P_P22                     (7)         /* TMO4, MISOA                             */
#define P_P23                     (8)         /* TMO2, MOSIA                             */
#define P_P24                     (9)         /* TMO6, RSPCKA                            */
#define P_P30                     (10)        /* MTU3_0:MTIOC0B, SSLA0                   */
#define P_P31                     (11)        /* MTU3_0:MTIOC0A, SSLA1                   */
#define P_P32                     (12)        /* TMO6, SSLA2                             */
#define P_P33                     (13)        /* TMO0, SSLA3                             */
#define P_P82                     (14)        /* TMO4, SCK6                              */
#define P_P90                     (15)        /* MTU3_7:MTIOC7D                          */
#define P_P91                     (16)        /* MTU3_7:MTIOC7C                          */
#define P_P92                     (17)        /* MTU3_6:MTIOC6D                          */
#define P_P93                     (18)        /* MTU3_7:MTIOC7B                          */
#define P_P94                     (19)        /* MTU3_7:MTIOC7A                          */
#define P_P95                     (20)        /* MTU3_6:MTIOC6B                          */
#define P_PA0                     (21)        /* TMO2, MTU3_6:MTIOC6C, SSLA3             */
#define P_PA1                     (22)        /* TMO4, MTU3_6:MTIOC6A, SSLA2             */
#define P_PA2                     (23)        /* TMO7, MTU3_2:MTIOC2B, SSLA1             */
#define P_PA3                     (24)        /* MTU3_2:MTIOC2A, SSLA0                   */
#define P_PA4                     (25)        /* MTU3_1:MTIOC1B, SCK6, RSPCKA            */
#define P_PA5                     (26)        /* MTU3_1:MTIOC1A, SMISO6, MISOA           */
#define P_PB0                     (27)        /* TMO0, MTU3_0: MTIOC0D, SMOSI6, MOSIA    */
#define P_PB1                     (28)        /* MTU3_0:MTIOC0C, SMISO6                  */
#define P_PB2                     (29)        /* MTU3_0:MTIOC0B, SMOSI6                  */
#define P_PB3                     (30)        /* MTU3_0:MTIOC0A, SCK6, RSPCKA            */
#define P_PD0                     (31)        /* TMO6, RSPCKA                            */
#define P_PD1                     (32)        /* TMO2, MISOA                             */
#define P_PD2                     (33)        /* TMO4, SCK5, MOSIA                       */
#define P_PD3                     (34)        /* TMO0, SMOSI1                            */
#define P_PD4                     (35)        /* SCK1                                    */
#define P_PD5                     (36)        /* SMISO1                                  */
#define P_PD6                     (37)        /* TMO1, MTU3_9:MTIOC9C, SSLA0             */
#define P_PD7                     (38)        /* MTU3_9:MTIOC9A, SMOSI5, SSLA1           */
#define P_PE0                     (39)        /* MTU3_9:MTIOC9B, SMISO5, SSLA2           */
#define P_PE1                     (40)        /* TMO5, MTU3_9:MTIOC9D, SSLA3             */
#define P_PB6                     (41)        /* SMISO5                                  */
#define P_PB5                     (42)        /* SMOSI5                                  */
#define P_PB7                     (43)        /* SCK5                                    */
#define P_P80                     (44)        /* SMISO6                                  */
#define P_P81                     (45)        /* SMOSI6                                  */
#define P_MAX                     (46)        /* PORT MAX                                */

#define P_NO_USE                  (0xff)      /* no use */

/* MCU type */
#define MCU_TYPE_R5F524TAADFM     (1)         /* RX24T-R5F524TAADFM(64pin)                      */
#define MCU_TYPE_R5F524TAADFP     (2)         /* RX24T-R5F524TAADFP(100pin)                     */

/* RDC register ID definition */
#define RDC_ADDR_PS1_02           (0x02)
#define RDC_ADDR_PS2_04           (0x04)
#define RDC_ADDR_SWRST_06         (0x06)
#define RDC_ADDR_PS3_0A           (0x0A)
#define RDC_ADDR_DDMNT_0E         (0x0E)
#define RDC_ADDR_ALMST_12         (0x12)
#define RDC_ADDR_ALMOUT_16        (0x16)
#define RDC_ADDR_MNTSL_20         (0x20)
#define RDC_ADDR_MDCACSEL_28      (0x28)
#define RDC_ADDR_GCGSL_2E         (0x2E)
#define RDC_ADDR_DLCGSL_30        (0x30)
#define RDC_ADDR_CCGSL_36         (0x36)
#define RDC_ADDR_CSACTL_42        (0x42)
#define RDC_ADDR_FOPER_48         (0x48)
#define RDC_ADDR_INITERR_54       (0x54)

#define PHASE_CH_A                (0)         /* Phase Channel A       */
#define PHASE_CH_B                (1)         /* Phase Channel B       */
#define INT_ENABLE                (1)         /* Enable Setting value  */
#define INT_DISABLE               (0)         /* Disable Setting value */

#define RDC_CS_ON                 (2)         /* RDC chip select ON (Port "L")    */
#define RDC_CS_OFF                (3)         /* RDC chip select ON (Port "H")    */

#define RDC_ALARM_PORT            (4)         /* Get RDC Alarm port value */

#define CAPTURE_TRIG_NONE         (0)         /* Input capture trigger : None         */
#define CAPTURE_TRIG_FIRST_EDGE   (1)         /* Input capture trigger : First edge  */
#define CAPTURE_TRIG_SECOND_EDGE  (2)         /* Input capture trigger : Second edge */
#define CAPTURE_TRIG_BOTH_EDGE    (3)         /* Input capture trigger : Both edge    */

/* DO NOT EDIT THE FOLLOWING MACRO DEFINITIONS ! */
/* ----- value of the excitation signal frequency setting ----- */
#define R_ESIG_SET_FREQ_5K        (1U)        /* Excitation signal frequency = 5kHz  */
#define R_ESIG_SET_FREQ_10K       (2U)        /* Excitation signal frequency = 10kHz */
#define R_ESIG_SET_FREQ_20K       (3U)        /* Excitation signal frequency = 20kHz */

/* ----- value of the PWM carrier frequency setting ----- */
#define R_CSIG_SET_FREQ_200K      (1U)        /* Carrier frequency of carrier correction PWM signal : 200kHz */
#define R_CSIG_SET_FREQ_400K      (2U)        /* Carrier frequency of carrier correction PWM signal : 400kHz */

/* ----- value of the PWM duty update cycle number setting ----- */
#define R_CSIG_SET_DCNT_02        (1U)        /* Carrier correction signal PWM duty Update cycle =  2 */
#define R_CSIG_SET_DCNT_04        (2U)        /* Carrier correction signal PWM duty Update cycle =  4 */

/* ----- value of simultaneously start esig and capture ----- */
#define MTU_SYNC_START_NONE       (0U)        /* Not performed simultaneous start */
#define MTU_SYNC_START_DISABLE    (0U)        /* Do not execute simultaneous start */
#define MTU_SYNC_START_ENABLE     (1U)        /* Perform simultaneous start */

/* ----- motor type  ----- */
#define MOTOR_BLDC                (1U)        /* brushless DC Motor */
#define MOTOR_STM                 (2U)        /* Stepper motor */

/* ----- Value to use with Dsig ----- */
#define R_EXT_INACTIVE           (0U)        /* Do not use */
#define R_EXT_ACTIVE             (1U)        /* Use */

#define RSLV_RESULT_OK            (1)
#define RSLV_RESULT_NG            (0)

/* Define the synchronization start channel bit of the MTU */
#define MTU_SYNCSTART_BIT_MTU7    (1 << 0)
#define MTU_SYNCSTART_BIT_MTU6    (1 << 1)
#define MTU_SYNCSTART_BIT_MTU9    (1 << 2)
#define MTU_SYNCSTART_BIT_MTU4    (1 << 3)
#define MTU_SYNCSTART_BIT_MTU3    (1 << 4)
#define MTU_SYNCSTART_BIT_MTU2    (1 << 5)
#define MTU_SYNCSTART_BIT_MTU1    (1 << 6)
#define MTU_SYNCSTART_BIT_MTU0    (1 << 7)

/* Resolver adjust function return value type */
/* API execution state */
#define ADJST_APIINFO_RUN_MODE            (0U)  /* Adjustment is running */
#define ADJST_APIINFO_END_NORMAL          (1U)  /* Adjustment was completed normally  */
#define ADJST_APIINFO_WAITING             (2U)  /* Adjustment is waiting for completion of request processing */
#define ADJST_APIINFO_ERR_GAIN_HI_LMT     (3U)  /* Gain Error:A-Phase amplification upper limit reached */
#define ADJST_APIINFO_ERR_GAIN_LO_LMT     (4U)  /* Gain Error:A-Phase amplification lower limit reached */
#define ADJST_APIINFO_ERR_GAIN_SWAY       (5U)  /* Gain Error:A-Phase amplitude change exceeds acceptance range */
#define ADJST_APIINFO_ERR_PHASE_AHI_BLO   (6U)  /* Phase Error:A-duty upper limit and B-duty lower limit reached */
#define ADJST_APIINFO_ERR_PHASE_ALO_BHI   (7U)  /* Phase Error:A-duty lower limit and B-duty upper limit reached */
#define ADJST_APIINFO_ERR_PHASE_SWAY      (8U)  /* Phase Error:A-Phase and B-Phase change exceeds acceptance range */
#define ADJST_APIINFO_ERR_PHASE_OUT_RANGE (9U)  /* Phase Error:A-Phase and B-Phase change exceeds acceptance range */
#define ADJST_APIINFO_ERR_RDC             (10U) /* Gain & Phase Error:RDC IC malfunction error */
#define ADJST_APIINFO_ERR_CARRIER         (11U) /* Carrier Error:Exceeds upper limit amplitude that can be set to Csig */
#define ADJST_APIINFO_ERR_MOTOR           (12U) /* Motor Error:Motor can not rotate */
#define ADJST_APIINFO_END_USER_STOP       (13U) /* Error:User's stop request */

/* API request processing */
#define ADJST_APIREQ_NONE                 (0U)  /* No request */
#define ADJST_APIREQ_POS_CTRL             (1U)  /* Motor position control request */
#define ADJST_APIREQ_POS_STOP             (2U)  /* Motor position control stop request */
#define ADJST_APIREQ_SPD_CTRL             (3U)  /* Motor speed control request */
#define ADJST_APIREQ_SPD_STOP             (4U)  /* Motor speed control stop request */

#define ADJST_APIREQ_MTR_CTRL             (1U)  /* Motor open-loop control request */
#define ADJST_APIREQ_MTR_STOP             (2U)  /* Motor open-loop control stop request */

/* User request to API */
#define ADJST_USRREQ_RUN                  (0U)  /* Run */
#define ADJST_USRREQ_STOP                 (1U)  /* Stop */
#define ADJST_USRINFO_COMPLETE            (0U)  /* Complete request from API */
#define ADJST_USRINFO_PROCESSING          (1U)  /* Processing request from API */

/* Disconnection Sequence I/F definitions */
#define DDMNT_USRREQ_RUN                  (0U)  /* Run */
#define DDMNT_USRREQ_STOP                 (1U)  /* Stop */
#define DDMNT_WIRE_STATE_NORMAL           (0U)  /* Normal status */
#define DDMNT_WIRE_STATE_ABNORMAL         (1U)  /* Abnormal status */

#define DDMNT_APIINFO_RUN_MODE            (0U)  /* Disconnection detection is running */
#define DDMNT_APIINFO_END_NORMAL          (1U)  /* Not disconnection detection */
#define DDMNT_APIINFO_ERR_DISCONNECT      (2U)  /* Error:Resolver cable is disconnection */
#define DDMNT_APIINFO_ENC_USER_STOP       (3U)  /* Error:User's stop request */

enum
{
    E_OUTPUT_SIGNAL_OFF,
    E_OUTPUT_SIGNAL_ON,
    E_OUTPUT_SIGNAL_START
};

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
/* ----- Output status of signal ----- */
/* Peripheral initialization parameter structure */
typedef struct st_init_reg_param
{
    unsigned char u1_sel_reg_type;            /* Types of peripheral registers  */
    unsigned char u1_sel_reg_func;            /* Select function                */
    unsigned char u1_sel_int_flg;             /* Interrupt used / not used flag */
    unsigned char u1_sel_int_priorty;         /* Interrupt priority             */
    unsigned char u1_capture_trig;            /* Select input capture trigger   */
    unsigned char u1_use_port1;               /* ID1 of used port               */
    unsigned char u1_use_port2;               /* ID2 of used port               */
    unsigned char u1_use_port3;               /* ID3 of used port (only for RDC_COM) */
    unsigned char u1_use_port4;               /* ID4 of used port (only for RDC_COM) */
} ST_INIT_REG_PARAM;

/* RDC driver setting information structure */
typedef struct st_rdc_drv_setting_info
{
    float          f_esig_freq;               /* Excitation frequency               */
    unsigned short u2_capture_cnt_max;        /* Maximum value of capture cycle counter */
    unsigned char  u1_motor_kind;             /* Motor type */
} ST_RDC_DRV_SETTING_INFO;

/* System information setting parameter structure */
typedef struct st_system_param
{
    unsigned char u1_mcu_type;                /* MCU type */
    unsigned char u1_esig_freq;               /* ESig frequency         */
    unsigned char u1_csig_freq;               /* CSig frequency         */
    unsigned char u1_csig_upd_duty_cycle;     /* CSig duty update count */
    unsigned char u1_mtu3_sync_start;         /* Flag for simultaneously starting esig and capture timer */
    unsigned char u1_motor_kind;              /* motor type */
    unsigned char u1_extension_use;           /* Whether to use */
} ST_SYSTEM_PARAM;

/* For Adjustment Function */
/* Function pointer and driver information storage structure */
typedef struct {
    unsigned short (*ad_data)(void);          /* AD register data */
    void (*ad_ctrl)(unsigned char);           /* AD conversion control function pointer */
    void (*ad_peri_adjst)(void);              /* AD peripheral change function pointer for adjust setting */
    void (*ad_peri_user)(void);               /* AD peripheral change function pointer for user setting */
    unsigned short resolver_pole_num;         /* Resolver pole pair number */
    float *mtr_speed;                         /* Motor speed(rad/s) value pointer */
    unsigned short req_speed;                 /* Command speed (rpm) */
} st_ptr_func_arg_t;


/* R_RSLV_ADJST_Carrier function return value structure */
typedef struct {
    unsigned char  adjst_state;               /* Run state */
    unsigned char  req_mtr_ctrl;              /* Motor control request */
    unsigned short mtr_ctrl_data;             /* Data for motor control */
    unsigned char  res_ccgsl;                 /* Result RDC register CCGSL */
    unsigned short res_csig_shift;            /* Result Csig shift */
    unsigned short res_csig_amp;              /* Result Csig amplitude */
} st_adjst_carrier_return_t;

/* R_RSLV_ADJST_Carrier function argument structure */
typedef struct {
    unsigned char call_state;                 /* User's inputs information, API run or stop */
    unsigned char req_state;                  /* User's inputs information, processing state of API request */
} st_adjst_carrier_arg_t;

/* R_RSLV_ADJST_GainPhase function return value structure */
typedef struct
{
    unsigned char  u1_adjst_state;            /* Run state of API */
    unsigned char  u1_res_dlcgsl;             /* Result RDC register DLCGSL */
    unsigned short u2_res_a_duty;             /* Result PWM signal duty of A phase */
    unsigned short u2_res_b_duty;             /* Result PWM signal duty of B phase */
} st_adjst_gainphase_return_t;

/* R_RSLV_DiscDetection_Sequence function argument structure */
typedef struct {
    unsigned char call_state;                 /* User's inputs information, API run or stop */
    unsigned char wire_state;                 /* User's inputs information, wiring state of API request */
} st_rdc_ddmnt_arg_t;

typedef unsigned char (*UNSIGNED_CHAR_POINTER)(void);

/***********************************************************************************************************************
Exported global variables
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/
unsigned char R_RSLV_CreatePeripheral(ST_INIT_REG_PARAM  *rdc_init_param);
unsigned char R_RSLV_SetSystemInfo(ST_SYSTEM_PARAM *rdc_sys_param);
unsigned char R_RSLV_GetRdcDrvSettingInfo(ST_RDC_DRV_SETTING_INFO *rdc_setting_info);
unsigned char R_RSLV_CSig_Start(unsigned short phase_diff, unsigned short amp_level );
unsigned char R_RSLV_CSig_Stop(void);
unsigned char R_RSLV_GetCSigStatus( unsigned char *status );
unsigned char R_RSLV_GetAngleCountFirstEdge(unsigned short *angle_cnt);
unsigned char R_RSLV_GetAngleDifferenceFirstEdge(signed short *angle_diff_cnt);
unsigned char R_RSLV_GetAngleCountSecondEdge(unsigned short *angle_cnt);
unsigned char R_RSLV_GetAngleDifferenceSecondEdge(signed short *angle_diff_cnt);
unsigned char R_RSLV_GetCaptureEdge(unsigned char *cap_edge);
unsigned char R_RSLV_Capture_Start(void);
unsigned char R_RSLV_INT_GetCaptureCount(void);
unsigned char R_RSLV_SetCaptureTiming(unsigned short tcnt);
unsigned char R_RSLV_INT_CSig_SyncStart(void);
unsigned char R_RSLV_ESig_Start(void);
unsigned char R_RSLV_ESig_Stop(void);
unsigned char R_RSLV_ESigStartTiming(unsigned short tcnt);
unsigned char R_RSLV_INT_CSig_UpdatePwmDuty(void);
unsigned char R_RSLV_INT_ESigCounter( void );
unsigned char R_RSLV_Phase_AdjStart(void);
unsigned char R_RSLV_Phase_AdjStop(void);
unsigned char R_RSLV_Phase_AdjUpdateBuff(unsigned short duty,unsigned char ch);
unsigned char R_RSLV_Phase_AdjUpdate(void);
unsigned char R_RSLV_Phase_AdjReadBuff(unsigned short *duty,unsigned char ch);
unsigned char R_RSLV_Rdc_VariableInit(unsigned char *u1_init_data);
unsigned char R_RSLV_Rdc_Init_Sequence(unsigned short *init_status);
unsigned char R_RSLV_Rdc_Communication(void);
unsigned char R_RSLV_Rdc_RegWrite(unsigned char wt_data, unsigned char address,unsigned char *write_status);
unsigned char R_RSLV_Rdc_RegRead(unsigned char address);
unsigned char R_RSLV_Rdc_ChkIfRun(void);
unsigned char R_RSLV_Rdc_GetRegisterVal(unsigned char *rd_data, unsigned char address);
unsigned char R_RSLV_Rdc_SetRegisterVal(unsigned char wt_data, unsigned char address);
unsigned char R_RSLV_RdcCom_GetErrorInfo(unsigned char *err_info);
unsigned char R_RSLV_INT_RdcCom_Recv(void);
unsigned char R_RSLV_INT_RdcCom_Trans(void);
unsigned char R_RSLV_INT_RdcCom_Error(void);
unsigned char R_RSLV_INT_RdcCom_Idle(void);
unsigned char R_RSLV_Rdc_AlarmCancelStart(void);
unsigned char R_RSLV_Rdc_AlarmCancel(void);
unsigned char R_RSLV_MTU_SyncStart(unsigned char start_ch);
unsigned char R_RSLV_SetFunctionPointer(UNSIGNED_CHAR_POINTER func, unsigned char func_id);
unsigned char R_RSLV_GetDriverVer(unsigned long *drv_ver);

/* Adjustment API */
st_adjst_gainphase_return_t R_RSLV_ADJST_GainPhase( unsigned char u1_call_state );
st_adjst_carrier_return_t R_RSLV_ADJST_Carrier( st_adjst_carrier_arg_t arg_value );
void R_RSLV_ADJST_SetPtrFunc( st_ptr_func_arg_t *ptr_arg );
unsigned char R_RSLV_ADJST_Ad_Processing( void );

/* Disconnection Detection API */
unsigned char R_RSLV_DiscDetection_Seq( st_rdc_ddmnt_arg_t arg_value );

#endif /* R_RSLV_API_H */
