/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_rslv_api.h
* Version      :
* Device(s)    : R5F524T***** & R5F523T***** & R5F566T***** & R5F572M*****
* Tool-Chain   : CCRX
* Description  : Header of interface with resolver functions
* Creation Date: 2019/XX/XX
***********************************************************************************************************************/
#ifndef R_RSLV_API_H
#define R_RSLV_API_H

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions (compile SW)
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* Status list definition */
#define RSLV_MD_STATUSBASE        (0x00U)
#define RSLV_MD_OK                (RSLV_MD_STATUSBASE + 0x00U) /* register setting OK */
#define RSLV_MD_SPT               (RSLV_MD_STATUSBASE + 0x01U) /* IIC stop */
#define RSLV_MD_NACK              (RSLV_MD_STATUSBASE + 0x02U) /* IIC no ACK */
#define RSLV_MD_BUSY1             (RSLV_MD_STATUSBASE + 0x03U) /* busy 1 */
#define RSLV_MD_BUSY2             (RSLV_MD_STATUSBASE + 0x04U) /* busy 2 */
/* Error list definition */
#define RSLV_MD_ERRORBASE         (0x80U)
#define RSLV_MD_ERROR             (RSLV_MD_ERRORBASE + 0x00U)  /* error */
#define RSLV_MD_ARGERROR          (RSLV_MD_ERRORBASE + 0x01U)  /* error argument input error */
#define RSLV_MD_ERROR1            (RSLV_MD_ERRORBASE + 0x02U)  /* error 1 */
#define RSLV_MD_ERROR2            (RSLV_MD_ERRORBASE + 0x03U)  /* error 2 */
#define RSLV_MD_ERROR3            (RSLV_MD_ERRORBASE + 0x04U)  /* error 3 */
#define RSLV_MD_ERROR4            (RSLV_MD_ERRORBASE + 0x05U)  /* error 4 */
#define RSLV_MD_ERROR5            (RSLV_MD_ERRORBASE + 0x06U)  /* error 5 */

/* Do not edit the macro definition given bellow! */
#define R_ESIG_FREQUENCY_5K       (5000.0f)   /* Setting ESig frequency as 5kHz            */
#define R_ESIG_FREQUENCY_10K      (10000.0f)  /* Setting ESig frequency as 10kHz           */
#define R_ESIG_FREQUENCY_20K      (20000.0f)  /* Setting ESig frequency as 20kHz           */

/* Definition of function type */
#define F_ESIG1                   (0)         /* Excitation signal only                               */
#define F_ESIG2_1                 (1)         /* Excitation signal when outputting                    */
                                              /* signals with different timers                        */
#define F_ESIG2_2                 (2)         /* For excitation signal synthesis                      */
#define F_ESIG12                  (3)         /* When outputting excitation signal and                */
                                              /* synthesis signal by 1 register                       */
#define F_CSIG                    (4)         /* Carrier correction signal                            */
#define F_PHASE_A                 (5)         /* Phase adjustment signal-A                            */
#define F_PHASE_B                 (6)         /* Phase adjustment signal-B                            */
#define F_PHASE_AB                (7)         /* Phase adjustment signal-A/B                          */
#define F_CAPTURE                 (8)         /* Phase signal input(Input Capture)                    */
#define F_CSIG_UPD_TIMER          (9)         /* Carrier correction duty update timer                 */
#define F_RDC_COM                 (10)        /* RDC communication                                    */
#define F_RDC_CLK                 (11)        /* RDC clock                                            */
#define F_RESERVE1                (12)        /* RDC reset (Setting prohibited)                       */
#define F_FUNC_MAX                (13)        /* Function ID Max                                      */

/* RDC register ID definition */
#define RDC_ADDR_PS1_02           (0x02)
#define RDC_ADDR_PS2_04           (0x04)
#define RDC_ADDR_SWRST_06         (0x06)
#define RDC_ADDR_PS3_0A           (0x0A)
#define RDC_ADDR_DDMNT_0E         (0x0E)
#define RDC_ADDR_ALMST_12         (0x12)
#define RDC_ADDR_ALMOUT_16        (0x16)
#define RDC_ADDR_MNTSL_20         (0x20)
#define RDC_ADDR_MDCACSEL_28      (0x28)
#define RDC_ADDR_GCGSL_2E         (0x2E)
#define RDC_ADDR_DLCGSL_30        (0x30)
#define RDC_ADDR_CCGSL_36         (0x36)
#define RDC_ADDR_CSACTL_42        (0x42)
#define RDC_ADDR_FOPER_48         (0x48)
#define RDC_ADDR_INITERR_54       (0x54)

#define PHASE_CH_A                (0)         /* Phase Channel A       */
#define PHASE_CH_B                (1)         /* Phase Channel B       */

/* DO NOT EDIT THE FOLLOWING MACRO DEFINITIONS ! */
/* ----- value of the excitation signal frequency setting ----- */
#define R_ESIG_SET_FREQ_5K        (1U)        /* Excitation signal frequency = 5kHz  */
#define R_ESIG_SET_FREQ_10K       (2U)        /* Excitation signal frequency = 10kHz */
#define R_ESIG_SET_FREQ_20K       (3U)        /* Excitation signal frequency = 20kHz */

/* ----- value of the PWM carrier frequency setting ----- */
#define R_CSIG_SET_FREQ_200K      (1U)        /* Carrier frequency of carrier correction PWM signal : 200kHz */
#define R_CSIG_SET_FREQ_400K      (2U)        /* Carrier frequency of carrier correction PWM signal : 400kHz */

/* ----- value of the PWM duty update cycle number setting ----- */
#define R_CSIG_SET_DCNT_02        (1U)        /* Carrier correction signal PWM duty Update cycle =  2 */
#define R_CSIG_SET_DCNT_04        (2U)        /* Carrier correction signal PWM duty Update cycle =  4 */

/* ----- value of simultaneously start esig and capture ----- */
#define SYNCMD_ESIG_API           (0U)        /* simultaneous start of CAPTURE timer by R_RSLV_ESig_Start */
#define SYNCMD_OTHER_API          (1U)        /* simultaneous start of CAPTURE timer by R_RSLV_Capture_Start or R_RSLV_MTU_SyncStart*/


/* ----- motor type  ----- */
#define MOTOR_BLDC                (1U)        /* brushless DC Motor */
#define MOTOR_STM                 (2U)        /* Stepper motor */

/* ----- MNTOUT Output type ----- */
#define RSLV_MNTOUT_TYPE_AC       (1U)
#define RSLV_MNTOUT_TYPE_DC       (2U)

#define RSLV_NOTSET_PERI_CLK_SRC  (0.0f)

#define RSLV_RESULT_OK            (1)
#define RSLV_RESULT_NG            (0)

/* Define the synchronization start channel bit of the MTU */
#define MTU_SYNCSTART_BIT_MTU7    (1 << 0)
#define MTU_SYNCSTART_BIT_MTU6    (1 << 1)
#define MTU_SYNCSTART_BIT_MTU9    (1 << 2)
#define MTU_SYNCSTART_BIT_MTU4    (1 << 3)
#define MTU_SYNCSTART_BIT_MTU3    (1 << 4)
#define MTU_SYNCSTART_BIT_MTU2    (1 << 5)
#define MTU_SYNCSTART_BIT_MTU1    (1 << 6)
#define MTU_SYNCSTART_BIT_MTU0    (1 << 7)

/* Resolver adjust function return value type */
/* API execution state */
#define ADJST_APIINFO_RUN_MODE            (0U)  /* Adjustment is running */
#define ADJST_APIINFO_END_NORMAL          (1U)  /* Adjustment was completed normally  */
#define ADJST_APIINFO_WAITING             (2U)  /* Adjustment is waiting for completion of request processing */
#define ADJST_APIINFO_ERR_GAIN_HI_LMT     (3U)  /* Gain Error:A-Phase amplification upper limit reached */
#define ADJST_APIINFO_ERR_GAIN_LO_LMT     (4U)  /* Gain Error:A-Phase amplification lower limit reached */
#define ADJST_APIINFO_ERR_GAIN_SWAY       (5U)  /* Gain Error:A-Phase amplitude change exceeds acceptance range */
#define ADJST_APIINFO_ERR_PHASE_AHI_BLO   (6U)  /* Phase Error:A-duty upper limit and B-duty lower limit reached */
#define ADJST_APIINFO_ERR_PHASE_ALO_BHI   (7U)  /* Phase Error:A-duty lower limit and B-duty upper limit reached */
#define ADJST_APIINFO_ERR_PHASE_SWAY      (8U)  /* Phase Error:A-Phase and B-Phase change exceeds acceptance range */
#define ADJST_APIINFO_ERR_PHASE_OUT_RANGE (9U)  /* Phase Error:A-Phase and B-Phase change exceeds acceptance range */
#define ADJST_APIINFO_ERR_RDC             (10U) /* Gain & Phase Error:RDC IC malfunction error */
#define ADJST_APIINFO_ERR_CARRIER         (11U) /* Carrier Error:Exceeds upper limit amplitude that can be set to Csig */
#define ADJST_APIINFO_ERR_MOTOR           (12U) /* Motor Error:Motor can not rotate */
#define ADJST_APIINFO_END_USER_STOP       (13U) /* Error:User's stop request */

/* API request processing */
#define ADJST_APIREQ_NONE                 (0U)  /* No request */
#define ADJST_APIREQ_POS_CTRL             (1U)  /* Motor position control request */
#define ADJST_APIREQ_POS_STOP             (2U)  /* Motor position control stop request */
#define ADJST_APIREQ_SPD_CTRL             (3U)  /* Motor speed control request */
#define ADJST_APIREQ_SPD_STOP             (4U)  /* Motor speed control stop request */

/* User request to API */
#define ADJST_USRREQ_RUN                  (0U)  /* Run */
#define ADJST_USRREQ_STOP                 (1U)  /* Stop */
#define ADJST_USRINFO_COMPLETE            (0U)  /* Complete request from API */
#define ADJST_USRINFO_PROCESSING          (1U)  /* Processing request from API */

/* Disconnection Sequence I/F definitions */
#define DDMNT_USRREQ_RUN                  (0U)  /* Run */
#define DDMNT_USRREQ_STOP                 (1U)  /* Stop */
#define DDMNT_WIRE_STATE_NORMAL           (0U)  /* Normal status */
#define DDMNT_WIRE_STATE_ABNORMAL         (1U)  /* Abnormal status */

#define DDMNT_APIINFO_RUN_MODE            (0U)  /* Disconnection detection is running */
#define DDMNT_APIINFO_END_NORMAL          (1U)  /* Not disconnection detection */
#define DDMNT_APIINFO_ERR_DISCONNECT      (2U)  /* Error:Resolver cable is disconnection */
#define DDMNT_APIINFO_ENC_USER_STOP       (3U)  /* Error:User's stop request */

enum
{
    E_OUTPUT_SIGNAL_OFF,
    E_OUTPUT_SIGNAL_ON,
    E_OUTPUT_SIGNAL_START
};

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
/* ----- Output status of signal ----- */

/* function table definition for timer */
typedef struct st_function_table
{
    void (*Start)(void);                                            /* Timer start function */
    void (*Stop)(void);                                             /* Timer stop function */
    void (*GetTcnt)(unsigned short *tcnt);                          /* Count value acquisition function */
    void (*SetTcnt)(unsigned short tcnt) ;                          /* Count value setting function */
    void (*GetDuty)(unsigned short *duty);                          /* Duty value acquisition function */
    void (*SetDuty)(unsigned short duty);                           /* Duty value setting function */
    void (*SetDuty_2val)(unsigned short ch,unsigned short duty);    /* Duty value setting function(A/B phase output with 1 timer) */
    void (*GetCaptureValue)(unsigned short *capture_val);           /* Count value acquisition function */
    void (*GetPortLevel)(unsigned char *port_level);                /* Port level acquisition function */
    unsigned short (*ComSendReceive)                                /* RDC IC SPI transmission/reception start function */
              (unsigned short *tx_buf, unsigned short tx_num, unsigned short *rx_buf);
} ST_FUNCTION_TABLE;

/* RDC driver setting information structure */
typedef struct st_rdc_drv_setting_info
{
    float          f_esig_freq;               /* Excitation frequency               */
    unsigned short u2_capture_cnt_max;        /* Maximum value of capture cycle counter */
    unsigned char  u1_motor_kind;             /* Motor type */
} ST_RDC_DRV_SETTING_INFO;

/* System information setting parameter structure */
typedef struct st_system_param
{
    unsigned char u1_esig_freq;               /* ESig frequency */
    unsigned char u1_csig_freq;               /* CSig frequency */
    unsigned char u1_csig_upd_duty_cycle;     /* CSig duty update count */
    unsigned char u1_sync_start;              /* Flag for simultaneously starting esig and capture timer */
    unsigned char u1_motor_kind;              /* motor type */
    unsigned char u1_mntout_type;             /* RDC IC MNTOUT port output method */
} ST_SYSTEM_PARAM;

/* Timer count clock source information setting parameter structure */
typedef struct st_peripheral_param
{
    float f_esig1_peri_clk_src;                    /* F_ESIG1 or F_ESIG12 allocation timer Counter clock source(MHz) */
    float f_csig_peri_clk_src;                     /* F_CSIG allocation timer counter clock source(MHz) */
    float f_capture_peri_clk_src;                  /* F_CAPTUER allocation timer counter clock source(MHz) */
    float f_csig_upd_timer_peri_clk_src;           /* F_CSIG_UPD_TIMER allocation timer counter clock source(MHz) */
    float f_phase1_peri_clk_src;                   /* F_PHASE_A allocation timer count clock source(MHz) */
    float f_phase2_peri_clk_src;                   /* F_PHASE_B allocation timer count clock source(MHz) */
} ST_USER_PERI_PARAM;

/* For Adjustment Function */
/* Function pointer and driver information storage structure */
typedef struct {
    unsigned short (*ad_data)(void);          /* AD register data */
    void (*ad_ctrl)(unsigned char);           /* AD conversion control function pointer */
    void (*ad_peri_adjst)(void);              /* AD peripheral change function pointer for adjust setting */
    void (*ad_peri_user)(void);               /* AD peripheral change function pointer for user setting */
    unsigned short resolver_pole_num;         /* Resolver pole pair number */
    float *mtr_speed;                         /* Motor speed(rad/s) value pointer */
    unsigned short req_speed;                 /* Command speed (rpm) */
} st_ptr_func_arg_t;

/* R_RSLV_ADJST_Carrier function return value structure */
typedef struct {
    unsigned char  adjst_state;               /* Run state */
    unsigned char  req_mtr_ctrl;              /* Motor control request */
    unsigned short mtr_ctrl_data;             /* Data for motor control */
    unsigned char  res_ccgsl;                 /* Result RDC register CCGSL */
    unsigned short res_csig_shift;            /* Result Csig shift */
    unsigned short res_csig_amp;              /* Result Csig amplitude */
} st_adjst_carrier_return_t;

/* R_RSLV_ADJST_Carrier function argument structure */
typedef struct {
    unsigned char call_state;                 /* User's inputs information, API run or stop */
    unsigned char req_state;                  /* User's inputs information, processing state of API request */
} st_adjst_carrier_arg_t;

/* R_RSLV_ADJST_GainPhase function return value structure */
typedef struct
{
    unsigned char  u1_adjst_state;            /* Run state of API */
    unsigned char  u1_res_dlcgsl;             /* Result RDC register DLCGSL */
    unsigned short u2_res_a_duty;             /* Result PWM signal duty of A phase */
    unsigned short u2_res_b_duty;             /* Result PWM signal duty of B phase */
} st_adjst_gainphase_return_t;

/* R_RSLV_DiscDetection_Sequence function argument structure */
typedef struct {
    unsigned char call_state;                 /* User's inputs information, API run or stop */
    unsigned char wire_state;                 /* User's inputs information, wiring state of API request */
} st_rdc_ddmnt_arg_t;

/***********************************************************************************************************************
Exported global variables
***********************************************************************************************************************/
extern ST_FUNCTION_TABLE g_st_user_func_table;

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/
unsigned char R_RSLV_SetSystemInfo(ST_SYSTEM_PARAM *rdc_sys_param,ST_USER_PERI_PARAM *user_peri_param);
unsigned char R_RSLV_SetFuncTable(unsigned char set_func,ST_FUNCTION_TABLE user_func_table);
unsigned char R_RSLV_GetRdcDrvSettingInfo(ST_RDC_DRV_SETTING_INFO *rdc_setting_info);
unsigned char R_RSLV_CSig_Start(unsigned short phase_diff, unsigned short amp_level );
unsigned char R_RSLV_CSig_Stop(void);
unsigned char R_RSLV_GetAngleCountFirstEdge(unsigned short *angle_cnt);
unsigned char R_RSLV_GetAngleDifferenceFirstEdge(signed short *angle_diff_cnt);
unsigned char R_RSLV_GetAngleCountSecondEdge(unsigned short *angle_cnt);
unsigned char R_RSLV_GetAngleDifferenceSecondEdge(signed short *angle_diff_cnt);
unsigned char R_RSLV_GetCaptureEdge(unsigned char *cap_edge);
unsigned char R_RSLV_Capture_Start(void);
unsigned char R_RSLV_INT_GetCaptureCount(void);
unsigned char R_RSLV_INT_CSig_SyncStart(void);
unsigned char R_RSLV_ESig_Start(void);
unsigned char R_RSLV_ESig_Stop(void);
unsigned char R_RSLV_ESigCapStartTiming(unsigned short esig_start_tcnt, unsigned short cap_start_tcnt);
unsigned char R_RSLV_INT_CSig_UpdatePwmDuty(void);
unsigned char R_RSLV_INT_ESigCounter( void );
unsigned char R_RSLV_Phase_AdjStart(void);
unsigned char R_RSLV_Phase_AdjStop(void);
unsigned char R_RSLV_Phase_AdjUpdateBuff(unsigned short duty,unsigned char ch);
unsigned char R_RSLV_Phase_AdjUpdate(void);
unsigned char R_RSLV_Phase_AdjReadBuff(unsigned short *duty,unsigned char ch);
unsigned char R_RSLV_Rdc_VariableInit(unsigned char *u1_init_data);
unsigned char R_RSLV_Rdc_Init_Sequence(unsigned short *init_status);
unsigned char R_RSLV_Rdc_Communication(void);
unsigned char R_RSLV_Rdc_RegWrite(unsigned char *write_status);
unsigned char R_RSLV_Rdc_RegRead(unsigned char address);
unsigned char R_RSLV_Rdc_ChkIfRun(void);
unsigned char R_RSLV_Rdc_GetRegisterVal(unsigned char *rd_data, unsigned char address);
unsigned char R_RSLV_Rdc_SetRegisterVal(unsigned char wt_data, unsigned char address);
unsigned char R_RSLV_RdcCom_GetErrorInfo(unsigned char *err_info);
unsigned char R_RSLV_Rdc_AlarmCancelStart(void);
unsigned char R_RSLV_Rdc_AlarmCancel(void);
unsigned char R_RSLV_MTU_SyncStart(unsigned char start_ch);
unsigned char R_RSLV_GetDriverVer(unsigned long *drv_ver);
unsigned char R_RSLV_Rdc_CallComEndCb(void);
unsigned char R_RSLV_Rdc_CallErrorCb(void);

/* Adjustment API */
st_adjst_gainphase_return_t R_RSLV_ADJST_GainPhase( unsigned char u1_call_state );
st_adjst_carrier_return_t R_RSLV_ADJST_Carrier( st_adjst_carrier_arg_t arg_value );
unsigned char R_RSLV_ADJST_SetPtrFunc( st_ptr_func_arg_t *ptr_arg );
unsigned char R_RSLV_ADJST_Ad_Processing( void );

/* Disconnection Detection API */
unsigned char R_RSLV_DiscDetection_Seq( st_rdc_ddmnt_arg_t arg_value );

#endif /* R_RSLV_API_H */
