RX23T�Ł@�֐��e�[�u���ݒ�

///// �\����
ST_FUNCTION_TABLE g_st_user_func_table;

///////////////////////////////////
///// �㎥�M��
///////////////////////////////////
// MTU0-ESIG1
    g_st_user_func_table.Start   = &R_Config_MTU0_Esig1_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU0_Esig1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU0_Esig1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU0_Esig1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG1, g_st_user_func_table);

// MTU0-ESIG2_1(non asign)
// MTU0-ESIG2_2(non asign)

// MTU0-ESIG12
    g_st_user_func_table.Start   = &R_Config_MTU0_Esig12_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU0_Esig12_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU0_Esig12_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU0_Esig12_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG12, g_st_user_func_table);


///////////////////////////////////
///// �p�x�덷�␳�M��
///////////////////////////////////
// MTU0-CSIG(non asign)

// MTU1-CSIG
    g_st_user_func_table.Start   = &R_Config_MTU1_Csig_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU1_Csig_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU1_Csig_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU1_Csig_GetTcnt;
    g_st_user_func_table.SetDuty = &R_Config_MTU1_Csig_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_MTU1_Csig_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG, g_st_user_func_table);

// MTU2-CSIG
    g_st_user_func_table.Start   = &R_Config_MTU2_Csig_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU2_Csig_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU2_Csig_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU2_Csig_GetTcnt;
    g_st_user_func_table.SetDuty = &R_Config_MTU2_Csig_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_MTU2_Csig_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG, g_st_user_func_table);

///////////////////////////////////
///// �ʑ������M��A
///////////////////////////////////
// TMR0-PHASE_A
    g_st_user_func_table.Start   = &R_Config_TMR0_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR0_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR0_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// TMR1-PHASE_A
    g_st_user_func_table.Start   = &R_Config_TMR1_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR1_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR1_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// TMR2-PHASE_A
    g_st_user_func_table.Start   = &R_Config_TMR2_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR2_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR2_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// TMR3-PHASE_A
    g_st_user_func_table.Start   = &R_Config_TMR3_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR3_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR3_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

///////////////////////////////////
///// �ʑ������M��B
///////////////////////////////////
// TMR0-PHASE_B
    g_st_user_func_table.Start   = &R_Config_TMR0_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR0_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR0_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// TMR1-PHASE_B
    g_st_user_func_table.Start   = &R_Config_TMR1_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR1_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR1_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// TMR2-PHASE_B
    g_st_user_func_table.Start   = &R_Config_TMR2_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR2_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR2_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// TMR3-PHASE_B
    g_st_user_func_table.Start   = &R_Config_TMR3_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR3_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR3_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

///////////////////////////////////
///// �ʑ������M��AB(non asign)
///////////////////////////////////

///////////////////////////////////
///// �p�x�M������
///////////////////////////////////
// MTU0-CAP(non asign)

// MTU1-CAP
    g_st_user_func_table.Start   = &R_Config_MTU1_Cap_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU1_Cap_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU1_Cap_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU1_Cap_GetTcnt;
    g_st_user_func_table.GetCaptureValue = &R_Config_MTU1_Cap_GetCapVal;
    g_st_user_func_table.GetPortLevel = &R_Config_MTU1_Cap_GetPortLevel;
    R_RSLV_SetFuncTable(F_CAPTURE, g_st_user_func_table);

// MTU2-CAP
    g_st_user_func_table.Start   = &R_Config_MTU2_Cap_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU2_Cap_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU2_Cap_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU2_Cap_GetTcnt;
    g_st_user_func_table.GetCaptureValue = &R_Config_MTU2_Cap_GetCapVal;
    g_st_user_func_table.GetPortLevel = &R_Config_MTU2_Cap_GetPortLevel;
    R_RSLV_SetFuncTable(F_CAPTURE, g_st_user_func_table);

///////////////////////////////////
///// �p�x�덷�␳�M��Duty�X�V
///////////////////////////////////
// CMT0-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_CMT0_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_CMT0_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_CMT0_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_CMT0_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// CMT1-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_CMT1_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_CMT1_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_CMT1_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_CMT1_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// CMT2-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_CMT2_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_CMT2_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_CMT2_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_CMT2_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// CMT3-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_CMT3_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_CMT3_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_CMT3_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_CMT3_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

///////////////////////////////////
///// RDC-IC�ʐM
///////////////////////////////////
// RSPI0-RDC_COM
    g_st_user_func_table.ComSendReceive = & R_Config_RSPI0_RdcCom_Send_Receive;
    R_RSLV_SetFuncTable(F_RDC_COM, g_st_user_func_table);

// SCI1-RDC_COM
    g_st_user_func_table.ComSendReceive = & R_Config_SCI1_RdcCom_Send_Receive;
    R_RSLV_SetFuncTable(F_RDC_COM, g_st_user_func_table);

// SCI5-RDC_COM
    g_st_user_func_table.ComSendReceive = & R_Config_SCI5_RdcCom_Send_Receive;
    R_RSLV_SetFuncTable(F_RDC_COM, g_st_user_func_table);

///////////////////////////////////
///// RDC�N���b�N
///////////////////////////////////
// TMR0-RDC_CLK
    /* Set function table for RDC IC Clock */
    g_st_user_func_table.Start   = &R_Config_TMR0_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR0_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// TMR1-RDC_CLK
    /* Set function table for RDC IC Clock */
    g_st_user_func_table.Start   = &R_Config_TMR1_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR1_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// TMR2-RDC_CLK
    /* Set function table for RDC IC Clock */
    g_st_user_func_table.Start   = &R_Config_TMR2_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR2_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// TMR3-RDC_CLK
    /* Set function table for RDC IC Clock */
    g_st_user_func_table.Start   = &R_Config_TMR3_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR3_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

///////////////////////////////////


