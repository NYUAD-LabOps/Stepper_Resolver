/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : Pin.c
* Version      : 1.0.2
* Device(s)    : R5F523T5AxFM
* Description  : This file implements SMC pin code generation.
* Creation Date: 2021-02-10
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Pins_Create
* Description  : This function initializes Smart Configurator pins
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Pins_Create(void)
{
    R_BSP_RegisterProtectDisable(BSP_REG_PROTECT_MPC);

    /* Set MISOA pin */
    MPC.P94PFS.BYTE = 0x0DU;
    PORT9.PMR.BYTE |= 0x10U;

    /* Set MOSIA pin */
    MPC.PB0PFS.BYTE = 0x0DU;
    PORTB.PMR.BYTE |= 0x01U;

    /* Set MTIOC0A pin */
    MPC.PB3PFS.BYTE = 0x01U;
    PORTB.PMR.BYTE |= 0x08U;

    /* Set MTIOC0B pin */
    MPC.PB2PFS.BYTE = 0x01U;
    PORTB.PMR.BYTE |= 0x04U;

    /* Set MTIOC1A pin */
    MPC.PA5PFS.BYTE = 0x01U;
    PORTA.PMR.BYTE |= 0x20U;

    /* Set MTIOC1B pin */
    MPC.PA4PFS.BYTE = 0x01U;
    PORTA.PMR.BYTE |= 0x10U;

    /* Set MTIOC2A pin */
    MPC.PA3PFS.BYTE = 0x01U;
    PORTA.PMR.BYTE |= 0x08U;

    /* Set MTIOC2B pin */
    MPC.PA2PFS.BYTE = 0x01U;
    PORTA.PMR.BYTE |= 0x04U;

    /* Set RSPCKA pin */
    MPC.P93PFS.BYTE = 0x0DU;
    PORT9.PMR.BYTE |= 0x08U;

    /* Set SCK1 pin */
    MPC.PD4PFS.BYTE = 0x0AU;
    PORTD.PMR.BYTE |= 0x10U;

    /* Set SCK5 pin */
    MPC.PB7PFS.BYTE = 0x0AU;
    PORTB.PMR.BYTE |= 0x80U;

    /* Set SMISO1 pin */
    MPC.PD5PFS.BYTE = 0x0AU;
    PORTD.PMR.BYTE |= 0x20U;

    /* Set SMISO5 pin */
    MPC.PB6PFS.BYTE = 0x0AU;
    PORTB.PMR.BYTE |= 0x40U;

    /* Set SMOSI1 pin */
    MPC.PD3PFS.BYTE = 0x0AU;
    PORTD.PMR.BYTE |= 0x08U;

    /* Set SMOSI5 pin */
    MPC.PB5PFS.BYTE = 0x0AU;
    PORTB.PMR.BYTE |= 0x20U;

    /* Set SSLA0 pin */
    MPC.P30PFS.BYTE = 0x0DU;
    PORT3.PMR.BYTE |= 0x01U;

    /* Set TMO0 pin */
    MPC.PD3PFS.BYTE = 0x05U;
    PORTD.PMR.BYTE |= 0x08U;

    /* Set TMO1 pin */
    MPC.PD6PFS.BYTE = 0x05U;
    PORTD.PMR.BYTE |= 0x40U;

    /* Set TMO2 pin */
    MPC.P23PFS.BYTE = 0x05U;
    PORT2.PMR.BYTE |= 0x08U;

    /* Set TMO3 pin */
    MPC.P11PFS.BYTE = 0x05U;
    PORT1.PMR.BYTE |= 0x02U;

    R_BSP_RegisterProtectEnable(BSP_REG_PROTECT_MPC);
}

