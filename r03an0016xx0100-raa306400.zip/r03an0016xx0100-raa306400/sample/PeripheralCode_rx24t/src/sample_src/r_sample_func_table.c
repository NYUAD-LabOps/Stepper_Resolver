RX24T�Ł@�֐��e�[�u���ݒ�

///// �\����
ST_FUNCTION_TABLE g_st_user_func_table;

///////////////////////////////////
///// �㎥�M��
///////////////////////////////////
// MTU0-ESIG1
    g_st_user_func_table.Start   = &R_Config_MTU0_Esig1_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU0_Esig1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU0_Esig1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU0_Esig1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG1, g_st_user_func_table);

// MTU0-ESIG2_1,ESIG2_2
    g_st_user_func_table.Start   = &R_Config_MTU0_Esig2_1_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU0_Esig2_1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU0_Esig2_1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU0_Esig2_1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_1, g_st_user_func_table);

    g_st_user_func_table.Start   = &R_Config_MTU0_Esig2_2_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU0_Esig2_2_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU0_Esig2_2_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU0_Esig2_2_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_2, g_st_user_func_table);

// MTU0-ESIG12
    g_st_user_func_table.Start   = &R_Config_MTU0_Esig12_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU0_Esig12_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU0_Esig12_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU0_Esig12_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG12, g_st_user_func_table);

//----------------------------------------------------------------
// MTU1-ESIG1
    g_st_user_func_table.Start   = &R_Config_MTU1_Esig1_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU1_Esig1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU1_Esig1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU1_Esig1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG1, g_st_user_func_table);

// MTU1-ESIG2_1,ESIG2_2
    g_st_user_func_table.Start   = &R_Config_MTU1_Esig2_1_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU1_Esig2_1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU1_Esig2_1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU1_Esig2_1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_1, g_st_user_func_table);

    g_st_user_func_table.Start   = &R_Config_MTU1_Esig2_2_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU1_Esig2_2_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU1_Esig2_2_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU1_Esig2_2_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_2, g_st_user_func_table);

// MTU1-ESIG12(non asign)

//----------------------------------------------------------------
// MTU2-ESIG1
    g_st_user_func_table.Start   = &R_Config_MTU2_Esig1_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU2_Esig1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU2_Esig1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU2_Esig1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG1, g_st_user_func_table);

// MTU2-ESIG2_1,ESIG2_2
    g_st_user_func_table.Start   = &R_Config_MTU2_Esig2_1_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU2_Esig2_1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU2_Esig2_1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU2_Esig2_1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_1, g_st_user_func_table);

    g_st_user_func_table.Start   = &R_Config_MTU2_Esig2_2_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU2_Esig2_2_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU2_Esig2_2_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU2_Esig2_2_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_2, g_st_user_func_table);

// MTU2-ESIG12(non asign)

//----------------------------------------------------------------
// MTU6-ESIG1
    g_st_user_func_table.Start   = &R_Config_MTU6_Esig1_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU6_Esig1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU6_Esig1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU6_Esig1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG1, g_st_user_func_table);

// MTU6-ESIG2_1,ESIG2_2
    g_st_user_func_table.Start   = &R_Config_MTU6_Esig2_1_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU6_Esig2_1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU6_Esig2_1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU6_Esig2_1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_1, g_st_user_func_table);

    g_st_user_func_table.Start   = &R_Config_MTU6_Esig2_2_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU6_Esig2_2_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU6_Esig2_2_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU6_Esig2_2_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_2, g_st_user_func_table);

// MTU6-ESIG12(non asign)

//----------------------------------------------------------------
// MTU7-ESIG1
    g_st_user_func_table.Start   = &R_Config_MTU7_Esig1_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU7_Esig1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU7_Esig1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU7_Esig1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG1, g_st_user_func_table);

// MTU7-ESIG2_1,ESIG2_2
    g_st_user_func_table.Start   = &R_Config_MTU7_Esig2_1_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU7_Esig2_1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU7_Esig2_1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU7_Esig2_1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_1, g_st_user_func_table);

    g_st_user_func_table.Start   = &R_Config_MTU7_Esig2_2_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU7_Esig2_2_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU7_Esig2_2_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU7_Esig2_2_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_2, g_st_user_func_table);

// MTU7-ESIG12(non asign)

//----------------------------------------------------------------
// MTU9-ESIG1
    g_st_user_func_table.Start   = &R_Config_MTU9_Esig1_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU9_Esig1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU9_Esig1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU9_Esig1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG1, g_st_user_func_table);

// MTU9-ESIG2_1,ESIG2_2
    g_st_user_func_table.Start   = &R_Config_MTU9_Esig2_1_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU9_Esig2_1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU9_Esig2_1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU9_Esig2_1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_1, g_st_user_func_table);

    g_st_user_func_table.Start   = &R_Config_MTU9_Esig2_2_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU9_Esig2_2_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU9_Esig2_2_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU9_Esig2_2_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_2, g_st_user_func_table);

// MTU9-ESIG12
    g_st_user_func_table.Start   = &R_Config_MTU9_Esig12_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU9_Esig12_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU9_Esig12_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU9_Esig12_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG12, g_st_user_func_table);


//----------------------------------------------------------------
// GPT0-ESIG1
    g_st_user_func_table.Start   = &R_Config_GPT0_Esig1_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT0_Esig1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT0_Esig1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT0_Esig1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG1, g_st_user_func_table);

// GPT0-ESIG2_1,ESIG2_2
    g_st_user_func_table.Start   = &R_Config_GPT0_Esig2_1_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT0_Esig2_1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT0_Esig2_1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT0_Esig2_1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_1, g_st_user_func_table);

    g_st_user_func_table.Start   = &R_Config_GPT0_Esig2_2_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT0_Esig2_2_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT0_Esig2_2_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT0_Esig2_2_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_2, g_st_user_func_table);

// GPT0-ESIG12
    g_st_user_func_table.Start   = &R_Config_GPT0_Esig12_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT0_Esig12_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT0_Esig12_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT0_Esig12_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG12, g_st_user_func_table);

//----------------------------------------------------------------
// GPT1-ESIG1
    g_st_user_func_table.Start   = &R_Config_GPT1_Esig1_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT1_Esig1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT1_Esig1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT1_Esig1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG1, g_st_user_func_table);

// GPT1-ESIG2_1,ESIG2_2
    g_st_user_func_table.Start   = &R_Config_GPT1_Esig2_1_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT1_Esig2_1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT1_Esig2_1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT1_Esig2_1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_1, g_st_user_func_table);

    g_st_user_func_table.Start   = &R_Config_GPT1_Esig2_2_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT1_Esig2_2_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT1_Esig2_2_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT1_Esig2_2_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_2, g_st_user_func_table);

// GPT1-ESIG12
    g_st_user_func_table.Start   = &R_Config_GPT1_Esig12_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT1_Esig12_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT1_Esig12_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT1_Esig12_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG12, g_st_user_func_table);

//----------------------------------------------------------------
// GPT2-ESIG1
    g_st_user_func_table.Start   = &R_Config_GPT2_Esig1_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT2_Esig1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT2_Esig1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT2_Esig1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG1, g_st_user_func_table);

// GPT2-ESIG2_1,ESIG2_2
    g_st_user_func_table.Start   = &R_Config_GPT2_Esig2_1_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT2_Esig2_1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT2_Esig2_1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT2_Esig2_1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_1, g_st_user_func_table);

    g_st_user_func_table.Start   = &R_Config_GPT2_Esig2_2_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT2_Esig2_2_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT2_Esig2_2_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT2_Esig2_2_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_2, g_st_user_func_table);

// GPT2-ESIG12
    g_st_user_func_table.Start   = &R_Config_GPT2_Esig12_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT2_Esig12_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT2_Esig12_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT2_Esig12_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG12, g_st_user_func_table);

//----------------------------------------------------------------
// GPT3-ESIG1
    g_st_user_func_table.Start   = &R_Config_GPT3_Esig1_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT3_Esig1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT3_Esig1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT3_Esig1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG1, g_st_user_func_table);

// GPT3-ESIG2_1,ESIG2_2
    g_st_user_func_table.Start   = &R_Config_GPT3_Esig2_1_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT3_Esig2_1_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT3_Esig2_1_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT3_Esig2_1_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_1, g_st_user_func_table);

    g_st_user_func_table.Start   = &R_Config_GPT3_Esig2_2_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT3_Esig2_2_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT3_Esig2_2_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT3_Esig2_2_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG2_2, g_st_user_func_table);

// GPT3-ESIG12
    g_st_user_func_table.Start   = &R_Config_GPT3_Esig12_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT3_Esig12_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT3_Esig12_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT3_Esig12_GetTcnt;
    R_RSLV_SetFuncTable(F_ESIG12, g_st_user_func_table);


///////////////////////////////////
///// �p�x�덷�␳�M��
///////////////////////////////////
// MTU0-CSIG
    g_st_user_func_table.Start   = &R_Config_MTU0_Csig_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU0_Csig_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU0_Csig_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU0_Csig_GetTcnt;
    g_st_user_func_table.SetDuty = &R_Config_MTU0_Csig_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_MTU0_Csig_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG, g_st_user_func_table);

// MTU1-CSIG
    g_st_user_func_table.Start   = &R_Config_MTU1_Csig_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU1_Csig_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU1_Csig_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU1_Csig_GetTcnt;
    g_st_user_func_table.SetDuty = &R_Config_MTU1_Csig_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_MTU1_Csig_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG, g_st_user_func_table);

// MTU2-CSIG
    g_st_user_func_table.Start   = &R_Config_MTU2_Csig_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU2_Csig_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU2_Csig_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU2_Csig_GetTcnt;
    g_st_user_func_table.SetDuty = &R_Config_MTU2_Csig_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_MTU2_Csig_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG, g_st_user_func_table);

// MTU6-CSIG
    g_st_user_func_table.Start   = &R_Config_MTU6_Csig_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU6_Csig_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU6_Csig_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU6_Csig_GetTcnt;
    g_st_user_func_table.SetDuty = &R_Config_MTU6_Csig_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_MTU6_Csig_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG, g_st_user_func_table);

// MTU7-CSIG
    g_st_user_func_table.Start   = &R_Config_MTU7_Csig_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU7_Csig_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU7_Csig_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU7_Csig_GetTcnt;
    g_st_user_func_table.SetDuty = &R_Config_MTU7_Csig_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_MTU7_Csig_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG, g_st_user_func_table);

// MTU9-CSIG
    g_st_user_func_table.Start   = &R_Config_MTU9_Csig_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU9_Csig_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU9_Csig_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU9_Csig_GetTcnt;
    g_st_user_func_table.SetDuty = &R_Config_MTU9_Csig_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_MTU9_Csig_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG, g_st_user_func_table);

// GPT0-CSIG
    g_st_user_func_table.Start   = &R_Config_GPT0_Csig_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT0_Csig_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT0_Csig_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT0_Csig_GetTcnt;
    g_st_user_func_table.SetDuty = &R_Config_GPT0_Csig_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_GPT0_Csig_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG, g_st_user_func_table);

// GPT1-CSIG
    g_st_user_func_table.Start   = &R_Config_GPT1_Csig_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT1_Csig_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT1_Csig_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT1_Csig_GetTcnt;
    g_st_user_func_table.SetDuty = &R_Config_GPT1_Csig_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_GPT1_Csig_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG, g_st_user_func_table);

// GPT2-CSIG
    g_st_user_func_table.Start   = &R_Config_GPT2_Csig_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT2_Csig_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT2_Csig_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT2_Csig_GetTcnt;
    g_st_user_func_table.SetDuty = &R_Config_GPT2_Csig_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_GPT2_Csig_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG, g_st_user_func_table);

// GPT3-CSIG
    g_st_user_func_table.Start   = &R_Config_GPT3_Csig_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT3_Csig_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT3_Csig_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT3_Csig_GetTcnt;
    g_st_user_func_table.SetDuty = &R_Config_GPT3_Csig_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_GPT3_Csig_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG, g_st_user_func_table);


///////////////////////////////////
///// �ʑ������M��A
///////////////////////////////////
// MTU0-PHASE_A
    g_st_user_func_table.Start   = &R_Config_MTU0_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU0_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU0_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// MTU1-PHASE_A
    g_st_user_func_table.Start   = &R_Config_MTU1_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU1_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU1_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// MTU2-PHASE_A
    g_st_user_func_table.Start   = &R_Config_MTU2_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU2_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU2_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// MTU6-PHASE_A
    g_st_user_func_table.Start   = &R_Config_MTU6_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU6_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU6_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// MTU7-PHASE_A
    g_st_user_func_table.Start   = &R_Config_MTU7_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU7_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU7_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// MTU9-PHASE_A
    g_st_user_func_table.Start   = &R_Config_MTU9_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU9_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU9_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// GPT0-PHASE_A
    g_st_user_func_table.Start   = &R_Config_GPT0_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT0_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_GPT0_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// GPT1-PHASE_A
    g_st_user_func_table.Start   = &R_Config_GPT1_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT1_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_GPT1_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// GPT2-PHASE_A
    g_st_user_func_table.Start   = &R_Config_GPT2_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT2_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_GPT2_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// GPT3-PHASE_A
    g_st_user_func_table.Start   = &R_Config_GPT3_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT3_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_GPT3_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// TMR0-PHASE_A
    g_st_user_func_table.Start   = &R_Config_TMR0_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR0_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR0_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// TMR1-PHASE_A
    g_st_user_func_table.Start   = &R_Config_TMR1_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR1_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR1_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// TMR2-PHASE_A
    g_st_user_func_table.Start   = &R_Config_TMR2_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR2_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR2_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// TMR3-PHASE_A
    g_st_user_func_table.Start   = &R_Config_TMR3_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR3_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR3_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// TMR4-PHASE_A
    g_st_user_func_table.Start   = &R_Config_TMR4_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR4_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR4_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// TMR5-PHASE_A
    g_st_user_func_table.Start   = &R_Config_TMR5_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR5_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR5_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// TMR6-PHASE_A
    g_st_user_func_table.Start   = &R_Config_TMR6_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR6_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR6_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

// TMR7-PHASE_A
    g_st_user_func_table.Start   = &R_Config_TMR7_PhaseA_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR7_PhaseA_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR7_PhaseA_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_A, g_st_user_func_table);

///////////////////////////////////
///// �ʑ������M��B
///////////////////////////////////
// MTU0-PHASE_B
    g_st_user_func_table.Start   = &R_Config_MTU0_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU0_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU0_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// MTU1-PHASE_B
    g_st_user_func_table.Start   = &R_Config_MTU1_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU1_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU1_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// MTU2-PHASE_B
    g_st_user_func_table.Start   = &R_Config_MTU2_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU2_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU2_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// MTU6-PHASE_B
    g_st_user_func_table.Start   = &R_Config_MTU6_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU6_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU6_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// MTU7-PHASE_B
    g_st_user_func_table.Start   = &R_Config_MTU7_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU7_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU7_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// MTU9-PHASE_B
    g_st_user_func_table.Start   = &R_Config_MTU9_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU9_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU9_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);
// GPT0-PHASE_B
    g_st_user_func_table.Start   = &R_Config_GPT0_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT0_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_GPT0_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// GPT1-PHASE_B
    g_st_user_func_table.Start   = &R_Config_GPT1_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT1_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_GPT1_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// GPT2-PHASE_B
    g_st_user_func_table.Start   = &R_Config_GPT2_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT2_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_GPT2_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// GPT3-PHASE_B
    g_st_user_func_table.Start   = &R_Config_GPT3_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT3_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_GPT3_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// TMR0-PHASE_B
    g_st_user_func_table.Start   = &R_Config_TMR0_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR0_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR0_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// TMR1-PHASE_B
    g_st_user_func_table.Start   = &R_Config_TMR1_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR1_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR1_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// TMR2-PHASE_B
    g_st_user_func_table.Start   = &R_Config_TMR2_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR2_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR2_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// TMR3-PHASE_B
    g_st_user_func_table.Start   = &R_Config_TMR3_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR3_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR3_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// TMR4-PHASE_B
    g_st_user_func_table.Start   = &R_Config_TMR4_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR4_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR4_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// TMR5-PHASE_B
    g_st_user_func_table.Start   = &R_Config_TMR5_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR5_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR5_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// TMR6-PHASE_B
    g_st_user_func_table.Start   = &R_Config_TMR6_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR6_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR6_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

// TMR7-PHASE_B
    g_st_user_func_table.Start   = &R_Config_TMR7_PhaseB_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR7_PhaseB_Stop;
    g_st_user_func_table.SetDuty = &R_Config_TMR7_PhaseB_SetDuty;
    R_RSLV_SetFuncTable(F_PHASE_B, g_st_user_func_table);

///////////////////////////////////
///// �ʑ������M��AB
///////////////////////////////////
// MTU0-PHASE_AB
    g_st_user_func_table.Start        = &R_Config_MTU0_PhaseAB_Start;
    g_st_user_func_table.Stop         = &R_Config_MTU0_PhaseAB_Stop;
    g_st_user_func_table.SetDuty_2val = &R_Config_MTU0_PhaseAB_SetDuty_2val;
    R_RSLV_SetFuncTable(F_PHASE_AB, g_st_user_func_table);

// MTU1-PHASE_AB(non asign)
// MTU2-PHASE_AB(non asign)

// MTU6-PHASE_AB
    g_st_user_func_table.Start        = &R_Config_MTU6_PhaseAB_Start;
    g_st_user_func_table.Stop         = &R_Config_MTU6_PhaseAB_Stop;
    g_st_user_func_table.SetDuty_2val = &R_Config_MTU6_PhaseAB_SetDuty_2val;
    R_RSLV_SetFuncTable(F_PHASE_AB, g_st_user_func_table);

// MTU7-PHASE_AB
    g_st_user_func_table.Start        = &R_Config_MTU7_PhaseAB_Start;
    g_st_user_func_table.Stop         = &R_Config_MTU7_PhaseAB_Stop;
    g_st_user_func_table.SetDuty_2val = &R_Config_MTU7_PhaseAB_SetDuty_2val;
    R_RSLV_SetFuncTable(F_PHASE_AB, g_st_user_func_table);

// MTU9-PHASE_AB
    g_st_user_func_table.Start        = &R_Config_MTU9_PhaseAB_Start;
    g_st_user_func_table.Stop         = &R_Config_MTU9_PhaseAB_Stop;
    g_st_user_func_table.SetDuty_2val = &R_Config_MTU9_PhaseAB_SetDuty_2val;
    R_RSLV_SetFuncTable(F_PHASE_AB, g_st_user_func_table);

// GPT0-PHASE_AB
    g_st_user_func_table.Start        = &R_Config_GPT0_PhaseAB_Start;
    g_st_user_func_table.Stop         = &R_Config_GPT0_PhaseAB_Stop;
    g_st_user_func_table.SetDuty_2val = &R_Config_GPT0_PhaseAB_SetDuty_2val;
    R_RSLV_SetFuncTable(F_PHASE_AB, g_st_user_func_table);

// GPT1-PHASE_AB
    g_st_user_func_table.Start        = &R_Config_GPT1_PhaseAB_Start;
    g_st_user_func_table.Stop         = &R_Config_GPT1_PhaseAB_Stop;
    g_st_user_func_table.SetDuty_2val = &R_Config_GPT1_PhaseAB_SetDuty_2val;
    R_RSLV_SetFuncTable(F_PHASE_AB, g_st_user_func_table);

// GPT2-PHASE_AB
    g_st_user_func_table.Start        = &R_Config_GPT2_PhaseAB_Start;
    g_st_user_func_table.Stop         = &R_Config_GPT2_PhaseAB_Stop;
    g_st_user_func_table.SetDuty_2val = &R_Config_GPT2_PhaseAB_SetDuty_2val;
    R_RSLV_SetFuncTable(F_PHASE_AB, g_st_user_func_table);

// GPT3-PHASE_AB
    g_st_user_func_table.Start        = &R_Config_GPT3_PhaseAB_Start;
    g_st_user_func_table.Stop         = &R_Config_GPT3_PhaseAB_Stop;
    g_st_user_func_table.SetDuty_2val = &R_Config_GPT3_PhaseAB_SetDuty_2val;
    R_RSLV_SetFuncTable(F_PHASE_AB, g_st_user_func_table);

///////////////////////////////////
///// �p�x�M������
///////////////////////////////////
// MTU0-CAP
    g_st_user_func_table.Start   = &R_Config_MTU0_Cap_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU0_Cap_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU0_Cap_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU0_Cap_GetTcnt;
    g_st_user_func_table.GetCaptureValue = &R_Config_MTU0_Cap_GetCapVal;
    g_st_user_func_table.GetPortLevel = &R_Config_MTU0_Cap_GetPortLvl;
    R_RSLV_SetFuncTable(F_CAPTURE, g_st_user_func_table);

// MTU1-CAP
    g_st_user_func_table.Start   = &R_Config_MTU1_Cap_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU1_Cap_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU1_Cap_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU1_Cap_GetTcnt;
    g_st_user_func_table.GetCaptureValue = &R_Config_MTU1_Cap_GetCapVal;
    g_st_user_func_table.GetPortLevel = &R_Config_MTU1_Cap_GetPortLvl;
    R_RSLV_SetFuncTable(F_CAPTURE, g_st_user_func_table);

// MTU2-CAP
    g_st_user_func_table.Start   = &R_Config_MTU2_Cap_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU2_Cap_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU2_Cap_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU2_Cap_GetTcnt;
    g_st_user_func_table.GetCaptureValue = &R_Config_MTU2_Cap_GetCapVal;
    g_st_user_func_table.GetPortLevel = &R_Config_MTU2_Cap_GetPortLvl;
    R_RSLV_SetFuncTable(F_CAPTURE, g_st_user_func_table);

// MTU6-CAP
    g_st_user_func_table.Start   = &R_Config_MTU6_Cap_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU6_Cap_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU6_Cap_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU6_Cap_GetTcnt;
    g_st_user_func_table.GetCaptureValue = &R_Config_MTU6_Cap_GetCapVal;
    g_st_user_func_table.GetPortLevel = &R_Config_MTU6_Cap_GetPortLvl;
    R_RSLV_SetFuncTable(F_CAPTURE, g_st_user_func_table);

// MTU7-CAP
    g_st_user_func_table.Start   = &R_Config_MTU7_Cap_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU7_Cap_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU7_Cap_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU7_Cap_GetTcnt;
    g_st_user_func_table.GetCaptureValue = &R_Config_MTU7_Cap_GetCapVal;
    g_st_user_func_table.GetPortLevel = &R_Config_MTU7_Cap_GetPortLvl;
    R_RSLV_SetFuncTable(F_CAPTURE, g_st_user_func_table);

// MTU9-CAP
    g_st_user_func_table.Start   = &R_Config_MTU9_Cap_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU9_Cap_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_MTU9_Cap_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_MTU9_Cap_GetTcnt;
    g_st_user_func_table.GetCaptureValue = &R_Config_MTU9_Cap_GetCapVal;
    g_st_user_func_table.GetPortLevel = &R_Config_MTU9_Cap_GetPortLvl;
    R_RSLV_SetFuncTable(F_CAPTURE, g_st_user_func_table);

// GPT0-CAP
    g_st_user_func_table.Start   = &R_Config_GPT0_Cap_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT0_Cap_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT0_Cap_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT0_Cap_GetTcnt;
    g_st_user_func_table.GetCaptureValue = &R_Config_GPT0_Cap_GetCapVal;
    g_st_user_func_table.GetPortLevel = &R_Config_GPT0_Cap_GetPortLvl;
    R_RSLV_SetFuncTable(F_CAPTURE, g_st_user_func_table);

// GPT1-CAP
    g_st_user_func_table.Start   = &R_Config_GPT1_Cap_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT1_Cap_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT1_Cap_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT1_Cap_GetTcnt;
    g_st_user_func_table.GetCaptureValue = &R_Config_GPT1_Cap_GetCapVal;
    g_st_user_func_table.GetPortLevel = &R_Config_GPT1_Cap_GetPortLvl;
    R_RSLV_SetFuncTable(F_CAPTURE, g_st_user_func_table);

// GPT2-CAP
    g_st_user_func_table.Start   = &R_Config_GPT2_Cap_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT2_Cap_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT2_Cap_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT2_Cap_GetTcnt;
    g_st_user_func_table.GetCaptureValue = &R_Config_GPT2_Cap_GetCapVal;
    g_st_user_func_table.GetPortLevel = &R_Config_GPT2_Cap_GetPortLvl;
    R_RSLV_SetFuncTable(F_CAPTURE, g_st_user_func_table);

// GPT3-CAP
    g_st_user_func_table.Start   = &R_Config_GPT3_Cap_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT3_Cap_Stop;
    g_st_user_func_table.SetTcnt = &R_Config_GPT3_Cap_SetTcnt;
    g_st_user_func_table.GetTcnt = &R_Config_GPT3_Cap_GetTcnt;
    g_st_user_func_table.GetCaptureValue = &R_Config_GPT3_Cap_GetCapVal;
    g_st_user_func_table.GetPortLevel = &R_Config_GPT3_Cap_GetPortLvl;
    R_RSLV_SetFuncTable(F_CAPTURE, g_st_user_func_table);

///////////////////////////////////
///// �p�x�덷�␳�M��Duty�X�V
///////////////////////////////////
// MTU0-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_MTU0_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU0_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU0_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_MTU0_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// MTU1-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_MTU1_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU1_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU1_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_MTU1_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// MTU2-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_MTU2_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU2_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU2_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_MTU2_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// MTU6-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_MTU6_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU6_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU6_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_MTU6_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// MTU7-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_MTU7_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU7_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU7_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_MTU7_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// MTU9-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_MTU9_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU9_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_MTU9_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_MTU9_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// GPT0-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_GPT0_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT0_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_GPT0_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_GPT0_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// GPT1-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_GPT1_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT1_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_GPT1_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_GPT1_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// GPT2-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_GPT2_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT2_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_GPT2_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_GPT2_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// GPT3-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_GPT3_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT3_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_GPT3_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_GPT3_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// CMT0-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_CMT0_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_CMT0_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_CMT0_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_CMT0_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// CMT1-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_CMT1_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_CMT1_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_CMT1_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_CMT1_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// CMT2-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_CMT2_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_CMT2_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_CMT2_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_CMT2_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

// CMT3-CSIG_UPD_TIM
    g_st_user_func_table.Start   = &R_Config_CMT3_CsigUpdTim_Start;
    g_st_user_func_table.Stop    = &R_Config_CMT3_CsigUpdTim_Stop;
    g_st_user_func_table.SetDuty = &R_Config_CMT3_CsigUpdTim_SetDuty;
    g_st_user_func_table.GetDuty = &R_Config_CMT3_CsigUpdTim_GetDuty;
    R_RSLV_SetFuncTable(F_CSIG_UPD_TIMER, g_st_user_func_table);

///////////////////////////////////
///// RDC-IC�ʐM
///////////////////////////////////
// RSPI0-RDC_COM
    g_st_user_func_table.ComSendReceive = & R_Config_RSPI0_RdcCom_Send_Receive;
    R_RSLV_SetFuncTable(F_RDC_COM, g_st_user_func_table);

// SCI1-RDC_COM
    g_st_user_func_table.ComSendReceive = & R_Config_SCI1_RdcCom_Send_Receive;
    R_RSLV_SetFuncTable(F_RDC_COM, g_st_user_func_table);

// SCI5-RDC_COM
    g_st_user_func_table.ComSendReceive = & R_Config_SCI5_RdcCom_Send_Receive;
    R_RSLV_SetFuncTable(F_RDC_COM, g_st_user_func_table);

// SCI6-RDC_COM
    g_st_user_func_table.ComSendReceive = & R_Config_SCI6_RdcCom_Send_Receive;
    R_RSLV_SetFuncTable(F_RDC_COM, g_st_user_func_table);

///////////////////////////////////
///// RDC�N���b�N
///////////////////////////////////
// MTU0-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_MTU0_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU0_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// MTU1-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_MTU1_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU1_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// MTU2-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_MTU2_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU2_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// MTU6-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_MTU6_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU6_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// MTU7-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_MTU7_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU7_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// MTU9-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_MTU9_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_MTU9_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);


// GPT0-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_GPT0_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT0_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// GPT1-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_GPT1_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT1_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// GPT2-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_GPT2_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT2_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// GPT3-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_GPT3_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_GPT3_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// TMR0-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_TMR0_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR0_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// TMR1-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_TMR1_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR1_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// TMR2-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_TMR2_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR2_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// TMR3-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_TMR3_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR3_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// TMR4-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_TMR4_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR4_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// TMR5-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_TMR5_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR5_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// TMR6-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_TMR6_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR6_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);

// TMR7-RDC_CLK
    g_st_user_func_table.Start   = &R_Config_TMR7_RdcClk_Start;
    g_st_user_func_table.Stop    = &R_Config_TMR7_RdcClk_Stop;
    R_RSLV_SetFuncTable(F_RDC_CLK, g_st_user_func_table);


