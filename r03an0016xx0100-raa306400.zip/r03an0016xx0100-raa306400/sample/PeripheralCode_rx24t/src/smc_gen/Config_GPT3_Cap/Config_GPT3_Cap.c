/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : Config_GPT3_Cap.c
* Version      : 1.5.1
* Device(s)    : R5F524TEAxFP
* Description  : This file implements device driver for Config_GPT3_Cap.
* Creation Date: 2021-02-09
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_GPT3_Cap.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_GPT3_Cap_Create
* Description  : This function initializes the GPT3 channel
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT3_Cap_Create(void)
{
    /* Disable GPT3 interrupts */
    IEN(GPT3, GTCIA3) = 0U;

    /* Cancel GPT module stop state */
    MSTP(GPT) = 0U;

    /* Disable GPT common registers write protect */
    GPT.GTCMNWP.BIT.CMNWP = 0U;
    GPT.GTWP.BIT.WP3 = 0U;
    GPT.GTCWP.BIT.CWP3 = 0U;

    /* Disable GPT3 control registers write protect */
    GPT.GTWP.BIT.WP3 = 0U;

    /* Set GPT3 mode and counter clear */
    GPT3.GTCR.WORD = _0000_GPTn_COUNTER_CLEAR_NONE | _0000_GPTn_MODE_SAW_WAVE_PWM;

    /* Forcibly set GPT3 count direction */
    GPT3.GTUDC.WORD = _0002_GPTn_COUNT_DIR_FORCE | _0001_GPTn_COUNT_UP;

    /* Clear GPT3 count direction forcible set */
    GPT3.GTUDC.BIT.UDF = 0U;

    /* Set GPT3 count clock */
    GPT3.GTCR.BIT.TPCS = _00_GPTn_COUNT_CLK_PCLKA_1;

    /* Set GPT3 cycle */
    GPT3.GTPR = _3E7F_GPT3_CYCLE_VALUE;

    /* Set GPT3 counter initial value */
    GPT3.GTCNT = _0000_GPT3_INIT_COUNT;

    /* Set GPT3 hardware count start source */
    GPT.GTHSSR.BIT.CSHSL3 = _00_GPT_HW_START_SRC_NONE;

    /* Set GPT3 hardware count stop/clear source */
    GPT.GTHPSR.BIT.CSHPL3 = _00_GPT_HW_STPCLR_SRC_NONE;

    /* Set GTIOC3A, GTIOC3B pin function */
    GPT3.GTIOR.WORD = _0001_GPTn_GTIOCA_INPUT_CAPTURE_FALLING | _0020_GPTn_GTCCRA_INPUT_CAPTURE | 
                      _0000_GPTn_GTCCRB_COMP_MATCH;

    /* Enable GTIOC3A, GTIOC3B pin output and set negation */
    GPT3.GTONCR.WORD = _0000_GPTn_GTCIOCB_OUTPUT_DISABLE;

    /* Disable GPT3 buffers */
    GPT.GTBDR.BIT.BD30 = 1U;
    GPT.GTBDR.BIT.BD31 = 1U;
    GPT.GTBDR.BIT.BD32 = 1U;
    GPT.GTBDR.BIT.BD33 = 1U;

    /* Set GPT3 buffer operations */
    GPT3.GTBER.WORD = _0000_GPTn_GTPR_BUF_NONE | _0000_GPTn_GTCCRB_BUF_NONE | _0000_GPTn_GTCCRA_BUF_NONE;

    /* Set GPT3 compare match value */
    GPT3.GTCCRB = _0064_GPT3_COMP_MATCH_B_VALUE;
    GPT3.GTCCRC = _0064_GPT3_COMP_MATCH_C_VALUE;
    GPT3.GTCCRD = _0064_GPT3_COMP_MATCH_D_VALUE;
    GPT3.GTCCRE = _0064_GPT3_COMP_MATCH_E_VALUE;
    GPT3.GTCCRF = _0064_GPT3_COMP_MATCH_F_VALUE;

    /* Set GPT A/D conversion start request signal monitor */
    GPT.GTADSMR.LONG = _00000000_GPT_AD_START_REQ_0_DISABLE | _00000000_GPT_AD_START_REQ_1_DISABLE;

    /* Set GPT3 interrupt and A/D conversion request generation */
    GPT3.GTINTAD.WORD = _0000_GPTn_ADTRB_DOWNCOUNTING_DISABLE | _0000_GPTn_ADTRB_UPCOUNTING_DISABLE | 
                        _0000_GPTn_ADTRA_DOWNCOUNTING_DISABLE | _0000_GPTn_ADTRA_UPCOUNTING_DISABLE | 
                        _0000_GPTn_GTCIV_INTERRUPT_DISABLE | _0000_GPTn_GTCIU_INTERRUPT_DISABLE | 
                        _0000_GPTn_GTCIF_INTERRUPT_DISABLE | _0000_GPTn_GTCIE_INTERRUPT_DISABLE | 
                        _0000_GPTn_GTCID_INTERRUPT_DISABLE | _0000_GPTn_GTCIC_INTERRUPT_DISABLE | 
                        _0000_GPTn_GTCIB_INTERRUPT_DISABLE | _0001_GPTn_GTCIA_INTERRUPT_ENABLE;

    /* Set GPT3 interrupt and A/D conversion request skipping */
    GPT3.GTITC.WORD = _0000_GPTn_GTCI_SKIPPING_DISABLE;

    /* Configure GPT3 interrupts */
    IPR(GPT3, GTCIA3) = _0F_GPT_PRIORITY_LEVEL15;

    /* Set GTIOC3A pin */
    MPC.PD7PFS.BYTE = 0x14U;
    PORTD.PMR.BYTE |= 0x80U;

    /* Enable GPT registers write protect */
    GPT.GTCMNWP.BIT.CMNWP = 1U;
    GPT.GTWP.BIT.WP3 = 1U;
    GPT.GTCWP.BIT.CWP3 = 1U;

    R_Config_GPT3_Cap_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_GPT3_Cap_Start
* Description  : This function starts the GPT3 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT3_Cap_Start(void)
{
    /* Enable GPT3 interrupts */
    IR(GPT3, GTCIA3) = 0U;
    IEN(GPT3, GTCIA3) = 1U;

    /* Disable GPT3 start write protect */
    GPT.GTSWP.BIT.SWP3 = 0U;

    /* Start GPT3 counting */
    GPT.GTSTR.BIT.CST3 = 1U;

    /* Enable GPT3 start write protect */
    GPT.GTSWP.BIT.SWP3 = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_GPT3_Cap_Stop
* Description  : This function stops the GPT3 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT3_Cap_Stop(void)
{
    /* Disable GPT3 interrupts */
    IEN(GPT3, GTCIA3) = 0U;

    /* Disable GPT3 start write protect */
    GPT.GTSWP.BIT.SWP3 = 0U;

    /* Stop GPT3 counting */
    GPT.GTSTR.BIT.CST3 = 0U;

    /* Enable GPT3 start write protect */
    GPT.GTSWP.BIT.SWP3 = 1U;
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
