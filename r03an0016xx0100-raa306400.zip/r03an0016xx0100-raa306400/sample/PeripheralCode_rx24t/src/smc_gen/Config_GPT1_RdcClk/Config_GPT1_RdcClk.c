/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : Config_GPT1_RdcClk.c
* Version      : 1.5.1
* Device(s)    : R5F524TEAxFP
* Description  : This file implements device driver for Config_GPT1_RdcClk.
* Creation Date: 2021-02-09
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_GPT1_RdcClk.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_GPT1_RdcClk_Create
* Description  : This function initializes the GPT1 channel
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT1_RdcClk_Create(void)
{
    /* Cancel GPT module stop state */
    MSTP(GPT) = 0U;

    /* Disable GPT common registers write protect */
    GPT.GTCMNWP.BIT.CMNWP = 0U;
    GPT.GTWP.BIT.WP1 = 0U;
    GPT.GTCWP.BIT.CWP1 = 0U;

    /* Disable GPT1 control registers write protect */
    GPT.GTWP.BIT.WP1 = 0U;

    /* Set GPT1 mode and counter clear */
    GPT1.GTCR.WORD = _0000_GPTn_COUNTER_CLEAR_NONE | _0000_GPTn_MODE_SAW_WAVE_PWM;

    /* Forcibly set GPT1 count direction */
    GPT1.GTUDC.WORD = _0002_GPTn_COUNT_DIR_FORCE | _0001_GPTn_COUNT_UP;

    /* Clear GPT1 count direction forcible set */
    GPT1.GTUDC.BIT.UDF = 0U;

    /* Set GPT1 count clock */
    GPT1.GTCR.BIT.TPCS = _00_GPTn_COUNT_CLK_PCLKA_1;

    /* Set GPT1 cycle */
    GPT1.GTPR = _0013_GPT1_CYCLE_VALUE;

    /* Set GPT1 counter initial value */
    GPT1.GTCNT = _0000_GPT1_INIT_COUNT;

    /* Set GPT1 hardware count start source */
    GPT.GTHSSR.BIT.CSHSL1 = _00_GPT_HW_START_SRC_NONE;

    /* Set GPT1 hardware count stop/clear source */
    GPT.GTHPSR.BIT.CSHPL1 = _00_GPT_HW_STPCLR_SRC_NONE;

    /* Set GTIOC1A, GTIOC1B pin function */
    GPT1.GTIOR.WORD = _0000_GPTn_GTIOCA_OUTPUT_ON_START_SET | _0000_GPTn_GTIOCA_OUTPUT_ON_STOP_0 | 
                      _0008_GPTn_GTIOCA_CYCLE_END_HIGH | _0001_GPTn_GTIOCA_COMP_MATCH_LOW | 
                      _0010_GPTn_GTIOCA_INIT_OUT_HIGH | _0000_GPTn_GTCCRA_COMP_MATCH | _0000_GPTn_GTCCRB_COMP_MATCH;

    /* Enable GTIOC1A, GTIOC1B pin output and set negation */
    GPT1.GTONCR.WORD = _0000_GPTn_GTCIOCB_OUTPUT_DISABLE | _4000_GPTn_GTCIOCA_OUTPUT_ENABLE | 
                       _0000_GPTn_GTCIOA_NEGATE_DISABLE;

    /* Disable GPT1 buffers */
    GPT.GTBDR.BIT.BD10 = 1U;
    GPT.GTBDR.BIT.BD11 = 1U;
    GPT.GTBDR.BIT.BD12 = 1U;
    GPT.GTBDR.BIT.BD13 = 1U;

    /* Set GPT1 buffer operations */
    GPT1.GTBER.WORD = _0000_GPTn_GTPR_BUF_NONE | _0000_GPTn_GTCCRB_BUF_NONE | _0000_GPTn_GTCCRA_BUF_NONE;

    /* Set GPT1 compare match value */
    GPT1.GTCCRA = _0009_GPT1_COMP_MATCH_A_VALUE;
    GPT1.GTCCRB = _0012_GPT1_COMP_MATCH_B_VALUE;
    GPT1.GTCCRC = _0012_GPT1_COMP_MATCH_C_VALUE;
    GPT1.GTCCRD = _0012_GPT1_COMP_MATCH_D_VALUE;
    GPT1.GTCCRE = _0012_GPT1_COMP_MATCH_E_VALUE;
    GPT1.GTCCRF = _0012_GPT1_COMP_MATCH_F_VALUE;

    /* Set GPT A/D conversion start request signal monitor */
    GPT.GTADSMR.LONG = _00000000_GPT_AD_START_REQ_0_DISABLE | _00000000_GPT_AD_START_REQ_1_DISABLE;

    /* Set GPT1 interrupt and A/D conversion request generation */
    GPT1.GTINTAD.WORD = _0000_GPTn_ADTRB_DOWNCOUNTING_DISABLE | _0000_GPTn_ADTRB_UPCOUNTING_DISABLE | 
                        _0000_GPTn_ADTRA_DOWNCOUNTING_DISABLE | _0000_GPTn_ADTRA_UPCOUNTING_DISABLE | 
                        _0000_GPTn_GTCIV_INTERRUPT_DISABLE | _0000_GPTn_GTCIU_INTERRUPT_DISABLE | 
                        _0000_GPTn_GTCIF_INTERRUPT_DISABLE | _0000_GPTn_GTCIE_INTERRUPT_DISABLE | 
                        _0000_GPTn_GTCID_INTERRUPT_DISABLE | _0000_GPTn_GTCIC_INTERRUPT_DISABLE | 
                        _0000_GPTn_GTCIB_INTERRUPT_DISABLE | _0000_GPTn_GTCIA_INTERRUPT_DISABLE;

    /* Set GPT1 interrupt and A/D conversion request skipping */
    GPT1.GTITC.WORD = _0000_GPTn_GTCI_SKIPPING_DISABLE;

    /* Set GTIOC1A pin */
    MPC.PD0PFS.BYTE = 0x14U;
    PORTD.PMR.BYTE |= 0x01U;

    /* Enable GPT registers write protect */
    GPT.GTCMNWP.BIT.CMNWP = 1U;
    GPT.GTWP.BIT.WP1 = 1U;
    GPT.GTCWP.BIT.CWP1 = 1U;

    R_Config_GPT1_RdcClk_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_GPT1_RdcClk_Start
* Description  : This function starts the GPT1 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT1_RdcClk_Start(void)
{
    /* Disable GPT1 start write protect */
    GPT.GTSWP.BIT.SWP1 = 0U;

    /* Start GPT1 counting */
    GPT.GTSTR.BIT.CST1 = 1U;

    /* Enable GPT1 start write protect */
    GPT.GTSWP.BIT.SWP1 = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_GPT1_RdcClk_Stop
* Description  : This function stops the GPT1 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT1_RdcClk_Stop(void)
{
    /* Disable GPT1 start write protect */
    GPT.GTSWP.BIT.SWP1 = 0U;

    /* Stop GPT1 counting */
    GPT.GTSTR.BIT.CST1 = 0U;

    /* Enable GPT1 start write protect */
    GPT.GTSWP.BIT.SWP1 = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_GPT1_RdcClk_Set_GTIOCA_Pin_Ouput_Duty
* Description  : This function changes GTIOCA1 pin output duty setting
* Arguments    : duty_set -
*                    GTIOCA1 pin output duty setting
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT1_RdcClk_Set_GTIOCA_Pin_Ouput_Duty(duty_setting_t duty_set)
{
    switch (duty_set)
    {
        case DUTY_COMPARE_MATCH_KEEP:
            GPT1.GTUDC.BIT.OADTYR = 0U;
            GPT1.GTUDC.BIT.OADTY = 0U;
            break;

        case DUTY_COMPARE_MATCH_MASK:
            GPT1.GTUDC.BIT.OADTYR = 1U;
            GPT1.GTUDC.BIT.OADTY = 0U;
            break;

        case DUTY_CYCLE_0:
            GPT1.GTUDC.BIT.OADTYR = 0U;
            GPT1.GTUDC.BIT.OADTY = 2U;
            break;

        case DUTY_CYCLE_100:
            GPT1.GTUDC.BIT.OADTYR = 0U;
            GPT1.GTUDC.BIT.OADTY = 3U;
            break;
    }
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
