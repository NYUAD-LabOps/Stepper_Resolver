/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : Config_GPT2_Esig12.c
* Version      : 1.5.1
* Device(s)    : R5F524TEAxFP
* Description  : This file implements device driver for Config_GPT2_Esig12.
* Creation Date: 2021-02-09
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_GPT2_Esig12.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_GPT2_Esig12_Create
* Description  : This function initializes the GPT2 channel
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT2_Esig12_Create(void)
{
    /* Disable GPT2 interrupts */
    IEN(GPT2, GTCIC2) = 0U;

    /* Cancel GPT module stop state */
    MSTP(GPT) = 0U;

    /* Disable GPT common registers write protect */
    GPT.GTCMNWP.BIT.CMNWP = 0U;
    GPT.GTWP.BIT.WP2 = 0U;
    GPT.GTCWP.BIT.CWP2 = 0U;

    /* Disable GPT2 control registers write protect */
    GPT.GTWP.BIT.WP2 = 0U;

    /* Set GPT2 mode and counter clear */
    GPT2.GTCR.WORD = _0000_GPTn_COUNTER_CLEAR_NONE | _0000_GPTn_MODE_SAW_WAVE_PWM;

    /* Forcibly set GPT2 count direction */
    GPT2.GTUDC.WORD = _0002_GPTn_COUNT_DIR_FORCE | _0001_GPTn_COUNT_UP;

    /* Clear GPT2 count direction forcible set */
    GPT2.GTUDC.BIT.UDF = 0U;

    /* Set GPT2 count clock */
    GPT2.GTCR.BIT.TPCS = _00_GPTn_COUNT_CLK_PCLKA_1;

    /* Set GPT2 cycle */
    GPT2.GTPR = _1F3F_GPT2_CYCLE_VALUE;

    /* Set GPT2 counter initial value */
    GPT2.GTCNT = _0000_GPT2_INIT_COUNT;

    /* Set GPT2 hardware count start source */
    GPT.GTHSSR.BIT.CSHSL2 = _00_GPT_HW_START_SRC_NONE;

    /* Set GPT2 hardware count stop/clear source */
    GPT.GTHPSR.BIT.CSHPL2 = _00_GPT_HW_STPCLR_SRC_NONE;

    /* Set GTIOC2A, GTIOC2B pin function */
    GPT2.GTIOR.WORD = _0000_GPTn_GTIOCA_OUTPUT_ON_START_SET | _0000_GPTn_GTIOCA_OUTPUT_ON_STOP_0 | 
                      _0000_GPTn_GTIOCA_CYCLE_END_RETAIN | _0003_GPTn_GTIOCA_COMP_MATCH_TOGGLE | 
                      _0000_GPTn_GTIOCA_INIT_OUT_LOW | _0000_GPTn_GTCCRA_COMP_MATCH | 
                      _0000_GPTn_GTIOCB_OUTPUT_ON_START_SET | _0000_GPTn_GTIOCB_OUTPUT_ON_STOP_0 | 
                      _0000_GPTn_GTIOCB_CYCLE_END_RETAIN | _0300_GPTn_GTIOCB_COMP_MATCH_TOGGLE | 
                      _0000_GPTn_GTIOCB_INIT_OUT_LOW | _0000_GPTn_GTCCRB_COMP_MATCH;

    /* Enable GTIOC2A, GTIOC2B pin output and set negation */
    GPT2.GTONCR.WORD = _8000_GPTn_GTCIOCB_OUTPUT_ENABLE | _4000_GPTn_GTCIOCA_OUTPUT_ENABLE | 
                       _0000_GPTn_GTCIOB_NEGATE_DISABLE | _0000_GPTn_GTCIOA_NEGATE_DISABLE;

    /* Disable GPT2 buffers */
    GPT.GTBDR.BIT.BD20 = 1U;
    GPT.GTBDR.BIT.BD21 = 1U;
    GPT.GTBDR.BIT.BD22 = 1U;
    GPT.GTBDR.BIT.BD23 = 1U;

    /* Set GPT2 buffer operations */
    GPT2.GTBER.WORD = _0000_GPTn_GTPR_BUF_NONE | _0000_GPTn_GTCCRB_BUF_NONE | _0000_GPTn_GTCCRA_BUF_NONE;

    /* Set GPT2 compare match value */
    GPT2.GTCCRA = _0F9F_GPT2_COMP_MATCH_A_VALUE;
    GPT2.GTCCRB = _1A09_GPT2_COMP_MATCH_B_VALUE;
    GPT2.GTCCRC = _14D4_GPT2_COMP_MATCH_C_VALUE;
    GPT2.GTCCRD = _0064_GPT2_COMP_MATCH_D_VALUE;
    GPT2.GTCCRE = _0064_GPT2_COMP_MATCH_E_VALUE;
    GPT2.GTCCRF = _0064_GPT2_COMP_MATCH_F_VALUE;

    /* Set GPT A/D conversion start request signal monitor */
    GPT.GTADSMR.LONG = _00000000_GPT_AD_START_REQ_0_DISABLE | _00000000_GPT_AD_START_REQ_1_DISABLE;

    /* Set GPT2 interrupt and A/D conversion request generation */
    GPT2.GTINTAD.WORD = _0000_GPTn_ADTRB_DOWNCOUNTING_DISABLE | _0000_GPTn_ADTRB_UPCOUNTING_DISABLE | 
                        _0000_GPTn_ADTRA_DOWNCOUNTING_DISABLE | _0000_GPTn_ADTRA_UPCOUNTING_DISABLE | 
                        _0000_GPTn_GTCIV_INTERRUPT_DISABLE | _0000_GPTn_GTCIU_INTERRUPT_DISABLE | 
                        _0000_GPTn_GTCIF_INTERRUPT_DISABLE | _0000_GPTn_GTCIE_INTERRUPT_DISABLE | 
                        _0000_GPTn_GTCID_INTERRUPT_DISABLE | _0004_GPTn_GTCIC_INTERRUPT_ENABLE | 
                        _0000_GPTn_GTCIB_INTERRUPT_DISABLE | _0000_GPTn_GTCIA_INTERRUPT_DISABLE;

    /* Set GPT2 interrupt and A/D conversion request skipping */
    GPT2.GTITC.WORD = _0000_GPTn_GTCI_SKIPPING_DISABLE;

    /* Configure GPT2 interrupts */
    IPR(GPT2, GTCIC2) = _0B_GPT_PRIORITY_LEVEL11;

    /* Set GTIOC2A pin */
    MPC.PB6PFS.BYTE = 0x14U;
    PORTB.PMR.BYTE |= 0x40U;

    /* Set GTIOC2B pin */
    MPC.PB5PFS.BYTE = 0x14U;
    PORTB.PMR.BYTE |= 0x20U;

    /* Enable GPT registers write protect */
    GPT.GTCMNWP.BIT.CMNWP = 1U;
    GPT.GTWP.BIT.WP2 = 1U;
    GPT.GTCWP.BIT.CWP2 = 1U;

    R_Config_GPT2_Esig12_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_GPT2_Esig12_Start
* Description  : This function starts the GPT2 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT2_Esig12_Start(void)
{
    /* Enable GPT2 interrupts */
    IR(GPT2, GTCIC2) = 0U;
    IEN(GPT2, GTCIC2) = 1U;

    /* Disable GPT2 start write protect */
    GPT.GTSWP.BIT.SWP2 = 0U;

    /* Start GPT2 counting */
    GPT.GTSTR.BIT.CST2 = 1U;

    /* Enable GPT2 start write protect */
    GPT.GTSWP.BIT.SWP2 = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_GPT2_Esig12_Stop
* Description  : This function stops the GPT2 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT2_Esig12_Stop(void)
{
    /* Disable GPT2 interrupts */
    IEN(GPT2, GTCIC2) = 0U;

    /* Disable GPT2 start write protect */
    GPT.GTSWP.BIT.SWP2 = 0U;

    /* Stop GPT2 counting */
    GPT.GTSTR.BIT.CST2 = 0U;

    /* Enable GPT2 start write protect */
    GPT.GTSWP.BIT.SWP2 = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_GPT2_Esig12_Set_GTIOCA_Pin_Ouput_Duty
* Description  : This function changes GTIOCA2 pin output duty setting
* Arguments    : duty_set -
*                    GTIOCA2 pin output duty setting
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT2_Esig12_Set_GTIOCA_Pin_Ouput_Duty(duty_setting_t duty_set)
{
    switch (duty_set)
    {
        case DUTY_COMPARE_MATCH_KEEP:
            GPT2.GTUDC.BIT.OADTYR = 0U;
            GPT2.GTUDC.BIT.OADTY = 0U;
            break;

        case DUTY_COMPARE_MATCH_MASK:
            GPT2.GTUDC.BIT.OADTYR = 1U;
            GPT2.GTUDC.BIT.OADTY = 0U;
            break;

        case DUTY_CYCLE_0:
            GPT2.GTUDC.BIT.OADTYR = 0U;
            GPT2.GTUDC.BIT.OADTY = 2U;
            break;

        case DUTY_CYCLE_100:
            GPT2.GTUDC.BIT.OADTYR = 0U;
            GPT2.GTUDC.BIT.OADTY = 3U;
            break;
    }
}

/***********************************************************************************************************************
* Function Name: R_Config_GPT2_Esig12_Set_GTIOCB_Pin_Ouput_Duty
* Description  : This function changes GTIOCB2 pin output duty setting
* Arguments    : duty_set -
*                    GTIOCB2 pin output duty setting
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT2_Esig12_Set_GTIOCB_Pin_Ouput_Duty(duty_setting_t duty_set)
{
    switch (duty_set)
    {
        case DUTY_COMPARE_MATCH_KEEP:
            GPT2.GTUDC.BIT.OBDTYR = 0U;
            GPT2.GTUDC.BIT.OBDTY = 0U;
            break;

        case DUTY_COMPARE_MATCH_MASK:
            GPT2.GTUDC.BIT.OBDTYR = 1U;
            GPT2.GTUDC.BIT.OBDTY = 0U;
            break;

        case DUTY_CYCLE_0:
            GPT2.GTUDC.BIT.OBDTYR = 0U;
            GPT2.GTUDC.BIT.OBDTY = 2U;
            break;

        case DUTY_CYCLE_100:
            GPT2.GTUDC.BIT.OBDTYR = 0U;
            GPT2.GTUDC.BIT.OBDTY = 3U;
            break;
    }
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
