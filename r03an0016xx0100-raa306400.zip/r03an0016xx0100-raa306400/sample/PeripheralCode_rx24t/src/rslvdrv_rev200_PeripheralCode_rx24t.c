/***********************************************************************
*
*  FILE        : rslvdrv_rev200_PeripheralCode_rx24t.c
*  DATE        : 2020-11-11
*  DESCRIPTION : Main Program
*
*  NOTE:THIS IS A TYPICAL EXAMPLE.
*
***********************************************************************/
#include "r_smc_entry.h"

void main(void);

void main(void)
{

}